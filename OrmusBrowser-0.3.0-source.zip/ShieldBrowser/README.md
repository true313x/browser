# Ormus Browser

A privacy-first, local-first Android web browser. No account, no cloud, no analytics, no telemetry, no Firebase/Google
services, no paid APIs. Everything runs and stays on the device.

> **Engine status (read this first):** this version still renders pages with the system **WebView** (Chromium).
> The planned migration to **Mozilla GeckoView** and to a Jetpack Compose / Material 3 UI has **not been implemented yet**;
> the audit, the feature-by-feature mapping and the staged plan are in [`docs/GECKOVIEW_MIGRATION.md`](docs/GECKOVIEW_MIGRATION.md).
> Everything below describes what the code does *today*.

> **Status: pre-release (0.3.0), never compiled by the authors' tooling.** The code in this repository was written
> without access to a compiler/Android SDK (including the 0.3.0 changes), so the **first build may need fixes**.
> No build and no test run has been executed for this version. Features are described honestly below:
> *Real*, *Best-effort* or *Not possible in WebView*.

**Naming.** The product name is **Ormus Browser** (Latin script in every locale). For data compatibility the
`applicationId`/package (`com.shieldbrowser.app`), the Keystore alias and some internal identifiers keep their original names.
The launcher icon is built from the Ormus eagle logo (`res/drawable-nodpi/ic_launcher_*.png`, `ormus_logo.png`).

---

## Build

Requirements: Android Studio Koala+ (or JDK 17 + Android SDK 34), internet for Gradle dependencies.

```bash
# Android Studio: File > Open > select this folder > Run ▶
# Command line (the binary gradle-wrapper.jar is not committed; generate it once):
gradle wrapper --gradle-version 8.7
./gradlew :app:testDebugUnitTest      # JVM unit tests
./gradlew :app:assembleDebug          # app/build/outputs/apk/debug/*.apk
./gradlew :app:connectedDebugAndroidTest   # instrumentation tests (device/emulator)
./gradlew :app:bundleRelease          # AAB (needs signing, see below)
```

**GitHub Actions** (`.github/workflows/build.yml`) already builds + tests with a pinned Gradle (no wrapper jar needed).

### Signing a release build
No keys are in the repo (`.gitignore` blocks `*.jks`, `keystore.properties`). Create your own keystore, then either sign
in Android Studio (*Build > Generate Signed Bundle / APK*) or add a local, git-ignored `keystore.properties` and a
`signingConfigs` block to `app/build.gradle.kts`.

**Install on a device:** enable "install unknown apps" for your file manager/ADB and install the APK;
or `adb install app-debug.apk`.

---

## Features and how real each one is

| Area | Status | How it works / limits |
|---|---|---|
| Ad blocker (domain / URL / resource / script rules) | **Real** | `shouldInterceptRequest` + local `RuleEngine`. Built-in list is **small** (~240 domains + ~40 patterns). Import hosts/domain lists from URL (https, user-initiated) or file. No cosmetic/regex/exception rules from ABP lists. |
| Tracker blocker with categories (Essential/Analytics/Advertising/Tracking/Social/Unknown) | **Real** | Per-category switches; essential infrastructure (CDNs, captcha, payments, sign-in) is allow-listed; first-party requests are not blocked by domain rules; per-site shield off; user allow/block lists. |
| Cosmetic hiding of ad containers | Best-effort | Generic CSS selectors only. |
| URL tracking-parameter cleaner + redirect-shim unwrapping | **Real** | `utm_*`, `fbclid`, `gclid`, `msclkid`, `dclid`, … + host-specific rules; Google/Facebook/Reddit link shims. Known params only. |
| Third-party cookie blocking | **Real** | `CookieManager.setAcceptThirdPartyCookies` per WebView and per site. |
| Per-site “block all cookies” | Best-effort | WebView has no per-site switch: cookies are expired after each page load and `document.cookie` is made inert. |
| Delete cookies on exit / session-only sites / clear site data | **Real** | On clean exit *and* crash recovery at next start. |
| Private tabs | **Real** where `MULTI_PROFILE` is supported | Dedicated WebView profile (own cookies/storage/cache), deleted when the last private tab closes; no history; private downloads in cache and wiped; `FLAG_SECURE` option. On old WebViews the banner says “LIMITED ISOLATION” (shared cookie jar). |
| Strict site isolation | **Real**, scope-limited | One throw-away profile per tab. Does **not** add OS-level process isolation beyond what Chromium gives. |
| Fingerprint protection (Off/Standard/Strict/Maximum) | Best-effort | Injected document-start JS: per-site randomised canvas/audio/WebGL read-back noise, generic WebGL strings, reduced `hardwareConcurrency`/`deviceMemory`, coarse screen, languages, timer resolution, (Maximum) UTC timezone reports, font probe & voices limiting. Cannot hide server-visible data (IP, TLS/HTTP2 fingerprint, headers). Font enumeration via layout measurement is **not** mitigated. |
| ~~User-Agent manager~~ | **Removed in 0.3.0** | Browser identity switching is not a feature of Ormus: it does not prevent fingerprinting and misleads users. The engine's own UA is used. |
| Anti-cryptomining | Best-effort | Known miner domains/patterns blocked; heuristic (many Workers + WebAssembly) can stop miners. Heuristics may rarely flag heavy web apps. |
| Drive-by protection | Best-effort | Auto-redirect gating (no gesture, cross-site), popup/popunder/new-window flood blocking, JS-dialog flood limit, automatic-download warning, `data:/file:/javascript:` top-level navigation blocked, sanitised intents. Cannot stop OS-level zero-click exploits. |
| Click/ping tracking | Partial | `ping` attributes removed, `noreferrer` added. Mouse/pointer-event listeners are **not** blocked (would break sites). |
| Referrer policy | **Real** | Injected `<meta name=referrer>` + `rel=noreferrer`. |
| HTTPS-only | **Real** | Upgrade + interstitial before falling back to HTTP; mixed content blocked; TLS errors never auto-proceed. |
| Permissions manager (camera/mic/location/clipboard/downloads/popups/autoplay/JS/cookies) | **Real** | Per registrable domain: Ask/Allow/Block. **Web notifications are not supported by Android WebView** (setting is stored, no effect). |
| Clipboard protection | Best-effort | Web `readText/read/paste` blocked unless allowed per site; writes need a user gesture; app can clear clipboard on exit. |
| WebRTC | Best-effort | Default / relay-only (`iceTransportPolicy=relay`) / block. Not a 100 % leak guarantee. |
| Secure DNS (DoH) | **Partial** | DoH (Cloudflare/Quad9/Mullvad/custom) for the app’s own traffic (downloads, list import). **Strict:** an invalid endpoint (custom endpoints must be https, no credentials, no loopback/private addresses) or an unreachable resolver makes lookups fail; there is **no silent fallback** to system DNS. **WebView has no DNS API**; page traffic uses system DNS — use Android *Private DNS* (Settings shortcut provided). |
| Downloads manager | **Real** | OkHttp, pause/resume (Range), speed/ETA, SHA-256, risk analysis, categories, search/sort/rename/share/delete. `blob:` downloads (the page streams the bytes to the app), progress/finished notifications with Pause/Resume/Cancel/Retry, foreground service so downloads survive leaving the app. Not supported: `data:` downloads; `blob:` downloads cannot be paused/resumed and need JavaScript. |
| Encrypted local settings | **Real** | All settings (incl. allow/block lists and the saved tab session) live in one AES-256-GCM file whose key is non-exportable in the Android Keystore. A file that cannot be decrypted is **preserved** (never overwritten) and merged back automatically if it becomes readable again. History/bookmarks/site rules (SQLite) and downloaded files are **not** encrypted. |
| Find in page | **Real** | Native WebView search with match counter, next/previous; Ctrl+F on hardware keyboards. |
| Tablet layout | **Real** | Smallest width ≥ 600dp: single top toolbar (navigation, address bar, tabs, menu), two-column tab switcher, centred lists/settings, bottom sheets limited to 640dp; Ctrl+L/T/W/F shortcuts. |
| APK handling | **Real** | Downloaded like any file; never auto-installed. Dialog shows source, size, SHA-256 and warnings; install goes through Android’s own installer after the “unknown apps” consent. |
| Media / video | **Real** | HTML5 video, fullscreen, controls, PiP via the page. **No DRM bypass**; DRM identifiers are denied. |
| History, bookmarks, reading list, recently closed, tab groups, tab search | **Real** | Local SQLite with `secure_delete`; auto-delete by age. |
| Privacy dashboard / security dashboard / session report | **Real** | Per-page counters + tappable event lists; report is in memory only. |
| Search-engine manager | **Real** | Google/Bing/DuckDuckGo/Brave/Startpage/Ecosia/custom template. Typing never leaves the device until submit. |
| Developer tools (hidden) | **Real** | Requests, blocked, cookies, permissions, UA, headers, console, page info. |
| Safe Browsing | Opt-in | Off by default (it contacts Google). Local malware-host list instead. |

## Architecture

Single Gradle module `:app`, packages follow clean layers (UI → domain → data), manual DI in `AppContainer`:

```
app/          Application + AppContainer (wiring, exit cleanup, settings listeners)
ui/           MainActivity (BrowserHost), privacy/site/tab sheets, report, dev tools
browser/      TabManager (app-scoped), WebViewConfigurator, Tab{WebView,WebChrome}Client, NavigationPolicy, ProfileManager
tabs/         Pure tab model (TabList) — unit tested
blocking/     RuleEngine, rule parsing, rule store/importer, domain utils (pure Kotlin)
privacy/      Stats, UrlCleaner, CookieController, page-script builder, clipboard guard
fingerprint/  Fingerprint-protection modes
security/     Interstitials (warning pages), external-intent sanitising, SecurityState
downloads/    Engine, safety heuristics, Downloads/Files UI
history/ bookmarks/ settings/ storage/ network/
assets/       rules/*.txt (built-in lists), js/shield_core.js (injected script)
```

Key design points: `TabManager` outlives the Activity (rotation/theme/language changes never lose tabs); the injected script
is built from settings and re-registered whenever settings or site rules change; warning pages are local HTML with a
per-page nonce so a website cannot forge “Continue anyway”.

## Privacy model
* No telemetry/analytics/ads/crash reporting SDKs. Only dependencies: AndroidX, Material, `androidx.webkit`, Kotlin coroutines, OkHttp (+DoH).
* Network requests made *by the app itself*: downloads you start, and blocklists **you** import. Nothing else.
* WebView metrics and Google Safe Browsing are disabled in the manifest/settings.
* `allowBackup=false`, data-extraction rules exclude everything, only system CAs trusted, cleartext allowed only so HTTPS-only can be switched off / overridden after a warning.
* Session report and private-mode state are never written to disk.

## Limitations (please read)
No browser engine of its own (WebView). No extension API. No per-site cookie switch, no DNS control for page traffic, no web notifications,
no DRM, no `data:` downloads, no service worker/IndexedDB enumeration. We **reduce** tracking and fingerprinting and block *known*
trackers; we do **not** make you anonymous, untrackable or unhackable.

## Roadmap
See [`docs/GECKOVIEW_MIGRATION.md`](docs/GECKOVIEW_MIGRATION.md) (stages G0–G9): first make the current code build and pass its unit tests, then
GeckoView, extension-based request blocking, Gecko-native privacy settings and DoH, ABP-format list support with safe updates,
Compose/Material 3 UI with customisable wallpapers, benchmarks and a release build. Also open: encrypting the SQLite database
(decision pending), native review of the Arabic and Persian translations.

## Contributing / License
See `CONTRIBUTING.md`, `SECURITY.md`, `CHANGELOG.md`. Licensed under MIT (`LICENSE`).
