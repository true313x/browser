package com.shieldbrowser.app

import com.shieldbrowser.app.privacy.PageScriptBuilder
import com.shieldbrowser.app.privacy.PageScriptConfig
import com.shieldbrowser.app.privacy.SiteScriptOverride
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PageScriptBuilderTest {
    private fun cfg(ovr: Map<String, SiteScriptOverride> = emptyMap()) = PageScriptConfig(
        fingerprintLevel = 2, referrerPolicy = "strict-origin", webRtc = "relay",
        blockClipboardRead = true, miningHeuristic = true, cosmetic = false, seed = 42, overrides = ovr
    )
    private val b = PageScriptBuilder("/*core*/")

    @Test fun prefixesConfigBeforeTemplate() {
        val s = b.build(cfg())
        assertTrue(s.startsWith("var __SHIELD_CFG = {")); assertTrue(s.endsWith("/*core*/"))
    }
    /** Ormus never changes the browser identity (no User-Agent / navigator.platform spoofing). */
    @Test fun configCarriesNoIdentityProfile() {
        val j = b.configJson(cfg())
        assertFalse(j.contains("\"id\":")); assertFalse(j.contains("platform")); assertFalse(j.contains("uad"))
    }
    @Test fun perSiteOverridesAreEmbedded() {
        val j = b.configJson(cfg(mapOf("example.com" to SiteScriptOverride(off = true, noCookie = true))))
        assertTrue(j.contains("\"example.com\":{\"off\":true,\"nocookie\":true"))
    }
    @Test fun configCannotBreakOutOfTheScript() {
        val j = b.configJson(cfg(mapOf("evil\"</script>" to SiteScriptOverride())))
        assertTrue(!j.contains("</script>")); assertEquals(j.count { it == '{' }, j.count { it == '}' })
    }
}
