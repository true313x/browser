package com.shieldbrowser.app

import com.shieldbrowser.app.network.DohEndpoint
import com.shieldbrowser.app.network.DohEndpoint.Result
import com.shieldbrowser.app.network.FailClosedDns
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.UnknownHostException

class DohEndpointTest {
    private fun ok(u: String) = assertTrue("should be valid: $u", DohEndpoint.validate(u) is Result.Valid)
    private fun bad(u: String) = assertTrue("should be invalid: $u", DohEndpoint.validate(u) is Result.Invalid)

    @Test fun acceptsNormalHttpsEndpoints() {
        ok("https://cloudflare-dns.com/dns-query")
        ok("https://dns.example.org:8443/dns-query?x=1")
        ok("https://1.1.1.1/dns-query")                    // public IP literal is fine
        ok("  https://dns.quad9.net/dns-query  ")           // surrounding whitespace is trimmed
    }

    @Test fun trimsTheStoredValue() =
        assertEquals("https://dns.quad9.net/dns-query", (DohEndpoint.validate(" https://dns.quad9.net/dns-query ") as Result.Valid).url)

    @Test fun rejectsNonHttps() { bad("http://dns.example.org/dns-query"); bad("ftp://x.example/dns"); bad("//dns.example.org/q"); bad("dns.example.org") }

    @Test fun rejectsCredentialsFragmentsAndGarbage() {
        bad("https://user:pw@dns.example.org/dns-query"); bad("https://dns.example.org/q#frag")
        bad(""); bad("   "); bad("https://"); bad("https://dns example.org/q"); bad("https://dns.example.org/q\nx")
        bad("https://" + "a".repeat(600) + ".com/q")
    }

    @Test fun rejectsBadPorts() { bad("https://dns.example.org:0/q"); bad("https://dns.example.org:70000/q") }

    @Test fun rejectsLocalAndPrivateTargets() {
        listOf(
            "https://localhost/q", "https://foo.localhost/q", "https://router.local/q", "https://nas.lan/q", "https://x.internal/q",
            "https://127.0.0.1/q", "https://10.0.0.1/q", "https://192.168.1.1/q", "https://172.16.0.5/q", "https://172.31.255.1/q",
            "https://169.254.169.254/latest", "https://0.0.0.0/q", "https://100.64.0.1/q", "https://[::1]/q", "https://[fe80::1]/q", "https://[fd00::1]/q"
        ).forEach { bad(it) }
        ok("https://172.32.0.1/q"); ok("https://8.8.8.8/dns-query")      // just outside the private ranges
    }

    @Test fun failClosedResolverNeverFallsBack() {
        try { FailClosedDns("test").lookup("example.com"); fail("must throw") }
        catch (e: UnknownHostException) { assertTrue(e.message!!.contains("Not falling back")) }
    }
}
