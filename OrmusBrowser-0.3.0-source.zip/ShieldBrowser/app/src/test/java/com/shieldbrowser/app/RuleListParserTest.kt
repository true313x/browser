package com.shieldbrowser.app

import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.blocking.RuleListParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RuleListParserTest {
    @Test fun parsesHostsDomainAndAbpDomainRules() {
        val text = "# header\n0.0.0.0 ads.example.com\n127.0.0.1 localhost\n||tracker.net^\n||bad.com^\$third-party\nplain.org\n||x.com/path\n!comment"
        val r = RuleListParser.parseDomains(text, BlockCategory.TRACKING)
        assertEquals(setOf("ads.example.com", "tracker.net", "bad.com", "plain.org"), r.domains.keys)
        assertEquals(2, r.skipped)
        assertTrue(r.domains.values.all { it == BlockCategory.TRACKING })
    }

    @Test fun builtInFormatCarriesCategory() {
        val r = RuleListParser.parseDomains("ads.example.com advertising\nminer.example cryptomining", BlockCategory.TRACKING)
        assertEquals(BlockCategory.ADVERTISING, r.domains["ads.example.com"])
        assertEquals(BlockCategory.CRYPTOMINING, r.domains["miner.example"])
    }

    @Test fun rejectsIpsAndGarbage() {
        val r = RuleListParser.parseDomains("1.2.3.4\nnot a domain\n-bad-.com\nOK.Example.COM", BlockCategory.ADVERTISING)
        assertTrue("ok.example.com" in r.domains)
        assertFalse("1.2.3.4" in r.domains)
    }

    @Test fun detectsHtmlThatMustNeverBeStoredAsAList() {
        assertTrue(RuleListParser.looksLikeHtml("  <!DOCTYPE html><html>captive portal"))
        assertTrue(RuleListParser.looksLikeHtml("<html><body>502 Bad Gateway</body></html>"))
        assertTrue(RuleListParser.looksLikeHtml("<?xml version=\"1.0\"?>"))
        assertFalse(RuleListParser.looksLikeHtml("! Title: EasyList\n||ads.example.com^"))
        assertFalse(RuleListParser.looksLikeHtml("0.0.0.0 ads.example.com"))
    }
}
