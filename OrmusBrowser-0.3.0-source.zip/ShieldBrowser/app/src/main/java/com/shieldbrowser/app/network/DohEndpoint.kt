package com.shieldbrowser.app.network

import java.net.URI

/**
 * Validation of a user-supplied DNS-over-HTTPS endpoint (pure JVM, unit-tested).
 * Rules: https only, no credentials/fragment, valid host and port, and no loopback / private / link-local targets
 * (a pasted or imported setting must not be able to point the resolver at the user's own LAN).
 */
object DohEndpoint {
    const val MAX_LENGTH = 512

    sealed class Result {
        data class Valid(val url: String) : Result()
        data class Invalid(val reason: String) : Result()
    }

    fun validate(raw: String): Result {
        val t = raw.trim()
        if (t.isEmpty()) return Result.Invalid("empty")
        if (t.length > MAX_LENGTH) return Result.Invalid("too long")
        if (t.any { it.isWhitespace() || it.isISOControl() }) return Result.Invalid("contains whitespace or control characters")
        val uri = try { URI(t) } catch (_: Exception) { return Result.Invalid("not a valid URL") }
        if (!"https".equals(uri.scheme, ignoreCase = true)) return Result.Invalid("must use https://")
        if (uri.rawUserInfo != null) return Result.Invalid("must not contain credentials")
        if (uri.rawFragment != null) return Result.Invalid("must not contain a fragment")
        val host = uri.host?.lowercase() ?: return Result.Invalid("missing or invalid host")
        if (uri.port != -1 && uri.port !in 1..65535) return Result.Invalid("invalid port")
        if (isLocalOrPrivate(host)) return Result.Invalid("local or private addresses are not allowed")
        return Result.Valid(t)
    }

    /** [host] as returned by [URI.getHost] (IPv6 literals keep their brackets). */
    fun isLocalOrPrivate(host: String): Boolean {
        if (host == "localhost" || host.endsWith(".localhost") || host.endsWith(".local") ||
            host.endsWith(".internal") || host.endsWith(".lan") || host.endsWith(".home.arpa")) return true
        if (host.startsWith("[")) {
            val h = host.removePrefix("[").removeSuffix("]")
            return h == "::1" || h == "::" || h.startsWith("fe80") || h.startsWith("fc") || h.startsWith("fd") || h.startsWith("::ffff:")
        }
        val p = host.split('.')
        if (p.size == 4 && p.all { it.toIntOrNull() in 0..255 }) {
            val a = p[0].toInt(); val b = p[1].toInt()
            return a == 0 || a == 10 || a == 127 || (a == 169 && b == 254) || (a == 172 && b in 16..31) || (a == 192 && b == 168) ||
                (a == 100 && b in 64..127)   // carrier-grade NAT
        }
        return false
    }
}
