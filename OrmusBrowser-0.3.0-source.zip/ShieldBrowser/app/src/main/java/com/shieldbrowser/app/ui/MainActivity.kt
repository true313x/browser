package com.shieldbrowser.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.HttpAuthHandler
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListPopupWindow
import android.widget.ArrayAdapter
import android.widget.PopupMenu
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.bookmarks.BookmarkKind
import com.shieldbrowser.app.bookmarks.BookmarksActivity
import com.shieldbrowser.app.browser.BrowserHost
import com.shieldbrowser.app.browser.BrowserTab
import com.shieldbrowser.app.browser.JsDialogKind
import com.shieldbrowser.app.browser.SitePerm
import com.shieldbrowser.app.browser.UrlInput
import com.shieldbrowser.app.databinding.ActivityMainBinding
import com.shieldbrowser.app.downloads.BlobDownloadManager
import com.shieldbrowser.app.downloads.DownloadRequest
import com.shieldbrowser.app.downloads.DownloadSafety
import com.shieldbrowser.app.downloads.DownloadsActivity
import com.shieldbrowser.app.downloads.RiskLevel
import com.shieldbrowser.app.history.HistoryActivity
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.privacy.ClipboardGuard
import com.shieldbrowser.app.privacy.EventType
import com.shieldbrowser.app.privacy.UrlCleaner
import com.shieldbrowser.app.security.SecurityState
import com.shieldbrowser.app.settings.Perm
import com.shieldbrowser.app.settings.ScreenshotMode
import com.shieldbrowser.app.settings.SettingsActivity
import com.shieldbrowser.app.settings.SiteSettingsActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), BrowserHost {
    companion object {
        const val EXTRA_INTERNAL = "internal"
        const val EXTRA_NEW_TAB = "new_tab"
        const val ACTION_NEW_PRIVATE = "com.shieldbrowser.app.action.NEW_PRIVATE_TAB"
    }

    private lateinit var b: ActivityMainBinding
    private lateinit var c: AppContainer
    private val tabs get() = c.tabs

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var permCallback: ((Boolean) -> Unit)? = null
    private var suggestJob: Job? = null
    private var suggestPopup: ListPopupWindow? = null
    private val ui = Handler(Looper.getMainLooper())
    private var lastLocale = ""
    private var lastNight = -1
    private var lastWide = false              // smallest width >= 600dp → tablet layout (layout-sw600dp)
    private var findActive = false
    private var findTabId = -1L
    private var findUrl = ""

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }
    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        permCallback?.invoke(res.values.all { it })
        permCallback = null
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        c = container
        c.settings.exitCleanupPending = true
        lastLocale = resources.configuration.locales.toLanguageTags()
        lastNight = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        lastWide = resources.configuration.smallestScreenWidthDp >= 600
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        setupAddressBar()
        setupBottomBar()
        setupFindBar()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBack()
        })

        tabs.attach(this, this)
        if (tabs.list.tabs.isEmpty() && !tabs.restoreSession()) tabs.newTab(null, false)
        else if (tabs.active() == null) tabs.list.tabs.firstOrNull()?.let { tabs.select(it.id) }
        showActiveTab()
        handleIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val loc = newConfig.locales.toLanguageTags()
        val night = newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK
        // The tablet layout is chosen by smallest width, which only changes on fold/unfold or window resizing,
        // not on rotation, so rotating a video into fullscreen never recreates the activity.
        val wide = newConfig.smallestScreenWidthDp >= 600
        val changed = (lastLocale.isNotEmpty() && loc != lastLocale) || (lastNight != -1 && night != lastNight) || wide != lastWide
        lastLocale = loc; lastNight = night; lastWide = wide
        if (changed && customView == null) recreate()          // tabs survive: TabManager is app-scoped
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.isCtrlPressed) {
            when (keyCode) {
                KeyEvent.KEYCODE_F -> { showFindBar(); return true }
                KeyEvent.KEYCODE_L -> { b.urlInput.requestFocus(); return true }
                KeyEvent.KEYCODE_T -> { tabs.newTab(null, false); return true }
                KeyEvent.KEYCODE_W -> { tabs.active()?.let { tabs.closeTab(it.id) }; return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        if (intent.action == ACTION_NEW_PRIVATE) { tabs.newTab(null, true); return }
        if (intent.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return      // never open file:, content:, javascript:, intent: from outside
        val internal = intent.getBooleanExtra(EXTRA_INTERNAL, false)
        val newTab = !internal || intent.getBooleanExtra(EXTRA_NEW_TAB, true)
        val active = tabs.active()
        if (newTab || active == null) tabs.newTab(uri.toString(), active?.isPrivate == true && internal)
        else tabs.navigate(active, uri.toString())
        intent.data = null
    }

    override fun onResume() {
        super.onResume()
        tabs.active()?.webView?.onResume()
        applySecureFlag()
    }

    override fun onPause() {
        tabs.active()?.webView?.onPause()
        c.cookies.flush()
        super.onPause()
    }

    override fun onStop() {
        tabs.persistSession()
        super.onStop()
    }

    override fun onDestroy() {
        suggestPopup?.dismiss()
        fileCallback?.onReceiveValue(null)      // otherwise the page's <input type=file> would hang forever
        fileCallback = null
        if (isFinishing && !isChangingConfigurations) {
            c.runExitCleanup()
            tabs.detach(this)
            tabs.shutdown()
        } else {
            b.webContainer.removeAllViews()
            tabs.detach(this)
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ chrome
    @SuppressLint("ClickableViewAccessibility")
    private fun setupAddressBar() {
        b.urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                submitAddress(b.urlInput.text.toString()); true
            } else false
        }
        b.urlInput.setOnFocusChangeListener { _, focused ->
            val tab = tabs.active()
            if (focused) {
                if (tab != null && !tab.internalPage) b.urlInput.setText(tab.data.url)
                b.urlInput.post { b.urlInput.selectAll() }
            } else {
                suggestPopup?.dismiss()
                if (tab != null) showUrlText(tab)
            }
        }
        b.urlInput.addTextChangedListener { text ->
            if (b.urlInput.hasFocus()) scheduleSuggestions(text?.toString().orEmpty())
        }
        b.btnReload.setOnClickListener {
            val t = tabs.active() ?: return@setOnClickListener
            if (t.loading) t.webView?.stopLoading() else t.webView?.reload()
        }
        b.btnSecurity.setOnClickListener { tabs.active()?.let { showSecurityDialog(it) } }
        b.btnShield.setOnClickListener { tabs.active()?.let { PrivacySheet(this, it).show() } }
    }

    private fun setupBottomBar() {
        b.btnBack.setOnClickListener { goBack() }
        b.btnForward.setOnClickListener { tabs.active()?.webView?.takeIf { it.canGoForward() }?.goForward() }
        b.btnHome.setOnClickListener { tabs.active()?.let { tabs.navigate(it, c.settings.homepage) } }
        b.btnDownloads.setOnClickListener { startActivity(Intent(this, DownloadsActivity::class.java)) }
        b.btnTabs.setOnClickListener { TabSwitcherSheet(this).show() }
        b.btnMenu.setOnClickListener { showMenu() }
    }

    private fun submitAddress(text: String) {
        val tab = tabs.active() ?: return
        suggestPopup?.dismiss()
        b.urlInput.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(b.urlInput.windowToken, 0)
        if (text.isNotBlank()) tabs.navigate(tab, text)
    }

    private fun showUrlText(tab: BrowserTab) {
        if (b.urlInput.hasFocus()) return
        b.urlInput.setText(if (tab.internalPage && tab.data.url == "shield://start") "" else UrlInput.displayUrl(tab.data.url))
    }

    private fun scheduleSuggestions(q: String) {
        suggestJob?.cancel()
        if (q.isBlank()) { suggestPopup?.dismiss(); return }
        suggestJob = lifecycleScope.launch {
            delay(150)
            val h = c.history.suggest(q, 5)
            val bk = c.bookmarks.suggest(q, 3)
            val urls = (bk.map { it.url } + h.map { it.url }).distinct().take(7)
            if (urls.isEmpty() || !b.urlInput.hasFocus()) { suggestPopup?.dismiss(); return@launch }
            val p = suggestPopup ?: ListPopupWindow(this@MainActivity).also { suggestPopup = it }
            p.anchorView = b.addressCard
            p.width = b.addressCard.width
            p.inputMethodMode = ListPopupWindow.INPUT_METHOD_NEEDED
            p.setAdapter(ArrayAdapter(this@MainActivity, R.layout.item_suggestion, urls))
            p.setOnItemClickListener { _, _, pos, _ -> p.dismiss(); submitAddress(urls[pos]) }
            p.show()
        }
    }

    private fun showActiveTab() {
        val tab = tabs.active() ?: return
        val wv = tabs.webViewFor(tab)
        if (wv.parent !== b.webContainer) {
            (wv.parent as? ViewGroup)?.removeView(wv)
            b.webContainer.removeAllViews()
            b.webContainer.addView(wv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        updateChrome(tab)
    }

    private fun updateChrome(tab: BrowserTab) {
        if (findActive && (tab.id != findTabId || tab.data.url != findUrl)) hideFindBar()
        showUrlText(tab)
        // security icon
        val (icon, color) = when (tab.security) {
            SecurityState.SECURE -> R.drawable.ic_lock to R.color.status_ok
            SecurityState.INSECURE -> R.drawable.ic_lock_open to R.color.status_warn
            SecurityState.WARNING -> R.drawable.ic_warning to R.color.status_bad
            SecurityState.INTERNAL -> R.drawable.ic_shield to R.color.status_off
            SecurityState.NONE -> R.drawable.ic_lock to R.color.status_off
        }
        b.btnSecurity.setImageResource(icon)
        b.btnSecurity.setColorFilter(getColor(color))
        b.btnReload.setImageResource(if (tab.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        val wv = tab.webView
        b.btnBack.alpha = if (wv?.canGoBack() == true || tab.openerId != null) 1f else 0.38f
        b.btnForward.alpha = if (wv?.canGoForward() == true) 1f else 0.38f
        b.tabCount.text = tabs.list.tabs.size.toString()
        // private mode indicator
        b.privateBanner.visibility = if (tab.isPrivate) View.VISIBLE else View.GONE
        b.privateBanner.text = getString(if (tabs.privateIsolated || !tab.isPrivate) R.string.private_mode_banner else R.string.private_mode_banner_limited)
        b.addressCard.setBackgroundResource(if (tab.isPrivate) R.drawable.bg_address_private else R.drawable.bg_address)
        updateShield(tab)
        applySecureFlag()
    }

    private fun updateShield(tab: BrowserTab) {
        val n = tab.stats.counters.let { it.trackers.get() + it.ads.get() + it.mining.get() }
        val off = !c.siteSettings.isShieldOn(tab.pageHost ?: "")
        b.shieldBadge.text = if (n > 99) "99+" else n.toString()
        b.shieldBadge.visibility = if (n > 0 && !off) View.VISIBLE else View.GONE
        b.btnShield.setColorFilter(getColor(if (off) R.color.status_off else R.color.status_ok))
    }

    private fun applySecureFlag() {
        val tab = tabs.active()
        val secure = when (c.settings.screenshots) {
            ScreenshotMode.ALWAYS -> true
            ScreenshotMode.PRIVATE -> tab?.isPrivate == true
            ScreenshotMode.NEVER -> false
        }
        if (secure) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    // ------------------------------------------------------------------ back / nav
    private fun goBack() {
        val tab = tabs.active() ?: return
        val wv = tab.webView
        when {
            wv != null && wv.canGoBack() -> wv.goBack()
            tab.openerId != null && tabs.tab(tab.openerId!!) != null -> tabs.closeTab(tab.id)
        }
    }

    private fun handleBack() {
        if (customView != null) { hideCustomView(); return }
        if (findActive) { hideFindBar(); return }
        val tab = tabs.active()
        val wv = tab?.webView
        when {
            wv != null && wv.canGoBack() -> wv.goBack()
            tab != null && tab.openerId != null && tabs.tab(tab.openerId!!) != null -> tabs.closeTab(tab.id)
            tab != null && tabs.list.tabs.size > 1 && tab.isPrivate -> tabs.closeTab(tab.id)
            else -> moveTaskToBack(true)
        }
    }

    // ------------------------------------------------------------------ menu
    private fun showMenu() {
        val tab = tabs.active() ?: return
        val pm = PopupMenu(this, b.btnMenu)
        pm.menuInflater.inflate(R.menu.menu_browser, pm.menu)
        pm.menu.findItem(R.id.m_devtools).isVisible = c.settings.developerMode
        val url = tab.data.url
        val webPage = url.startsWith("http")
        pm.menu.findItem(R.id.m_bookmark).isEnabled = webPage
        pm.menu.findItem(R.id.m_reading).isEnabled = webPage
        pm.menu.findItem(R.id.m_share).isEnabled = webPage
        pm.menu.findItem(R.id.m_find).isEnabled = webPage
        pm.menu.findItem(R.id.m_site_settings).isEnabled = webPage
        lifecycleScope.launch {
            val has = webPage && c.bookmarks.contains(url)
            pm.menu.findItem(R.id.m_bookmark).setTitle(if (has) R.string.remove_bookmark else R.string.add_bookmark)
        }
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.m_new_tab -> tabs.newTab(null, false)
                R.id.m_new_private -> tabs.newTab(null, true)
                R.id.m_bookmark -> toggleBookmark(tab)
                R.id.m_reading -> lifecycleScope.launch {
                    c.bookmarks.add(tab.data.url, tab.data.title, BookmarkKind.READING_LIST)
                    toast(getString(R.string.added_reading_list))
                }
                R.id.m_share -> share(tab.data.url)
                R.id.m_find -> showFindBar()
                R.id.m_bookmarks -> startActivity(Intent(this, BookmarksActivity::class.java))
                R.id.m_history -> startActivity(Intent(this, HistoryActivity::class.java))
                R.id.m_downloads -> startActivity(Intent(this, DownloadsActivity::class.java))
                R.id.m_report -> startActivity(Intent(this, PrivacyReportActivity::class.java))
                R.id.m_site_settings -> SiteSettingsSheet(this, tab.pageHost ?: DomainUtils.hostOf(url) ?: "").show()
                R.id.m_clear_data -> showClearDataDialog()
                R.id.m_devtools -> startActivity(Intent(this, DevToolsActivity::class.java))
                R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
                R.id.m_exit -> finishAndRemoveTask()
            }
            true
        }
        pm.show()
    }

    private fun toggleBookmark(tab: BrowserTab) {
        lifecycleScope.launch {
            val url = tab.data.url
            if (c.bookmarks.contains(url)) { c.bookmarks.remove(url, BookmarkKind.BOOKMARK); toast(getString(R.string.bookmark_removed)) }
            else { c.bookmarks.add(url, tab.data.title, BookmarkKind.BOOKMARK); toast(getString(R.string.bookmark_added)) }
        }
    }

    private fun share(url: String) {
        val clean = UrlCleaner.clean(url)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, clean), null))
    }

    private fun showClearDataDialog() {
        val labels = arrayOf(getString(R.string.clear_history), getString(R.string.clear_cookies), getString(R.string.clear_downloads_list), getString(R.string.clear_report), getString(R.string.clear_clipboard))
        val checked = booleanArrayOf(true, true, false, true, false)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.clear_browsing_data)
            .setMultiChoiceItems(labels, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton(R.string.clear) { _, _ ->
                lifecycleScope.launch {
                    if (checked[0]) c.history.deleteAll()
                    if (checked[1]) c.cookies.clearAll()
                    if (checked[2]) c.downloads.clearFinished(deleteFiles = false)
                    if (checked[3]) c.sessionReport.clear()
                    if (checked[4]) ClipboardGuard.clear(this@MainActivity)
                    toast(getString(R.string.cleared))
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    fun showSecurityDialog(tab: BrowserTab) {
        val cert = tab.webView?.certificate
        val sb = StringBuilder()
        sb.append(getString(when (tab.security) {
            SecurityState.SECURE -> R.string.sec_secure
            SecurityState.INSECURE -> R.string.sec_insecure
            SecurityState.WARNING -> R.string.sec_warning
            else -> R.string.sec_internal
        })).append("\n\n")
        if (cert != null && tab.security != SecurityState.INTERNAL) {
            sb.append(getString(R.string.cert_issued_to, cert.issuedTo?.cName ?: "?")).append('\n')
            sb.append(getString(R.string.cert_issued_by, cert.issuedBy?.cName ?: "?", cert.issuedBy?.oName ?: "")).append('\n')
            sb.append(getString(R.string.cert_valid, cert.validNotBeforeDate?.toString() ?: "?", cert.validNotAfterDate?.toString() ?: "?"))
        }
        sb.append("\n\n").append(getString(R.string.https_only)).append(": ").append(getString(if (c.settings.httpsOnly) R.string.on else R.string.off))
        MaterialAlertDialogBuilder(this).setTitle(R.string.security).setMessage(sb.toString()).setPositiveButton(android.R.string.ok, null).show()
    }

    /** The bottom bar only exists on phones; on tablets (layout-sw600dp) it is hidden and must not anchor snackbars. */
    private fun snackbarAnchor(): View? = if (b.bottomBar.visibility == View.VISIBLE) b.bottomBar else null

    private fun toast(msg: String) { Snackbar.make(b.root, msg, Snackbar.LENGTH_SHORT).setAnchorView(snackbarAnchor()).show() }

    // ------------------------------------------------------------------ BrowserHost
    override fun onTabsChanged() { ui.post { b.tabCount.text = tabs.list.tabs.size.toString() } }

    override fun onActiveTabChanged() { ui.post { showActiveTab() } }

    override fun onTabChanged(tab: BrowserTab) {
        ui.post { if (tab.id == tabs.list.activeId) updateChrome(tab) }
    }

    override fun onProgress(tab: BrowserTab, progress: Int) {
        ui.post {
            if (tab.id != tabs.list.activeId) return@post
            b.progress.visibility = if (progress in 1..99) View.VISIBLE else View.INVISIBLE
            b.progress.setProgressCompat(progress, true)
            b.btnReload.setImageResource(if (progress in 1..99) R.drawable.ic_close else R.drawable.ic_refresh)
        }
    }

    override fun onStats(tab: BrowserTab) { ui.post { if (tab.id == tabs.list.activeId) updateShield(tab) } }

    override fun toast(message: String, actionLabel: String?, action: (() -> Unit)?) {
        ui.post {
            val s = Snackbar.make(b.root, message, Snackbar.LENGTH_LONG)
            if (actionLabel != null && action != null) s.setAction(actionLabel) { action() }
            s.anchorView = snackbarAnchor()
            s.show()
        }
    }

    override fun promptEnableJs(tab: BrowserTab, host: String) {
        toast(getString(R.string.js_blocked_ask, host), getString(R.string.enable)) {
            c.siteSettings.update(host) { it.copy(js = Perm.ALLOW) }
            tabs.reloadActive()
        }
    }

    override fun requestSitePermissions(tab: BrowserTab, siteHost: String, needs: List<SitePerm>, onResult: (Boolean) -> Unit) {
        ui.post {
            val site = c.siteSettings.get(siteHost)
            val values = needs.map {
                when (it) { SitePerm.CAMERA -> site.camera; SitePerm.MICROPHONE -> site.mic; SitePerm.LOCATION -> site.location }
            }
            when {
                values.any { it == Perm.BLOCK } -> onResult(false)
                values.all { it == Perm.ALLOW } -> ensureRuntimePermissions(needs, onResult)
                else -> {
                    val what = needs.joinToString(", ") { getString(when (it) { SitePerm.CAMERA -> R.string.perm_camera; SitePerm.MICROPHONE -> R.string.perm_microphone; SitePerm.LOCATION -> R.string.perm_location }) }
                    var remember = false
                    MaterialAlertDialogBuilder(this)
                        .setTitle(getString(R.string.perm_request_title, siteHost.ifEmpty { "?" }))
                        .setMessage(getString(R.string.perm_request_msg, what))
                        .setMultiChoiceItems(arrayOf(getString(R.string.remember_for_site)), booleanArrayOf(false)) { _, _, v -> remember = v }
                        .setPositiveButton(R.string.allow) { _, _ ->
                            if (remember) c.siteSettings.update(siteHost) { s -> needs.fold(s) { acc, n -> when (n) { SitePerm.CAMERA -> acc.copy(camera = Perm.ALLOW); SitePerm.MICROPHONE -> acc.copy(mic = Perm.ALLOW); SitePerm.LOCATION -> acc.copy(location = Perm.ALLOW) } } }
                            ensureRuntimePermissions(needs, onResult)
                        }
                        .setNegativeButton(R.string.block) { _, _ ->
                            if (remember) c.siteSettings.update(siteHost) { s -> needs.fold(s) { acc, n -> when (n) { SitePerm.CAMERA -> acc.copy(camera = Perm.BLOCK); SitePerm.MICROPHONE -> acc.copy(mic = Perm.BLOCK); SitePerm.LOCATION -> acc.copy(location = Perm.BLOCK) } } }
                            onResult(false)
                        }
                        .setOnCancelListener { onResult(false) }
                        .show()
                }
            }
        }
    }

    private fun ensureRuntimePermissions(needs: List<SitePerm>, onResult: (Boolean) -> Unit) {
        val perms = needs.flatMap {
            when (it) {
                SitePerm.CAMERA -> listOf(Manifest.permission.CAMERA)
                SitePerm.MICROPHONE -> listOf(Manifest.permission.RECORD_AUDIO)
                SitePerm.LOCATION -> listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            }
        }.distinct()
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { onResult(true); return }
        permCallback = { ok ->
            // Location: either fine or coarse is enough.
            val loc = needs.contains(SitePerm.LOCATION) && perms.any { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
            onResult(ok || (loc && needs.size == 1))
        }
        permLauncher.launch(missing.toTypedArray())
    }

    override fun confirmExternal(tab: BrowserTab, label: String, onAllow: () -> Unit) {
        ui.post {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.open_external_title)
                .setMessage(getString(R.string.open_external_msg, tab.pageHost ?: "?", label))
                .setPositiveButton(R.string.open) { _, _ -> onAllow() }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    override fun showJsDialog(tab: BrowserTab, kind: JsDialogKind, host: String, message: String, default: String?, result: JsResult) {
        ui.post {
            val builder = MaterialAlertDialogBuilder(this).setTitle(host).setMessage(message)
            builder.setOnCancelListener { result.cancel() }
            when (kind) {
                JsDialogKind.ALERT -> builder.setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                JsDialogKind.CONFIRM -> builder.setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                JsDialogKind.PROMPT -> {
                    val input = EditText(this).apply { setText(default.orEmpty()); setSingleLine() }
                    val box = LinearLayout(this).apply { setPadding(48, 8, 48, 0); addView(input, LinearLayout.LayoutParams(-1, -2)) }
                    builder.setView(box)
                        .setPositiveButton(android.R.string.ok) { _, _ -> (result as? JsPromptResult)?.confirm(input.text.toString()) ?: result.confirm() }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                }
            }
            builder.show()
        }
    }

    override fun launchFileChooser(callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
        fileCallback?.onReceiveValue(null)
        fileCallback = callback
        return try { fileLauncher.launch(params.createIntent()); true } catch (_: Exception) { fileCallback = null; false }
    }

    override fun showCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
        ui.post {
            if (customView != null) { callback.onCustomViewHidden(); return@post }
            customView = view; customCb = callback
            b.fullscreenContainer.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            b.fullscreenContainer.visibility = View.VISIBLE
            b.mainColumn.visibility = View.GONE
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }

    override fun hideCustomView() {
        ui.post {
            val v = customView ?: return@post
            b.fullscreenContainer.removeView(v)
            b.fullscreenContainer.visibility = View.GONE
            b.mainColumn.visibility = View.VISIBLE
            customView = null
            customCb?.onCustomViewHidden(); customCb = null
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onDownloadRequested(tab: BrowserTab, url: String, userAgent: String?, contentDisposition: String?, mime: String?, length: Long) {
        ui.post {
            val scheme = DomainUtils.schemeOf(url)
            if (scheme == "blob") { startBlobDownload(tab, url); return@post }
            if (scheme != "http" && scheme != "https") { toast(getString(R.string.download_unsupported)); return@post }
            val host = DomainUtils.hostOf(url) ?: ""
            val name = DownloadSafety.sanitizeFileName(URLUtil.guessFileName(url, contentDisposition, mime))
            askAndStart(tab, name, mime, url, length, onAccept = {
                val cookies = try { tab.profileName.let { c.profiles.cookieManagerFor(it) }.getCookie(url) } catch (_: Exception) { null }
                c.downloads.enqueue(DownloadRequest(url, userAgent, cookies, tab.data.url.takeIf { it.startsWith("http") }, name, mime, length, tab.isPrivate))
                c.sessionReport.record(BlockEvent(EventType.DOWNLOAD, host, url, detail = "started"), 0)
                showDownloadStarted(name)
                maybeAskNotificationPermission()
            }, onReject = { })
        }
    }

    /** blob: download: ask the page for the bytes; the normal policy dialog runs once the metadata arrives. */
    private fun startBlobDownload(tab: BrowserTab, url: String) {
        val pageHost = tab.pageHost ?: (DomainUtils.hostOf(url) ?: "")
        if (c.siteSettings.get(pageHost).downloads == Perm.BLOCK) { toast(getString(R.string.download_blocked_site, pageHost)); return }
        when (c.blobs.begin(tab, url)) {
            BlobDownloadManager.BeginResult.STARTED -> Unit
            BlobDownloadManager.BeginResult.NO_JS -> toast(getString(R.string.blob_js_needed))
            BlobDownloadManager.BeginResult.BUSY -> toast(getString(R.string.blob_busy))
            BlobDownloadManager.BeginResult.NO_WEBVIEW, BlobDownloadManager.BeginResult.UNSUPPORTED -> toast(getString(R.string.blob_unsupported))
        }
    }

    override fun confirmBlobDownload(tab: BrowserTab, name: String, mime: String?, size: Long, blobUrl: String, onResult: (Boolean) -> Unit) {
        ui.post {
            val host = DomainUtils.hostOf(blobUrl) ?: ""
            askAndStart(tab, name, mime, blobUrl, size, onAccept = {
                onResult(true)
                c.sessionReport.record(BlockEvent(EventType.DOWNLOAD, host, blobUrl, detail = "started"), 0)
                showDownloadStarted(name)
                maybeAskNotificationPermission()
            }, onReject = { onResult(false) })
        }
    }

    /** Applies the per-site download policy and, when needed, asks the user. Calls exactly one of the callbacks. */
    private fun askAndStart(tab: BrowserTab, name: String, mime: String?, url: String, length: Long, onAccept: () -> Unit, onReject: () -> Unit) {
        val host = DomainUtils.hostOf(url) ?: ""
        val pageHost = tab.pageHost ?: host
        val site = c.siteSettings.get(pageHost)
        if (site.downloads == Perm.BLOCK) { toast(getString(R.string.download_blocked_site, pageHost)); onReject(); return }
        val risk = DownloadSafety.assess(name, mime, url)
        val automatic = c.settings.blockAutoDownloads && System.currentTimeMillis() - tab.lastTouchAt > 5000
        val needAsk = site.downloads == Perm.ASK || (site.downloads == Perm.INHERIT && c.settings.askBeforeDownload) ||
            automatic || (c.settings.warnDangerous && risk.level != RiskLevel.LOW)
        if (!needAsk) { onAccept(); return }
        val msg = StringBuilder()
        if (automatic) msg.append(getString(R.string.download_automatic)).append("\n\n")
        msg.append(getString(R.string.download_file, name)).append('\n')
        msg.append(getString(R.string.download_source, host)).append('\n')
        msg.append(getString(R.string.download_size, formatSize(length)))
        if (risk.level != RiskLevel.LOW) msg.append("\n\n⚠ ").append(getString(R.string.download_risky))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.download_confirm_title)
            .setMessage(msg.toString())
            .setPositiveButton(R.string.download) { _, _ -> onAccept() }
            .setNegativeButton(android.R.string.cancel) { _, _ -> onReject() }
            .setOnCancelListener { onReject() }
            .show()
    }

    private fun showDownloadStarted(name: String) {
        Snackbar.make(b.root, getString(R.string.download_started, name), Snackbar.LENGTH_LONG)
            .setAction(R.string.view) { startActivity(Intent(this, DownloadsActivity::class.java)) }
            .setAnchorView(snackbarAnchor()).show()
    }

    /** Android 13+: asks once, in the context of the first download, for permission to show download notifications. */
    private fun maybeAskNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33 || !c.settings.downloadNotifications || c.settings.notifPermissionAsked) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        c.settings.notifPermissionAsked = true
        try { notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ find in page
    private fun setupFindBar() {
        b.findInput.addTextChangedListener { text -> if (findActive) runFind(text?.toString().orEmpty()) }
        b.findInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                findStep(true); true
            } else false
        }
        b.btnFindNext.setOnClickListener { findStep(true) }
        b.btnFindPrev.setOnClickListener { findStep(false) }
        b.btnFindClose.setOnClickListener { hideFindBar() }
    }

    private fun showFindBar() {
        val tab = tabs.active() ?: return
        if (!tab.data.url.startsWith("http")) return
        findActive = true
        findTabId = tab.id
        findUrl = tab.data.url
        b.findBar.visibility = View.VISIBLE
        b.findInput.requestFocus()
        b.findInput.selectAll()
        b.findInput.post {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(b.findInput, InputMethodManager.SHOW_IMPLICIT)
        }
        runFind(b.findInput.text.toString())
    }

    private fun hideFindBar() {
        if (!findActive) return
        findActive = false
        tabs.tab(findTabId)?.webView?.clearMatches()
        b.findBar.visibility = View.GONE
        b.findCount.text = ""
        b.findInput.setText("")                 // never carry a (possibly private) query over to another tab
        b.findInput.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(b.findInput.windowToken, 0)
    }

    private fun runFind(query: String) {
        val wv = tabs.tab(findTabId)?.webView ?: return
        if (query.isEmpty()) { wv.clearMatches(); b.findCount.text = ""; return }
        wv.findAllAsync(query)
    }

    private fun findStep(forward: Boolean) {
        tabs.tab(findTabId)?.webView?.findNext(forward)
    }

    override fun onFindResult(tab: BrowserTab, activeMatchOrdinal: Int, numberOfMatches: Int, isDoneCounting: Boolean) {
        ui.post {
            if (!findActive || tab.id != findTabId) return@post
            if (b.findInput.text.isNullOrEmpty()) { b.findCount.text = ""; return@post }
            b.findCount.text =
                if (numberOfMatches == 0) getString(R.string.find_no_match) else "${activeMatchOrdinal + 1}/$numberOfMatches"
        }
    }

    override fun showLinkMenu(tab: BrowserTab, linkUrl: String?, imageUrl: String?) {
        ui.post {
            val items = ArrayList<Pair<String, () -> Unit>>()
            if (linkUrl != null) {
                val clean = UrlCleaner.clean(linkUrl)
                items.add(getString(R.string.open_new_tab) to { tabs.newTab(clean, tab.isPrivate, select = false, openerId = tab.id) })
                items.add(getString(R.string.open_private_tab) to { tabs.newTab(clean, true, select = true) })
                items.add(getString(R.string.copy_link) to { copyText(clean) })
                items.add(getString(R.string.share) to { share(clean) })
            }
            if (imageUrl != null) {
                items.add(getString(R.string.download_image) to { onDownloadRequested(tab, imageUrl, null, null, null, -1) })
                items.add(getString(R.string.copy_image_url) to { copyText(imageUrl) })
            }
            if (items.isEmpty()) return@post
            MaterialAlertDialogBuilder(this)
                .setTitle((linkUrl ?: imageUrl)!!.take(80))
                .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
                .show()
        }
    }

    private fun copyText(t: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", t))
    }

    override fun promptHttpAuth(tab: BrowserTab, host: String, realm: String, handler: HttpAuthHandler) {
        ui.post {
            val user = EditText(this).apply { hint = getString(R.string.username); setSingleLine() }
            val pass = EditText(this).apply { hint = getString(R.string.password); setSingleLine(); inputType = 129 }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(48, 8, 48, 0)
                addView(user, LinearLayout.LayoutParams(-1, -2)); addView(pass, LinearLayout.LayoutParams(-1, -2))
            }
            MaterialAlertDialogBuilder(this).setTitle(getString(R.string.http_auth_title, host)).setMessage(realm).setView(box)
                .setPositiveButton(R.string.sign_in) { _, _ -> handler.proceed(user.text.toString(), pass.text.toString()) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> handler.cancel() }
                .setOnCancelListener { handler.cancel() }
                .show()
        }
    }
}
