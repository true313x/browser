package com.shieldbrowser.app.browser

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.privacy.PageScriptBuilder
import com.shieldbrowser.app.privacy.PageScriptConfig
import com.shieldbrowser.app.privacy.SiteScriptOverride
import com.shieldbrowser.app.settings.JsMode
import com.shieldbrowser.app.settings.Perm
import com.shieldbrowser.app.settings.SiteCookies
import java.security.SecureRandom

/** Single place that hardens and configures every WebView (see SECURITY.md > "Secure WebView configuration"). */
class WebViewConfigurator(
    private val app: Context,
    private val c: AppContainer,
    private val tabs: TabManager
) {
    private val template: String by lazy {
        try { app.assets.open("js/shield_core.js").bufferedReader().use { it.readText() } } catch (_: Exception) { "" }
    }
    private val builder by lazy { PageScriptBuilder(template) }
    /** New noise seed per app launch → fingerprint noise can't be linked across sessions. */
    private val seed = SecureRandom().nextInt()
    @Volatile private var cachedScript: String? = null

    val docStartSupported: Boolean
        get() = try { WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT) } catch (_: Throwable) { false }
    val messageListenerSupported: Boolean
        get() = try { WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER) } catch (_: Throwable) { false }

    /** blob: download helper (document-start, independent of the privacy shield). Loaded once. */
    private val blobTrackerScript: String by lazy {
        try { app.assets.open("js/blob_tracker.js").bufferedReader().use { it.readText() } } catch (_: Exception) { "" }
    }

    fun invalidateScript() { cachedScript = null }

    fun currentScript(): String = cachedScript ?: builder.build(scriptConfig()).also { cachedScript = it }

    private fun scriptConfig(): PageScriptConfig {
        val s = c.settings
        val ov = HashMap<String, SiteScriptOverride>()
        for (st in c.siteSettings.all()) {
            if (!st.shield || st.cookies == SiteCookies.BLOCK_ALL || st.clipboard == Perm.ALLOW || st.fingerprint >= 0) {
                ov[st.key] = SiteScriptOverride(
                    off = !st.shield, noCookie = st.cookies == SiteCookies.BLOCK_ALL,
                    allowClipboard = st.clipboard == Perm.ALLOW, fingerprintLevel = st.fingerprint
                )
            }
        }
        return PageScriptConfig(
            fingerprintLevel = s.fingerprintMode.level,
            referrerPolicy = s.referrerMode.policy,
            webRtc = s.webRtcMode.name.lowercase(),
            blockClipboardRead = s.blockClipboardRead,
            miningHeuristic = s.miningHeuristic,
            cosmetic = s.cosmeticFiltering,
            seed = seed,
            overrides = ov
        )
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    @Suppress("DEPRECATION")
    fun configure(tab: BrowserTab, wv: WebView) {
        val s = wv.settings
        // --- hardening ---------------------------------------------------------------------------
        s.javaScriptEnabled = true            // per-site JS policy is applied on every navigation (applySite)
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(true)
        s.setGeolocationEnabled(true)         // still gated by onGeolocationPermissionsShowPrompt + site settings
        s.saveFormData = false
        s.savePassword = false
        // --- usability ---------------------------------------------------------------------------
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.cacheMode = if (tab.isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        wv.isLongClickable = true

        applyGlobal(tab, wv)

        wv.webViewClient = TabWebViewClient(tab, tabs, c)
        wv.webChromeClient = TabWebChromeClient(tab, tabs, c)
        wv.setDownloadListener { url, ua, cd, mime, len -> tabs.host?.onDownloadRequested(tab, url, ua, cd, mime, len) }
        wv.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_UP)
                tab.lastTouchAt = System.currentTimeMillis()
            false
        }
        wv.setOnLongClickListener { handleLongClick(tab, wv) }
        wv.setFindListener { ordinal, count, done -> tabs.host?.onFindResult(tab, ordinal, count, done) }

        c.cookies.configure(tab, wv)

        if (messageListenerSupported) {
            try {
                WebViewCompat.addWebMessageListener(wv, "ShieldBridge", setOf("*"),
                    WebViewCompat.WebMessageListener { _, message, _, _, _ -> tabs.bridge.handle(tab, message.data) })
            } catch (_: Throwable) { /* counters just won't update */ }
            try {
                // blob: downloads: only sessions started by the app are accepted (see BlobDownloadManager).
                WebViewCompat.addWebMessageListener(wv, "ShieldDownload", setOf("*"),
                    WebViewCompat.WebMessageListener { _, message, sourceOrigin, isMainFrame, replyProxy ->
                        c.blobs.onMessage(tab, message.data, sourceOrigin, isMainFrame, replyProxy)
                    })
            } catch (_: Throwable) { /* blob: downloads will report "unsupported" */ }
        }
        registerScripts(tab, wv)
        registerBlobTracker(tab, wv)
    }

    /** Settings that can change at runtime (called again from TabManager.applyPrefsAll). */
    fun applyGlobal(tab: BrowserTab, wv: WebView) {
        val s = wv.settings
        s.textZoom = c.settings.textScale
        try { s.safeBrowsingEnabled = c.settings.safeBrowsing } catch (_: Throwable) {}
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING))
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, c.settings.forceDark)
        } catch (_: Throwable) {}
    }

    fun registerScripts(tab: BrowserTab, wv: WebView) {
        try { tab.scriptHandler?.remove() } catch (_: Throwable) {}
        tab.scriptHandler = null
        if (docStartSupported) {
            try { tab.scriptHandler = WebViewCompat.addDocumentStartJavaScript(wv, currentScript(), setOf("*")) } catch (_: Throwable) {}
        }
    }

    private fun registerBlobTracker(tab: BrowserTab, wv: WebView) {
        if (!docStartSupported || blobTrackerScript.isEmpty()) return
        try { tab.blobScriptHandler = WebViewCompat.addDocumentStartJavaScript(wv, blobTrackerScript, setOf("*")) } catch (_: Throwable) {}
    }

    /** Applies per-site JS / third-party-cookie / autoplay policy. Called before each top-level navigation. */
    fun applySite(tab: BrowserTab, wv: WebView, host: String?) {
        val site = c.siteSettings.get(host)
        val global = c.settings
        val js = when (site.js) {
            Perm.INHERIT -> global.jsDefault
            Perm.ALLOW -> JsMode.ALLOW
            Perm.BLOCK -> JsMode.BLOCK
            else -> JsMode.ASK
        }
        wv.settings.javaScriptEnabled = js == JsMode.ALLOW
        if (js == JsMode.ASK && host != null) tabs.host?.promptEnableJs(tab, host)
        c.cookies.applyForHost(tab, wv, host)
        val autoplay = if (site.autoplay == Perm.INHERIT) global.autoplayAllowed else site.autoplay == Perm.ALLOW
        wv.settings.mediaPlaybackRequiresUserGesture = !autoplay
    }

    private fun handleLongClick(tab: BrowserTab, wv: WebView): Boolean {
        val r = wv.hitTestResult
        val extra = r.extra
        when (r.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE -> { if (extra == null) return false; tabs.host?.showLinkMenu(tab, extra, null); return true }
            WebView.HitTestResult.IMAGE_TYPE -> { if (extra == null) return false; tabs.host?.showLinkMenu(tab, null, extra); return true }
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                val msg = Handler(Looper.getMainLooper()) { m ->
                    val link = m.data.getString("url")
                    val img = m.data.getString("src")
                    if (link != null) tabs.host?.showLinkMenu(tab, link, img)
                    true
                }.obtainMessage()
                wv.requestFocusNodeHref(msg)
                return true
            }
        }
        return false
    }
}
