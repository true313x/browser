package com.shieldbrowser.app.privacy

/** Per-site overrides baked into the injected script (keyed by registrable domain). */
data class SiteScriptOverride(
    val off: Boolean = false,
    val noCookie: Boolean = false,
    val allowClipboard: Boolean = false,
    val fingerprintLevel: Int = -1
)

data class PageScriptConfig(
    val fingerprintLevel: Int,
    val referrerPolicy: String?,
    val webRtc: String,
    val blockClipboardRead: Boolean,
    val miningHeuristic: Boolean,
    val cosmetic: Boolean,
    val seed: Int,
    val overrides: Map<String, SiteScriptOverride>
)

/**
 * Builds the document-start script (assets/js/shield_core.js prefixed with a JSON config).
 * The same script is injected into every frame via WebViewCompat.addDocumentStartJavaScript.
 */
class PageScriptBuilder(private val template: String) {

    fun build(cfg: PageScriptConfig): String = "var __SHIELD_CFG = " + configJson(cfg) + ";\n" + template

    fun configJson(cfg: PageScriptConfig): String {
        val sb = StringBuilder("{")
        sb.append("\"fp\":").append(cfg.fingerprintLevel)
        sb.append(",\"seed\":").append(cfg.seed)
        sb.append(",\"referrer\":").append(cfg.referrerPolicy?.let { q(it) } ?: "null")
        sb.append(",\"webrtc\":").append(q(cfg.webRtc))
        sb.append(",\"clip\":").append(cfg.blockClipboardRead)
        sb.append(",\"mining\":").append(cfg.miningHeuristic)
        sb.append(",\"cosmetic\":").append(cfg.cosmetic)
        sb.append(",\"ovr\":{")
        sb.append(cfg.overrides.entries.joinToString(",") { (host, o) ->
            q(host) + ":{\"off\":" + o.off + ",\"nocookie\":" + o.noCookie + ",\"clip\":" + o.allowClipboard + ",\"fp\":" + o.fingerprintLevel + "}"
        })
        sb.append("}}")
        return sb.toString()
    }

    private fun q(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '<' -> sb.append("\\u003c")
            c.code < 32 || c.code > 126 -> sb.append(String.format("\\u%04x", c.code))
            else -> sb.append(c)
        }
        return sb.append('"').toString()
    }
}
