package com.shieldbrowser.app.browser

import android.content.Intent
import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.HttpAuthHandler
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.privacy.EventType
import com.shieldbrowser.app.security.ExternalIntentGuard
import com.shieldbrowser.app.security.InterstitialKind
import com.shieldbrowser.app.security.Interstitials
import com.shieldbrowser.app.security.SecurityState
import com.shieldbrowser.app.settings.ExternalAppMode
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream

class TabWebViewClient(
    private val tab: BrowserTab,
    private val tabs: TabManager,
    private val c: AppContainer
) : WebViewClient() {

    private val settings get() = c.settings

    // ---------------------------------------------------------------- navigation policy
    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val uri = request.url
        val url = uri.toString()
        val scheme = uri.scheme?.lowercase() ?: return true

        if (!request.isForMainFrame) {
            return when (scheme) {
                "http", "https", "about", "blob", "data" -> false
                else -> { if (request.hasGesture()) handleExternal(url); true }
            }
        }
        return when (scheme) {
            "http", "https" -> handleWeb(view, request, url)
            "shield" -> { handleInternal(view, uri); true }
            "about" -> url != "about:blank"
            "blob" -> false
            "data", "javascript", "file", "content", "ftp" -> {
                tabs.record(tab, BlockEvent(EventType.REDIRECT, tab.pageHost.orEmpty(), url.take(120), detail = "blocked $scheme: navigation"))
                true
            }
            else -> { handleExternal(url); true }
        }
    }

    private fun handleWeb(view: WebView, request: WebResourceRequest, url: String): Boolean {
        val host = DomainUtils.hostOf(url)
        val from = tab.pageHost
        // Automatic (script-driven, no gesture) cross-site redirects after the page has loaded.
        if (settings.blockAutoRedirects && !request.hasGesture() && !request.isRedirect && tab.pageLoaded && !tab.internalPage &&
            host != null && from != null && DomainUtils.isThirdParty(host, from) &&
            System.currentTimeMillis() - tab.lastTouchAt > 1500
        ) {
            tabs.record(tab, BlockEvent(EventType.REDIRECT, host, url, detail = "automatic cross-site redirect"))
            val ctx = tabs.uiContext()
            tabs.host?.toast(ctx.getString(R.string.redirect_blocked, host), ctx.getString(R.string.allow_once)) { tabs.loadUrl(tab, url) }
            return true
        }
        val out = c.navPolicy.apply(tab, url)
        out.events.forEach { tabs.record(tab, it) }
        tabs.applySiteSettings(tab, DomainUtils.hostOf(out.url))
        if (out.url != url) { view.loadUrl(out.url); return true }
        return false
    }

    private fun handleExternal(url: String) {
        val ctx = tabs.uiContext()
        val mode = settings.externalApps
        tabs.record(tab, BlockEvent(EventType.EXTERNAL_APP, tab.pageHost.orEmpty(), url.take(160), detail = mode.name))
        if (mode == ExternalAppMode.BLOCK) return
        val intent = ExternalIntentGuard.toSafeIntent(url) ?: return
        val label = ExternalIntentGuard.describe(ctx, intent, url)
        val launch = { ExternalIntentGuard.launch(ctx, intent) }
        if (mode == ExternalAppMode.ALLOW) launch()
        else tabs.host?.confirmExternal(tab, label) { launch() }
    }

    private fun handleInternal(view: WebView, uri: android.net.Uri) {
        val nonce = uri.getQueryParameter("nonce")
        if (nonce.isNullOrEmpty() || nonce != tab.nonce) return          // forged / stale link → ignore
        val pending = tab.pendingUrl
        when (uri.host) {
            "search" -> uri.getQueryParameter("q")?.takeIf { it.isNotBlank() }?.let { tabs.navigate(tab, it) }
            "action" -> when (uri.getQueryParameter("do")) {
                "back" -> if (view.canGoBack()) view.goBack() else tabs.showStart(tab)
                "ssl_continue" -> if (pending != null) { DomainUtils.hostOf(pending)?.let { tab.sslExceptions.add(it) }; tabs.loadUrl(tab, pending) }
                "http_continue" -> if (pending != null) { DomainUtils.hostOf(pending)?.let { tab.httpAllowed.add(it) }; tabs.loadUrl(tab, pending) }
                "block_continue" -> if (pending != null) { DomainUtils.hostOf(pending)?.let { tab.blockAllowed.add(it) }; tabs.loadUrl(tab, pending) }
                "retry" -> if (pending != null) tabs.loadUrl(tab, pending)
            }
        }
    }

    // ---------------------------------------------------------------- request interception
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val uri = request.url
        val scheme = uri.scheme ?: return null
        if (scheme != "http" && scheme != "https") return null
        val host = uri.host?.lowercase() ?: return null
        val url = uri.toString()
        val main = request.isForMainFrame
        if (main) {
            tab.pageHost = host
            tab.lastHeaders = request.requestHeaders ?: emptyMap()
        }
        if (settings.developerMode) tabs.logRequest(tab, request)
        if (main && host in tab.blockAllowed) { tab.blockedUrl = null; return null }

        val d = c.ruleEngine.evaluate(url, tab.pageHost, main)
        if (!d.block) { if (main) tab.blockedUrl = null; return null }
        tabs.record(tab, BlockEvent(EventType.BLOCKED_REQUEST, host, url, d.category, d.rule, d.thirdParty))

        if (main) {
            tab.forcedSecurity = SecurityState.WARNING
            tab.blockedUrl = url
            tab.pendingUrl = url
            val ctx = tabs.uiContext()
            val kind = if (d.category == BlockCategory.CRYPTOMINING) InterstitialKind.MINER else InterstitialKind.MALWARE
            val html = Interstitials.page(ctx, kind, url, d.rule.orEmpty(), tabs.newNonce(tab))
            return WebResourceResponse(
                "text/html", "utf-8", 200, "OK",
                mapOf("Cache-Control" to "no-store", "Content-Security-Policy" to "default-src 'none'; style-src 'unsafe-inline'"),
                ByteArrayInputStream(html.toByteArray(Charsets.UTF_8))
            )
        }
        return WebResourceResponse(
            "text/plain", "utf-8", 403, "Blocked by Ormus",
            mapOf("Cache-Control" to "no-store"), ByteArrayInputStream(ByteArray(0))
        )
    }

    // ---------------------------------------------------------------- page lifecycle
    override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
        tab.loading = true
        tab.pageLoaded = false
        if (!url.startsWith(Interstitials.INTERNAL_BASE)) {
            tab.internalPage = false
            tab.forcedSecurity = null
            tab.data.url = url
            tab.stats.reset()
            val host = DomainUtils.hostOf(url)
            tab.pageHost = host
            if (!tab.isPrivate && host != null) c.sessionReport.visit(host)
            tab.security = if (url.startsWith("https://")) SecurityState.NONE else SecurityState.INSECURE
            tabs.applySiteSettings(tab, host)
            if (!tabs.configurator.docStartSupported) view.evaluateJavascript(tabs.configurator.currentScript(), null)
        }
        tabs.host?.onTabChanged(tab)
    }

    override fun onPageFinished(view: WebView, url: String) {
        tab.loading = false
        tab.pageLoaded = true
        tab.progress = 100
        if (!tab.internalPage) {
            tab.data.title = view.title.orEmpty()
            val blocked = tab.blockedUrl == url            // this "page" is our block interstitial, not the real site
            if (blocked) tab.forcedSecurity = SecurityState.WARNING
            updateSecurity(view, url)
            if (!blocked) c.cookies.afterPageFinished(tab, url)
            if (!blocked && !tab.isPrivate && settings.historyEnabled && (url.startsWith("http://") || url.startsWith("https://"))) {
                val title = tab.data.title
                c.scope.launch { c.history.add(url, title) }
            }
        }
        tabs.host?.onTabChanged(tab)
    }

    override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
        if (!url.startsWith(Interstitials.INTERNAL_BASE) && !tab.internalPage) tab.data.url = url
        tabs.host?.onTabChanged(tab)
    }

    private fun updateSecurity(view: WebView, url: String) {
        tab.security = tab.forcedSecurity ?: when {
            url.startsWith("https://") -> {
                val host = DomainUtils.hostOf(url).orEmpty()
                if (host in tab.sslExceptions) SecurityState.WARNING
                else if (view.certificate != null) SecurityState.SECURE else SecurityState.WARNING
            }
            url.startsWith("http://") -> SecurityState.INSECURE
            else -> SecurityState.NONE
        }
    }

    // ---------------------------------------------------------------- errors
    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
        if (!request.isForMainFrame) return
        if (System.currentTimeMillis() - tab.sslErrorAt < 3000) return
        if (error.errorCode == ERROR_UNSUPPORTED_SCHEME || error.errorCode == ERROR_UNKNOWN && error.description.isNullOrEmpty()) return
        val url = request.url.toString()
        val host = request.url.host?.lowercase()
        val ctx = tabs.uiContext()
        val fallback = url.startsWith("https://") && host != null && tab.upgradedHost == host
        tab.pendingUrl = if (fallback) "http://" + url.removePrefix("https://") else url
        val kind = if (fallback) InterstitialKind.HTTPS_FALLBACK else InterstitialKind.LOAD_ERROR
        val details = "${error.description} (code ${error.errorCode})"
        tabs.loadInternal(
            tab, Interstitials.page(ctx, kind, url, details, tabs.newNonce(tab)), url,
            if (fallback) SecurityState.WARNING else SecurityState.NONE
        )
    }

    override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
        val url = error.url ?: view.url.orEmpty()
        val host = DomainUtils.hostOf(url).orEmpty()
        if (host in tab.sslExceptions) {            // user explicitly continued for this host in this tab
            tab.forcedSecurity = SecurityState.WARNING
            handler.proceed()
            return
        }
        handler.cancel()                              // NEVER proceed silently
        tabs.record(tab, BlockEvent(EventType.INSECURE, host, url, detail = "TLS error ${error.primaryError}"))
        if (host != tab.pageHost) return              // third-party sub-resource: just fail the request
        tab.sslErrorAt = System.currentTimeMillis()
        tab.pendingUrl = url
        val ctx = tabs.uiContext()
        val why = when (error.primaryError) {
            SslError.SSL_UNTRUSTED -> R.string.ssl_err_untrusted
            SslError.SSL_EXPIRED -> R.string.ssl_err_expired
            SslError.SSL_IDMISMATCH -> R.string.ssl_err_mismatch
            SslError.SSL_NOTYETVALID -> R.string.ssl_err_not_yet_valid
            else -> R.string.ssl_err_other
        }
        tabs.loadInternal(
            tab, Interstitials.page(ctx, InterstitialKind.SSL, url, ctx.getString(why), tabs.newNonce(tab)), url, SecurityState.WARNING
        )
    }

    override fun onReceivedHttpAuthRequest(view: WebView, handler: HttpAuthHandler, host: String, realm: String) {
        val h = tabs.host
        if (h == null) handler.cancel() else h.promptHttpAuth(tab, host, realm, handler)
    }

    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
        tabs.onRenderGone(tab)
        return true
    }
}
