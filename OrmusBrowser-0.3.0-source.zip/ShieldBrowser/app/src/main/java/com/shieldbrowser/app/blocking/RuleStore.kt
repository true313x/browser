package com.shieldbrowser.app.blocking

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import com.shieldbrowser.app.network.DnsProvider
import java.io.File

/** Loads built-in assets + user-imported lists (filesDir/rules/*.txt) into a [RuleEngine]. */
class RuleStore(private val context: Context) {
    private val dir get() = File(context.filesDir, "rules").also { it.mkdirs() }

    private fun asset(name: String): String =
        try { context.assets.open("rules/$name").bufferedReader().use { it.readText() } } catch (_: Exception) { "" }

    fun loadInto(engine: RuleEngine) {
        val domains = HashMap<String, BlockCategory>()
        domains.putAll(RuleListParser.parseDomains(asset("domains.txt"), BlockCategory.TRACKING).domains)
        dir.listFiles { f -> f.extension == "txt" }?.forEach { f ->
            domains.putAll(RuleListParser.parseDomains(f.readText(), BlockCategory.TRACKING).domains)
        }
        val essential = RuleListParser.parseDomains(asset("essential.txt"), BlockCategory.ESSENTIAL).domains.keys
        // Imported lists can never override essential infrastructure.
        essential.forEach { domains.remove(it) }
        engine.load(domains, PatternParser.parse(asset("patterns.txt")), essential)
    }

    /** Stores a normalised copy of an imported list; returns the number of domain rules accepted. */
    fun saveImported(name: String, text: String, category: BlockCategory): Int {
        if (RuleListParser.looksLikeHtml(text)) return 0              // captive portal / error page, not a list
        val parsed = RuleListParser.parseDomains(text, category)
        if (parsed.domains.isEmpty()) return 0
        val safe = name.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(40).ifEmpty { "list" }
        // Atomic replace: a crash mid-write must never leave a truncated list that is loaded on the next start.
        val target = File(dir, "$safe.txt")
        val tmp = File(dir, "$safe.txt.tmp")
        tmp.writeText(parsed.domains.entries.joinToString("\n") { "${it.key} ${it.value.key}" })
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) { tmp.delete(); throw java.io.IOException("could not store rule list") }
        }
        return parsed.domains.size
    }

    fun importedFiles(): List<String> = dir.listFiles { f -> f.extension == "txt" }?.map { it.nameWithoutExtension }.orEmpty()
    fun clearImported() { dir.listFiles()?.forEach { it.delete() } }
}

/** User-initiated list import (URL must be https). Nothing is fetched automatically. */
class RuleUpdater(private val dns: DnsProvider, private val store: RuleStore, private val engine: RuleEngine) {
    suspend fun importFromUrl(url: String, category: BlockCategory): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            require(url.startsWith("https://")) { "https only" }
            val req = Request.Builder().url(url).header("User-Agent", "OrmusBrowser-ListImport").build()
            val text = dns.client().newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("HTTP ${r.code}")
                val body = r.body ?: error("empty")
                if (body.contentLength() > 15_000_000L) error("list too large")
                val source = body.source()
                source.request(15_000_001L)                      // buffers at most this much, even for chunked responses
                if (source.buffer.size > 15_000_000L) error("list too large")
                source.readUtf8()
            }
            val name = url.substringAfter("://").substringBefore('/').replace('.', '-') + "-" + (url.hashCode() and 0xffff)
            val n = store.saveImported(name, text, category)
            store.loadInto(engine)
            n
        }
    }

    suspend fun importFromText(name: String, text: String, category: BlockCategory): Int = withContext(Dispatchers.IO) {
        val n = store.saveImported(name, text, category)
        store.loadInto(engine)
        n
    }
}
