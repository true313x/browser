package com.shieldbrowser.app.network

import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.DnsMode
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.io.IOException
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * HTTP client for the app's OWN traffic (downloads, optional blocklist import) with System / Secure (DoH) / Custom DNS.
 *
 * HONEST LIMITATION: Android WebView does not expose a DNS API. Page loads in the WebView keep using the
 * system resolver (and Android's "Private DNS" setting, which we link to from Settings > DNS).
 * This setting therefore protects downloads and list updates only.
 */
class DnsProvider(private val settings: BrowserSettings) {
    data class Provider(val id: String, val name: String, val url: String, val bootstrap: List<String>)

    companion object {
        val providers = listOf(
            Provider("cloudflare", "Cloudflare", "https://cloudflare-dns.com/dns-query", listOf("1.1.1.1", "1.0.0.1")),
            Provider("quad9", "Quad9", "https://dns.quad9.net/dns-query", listOf("9.9.9.9", "149.112.112.112")),
            Provider("mullvad", "Mullvad", "https://dns.mullvad.net/dns-query", listOf("194.242.2.2"))
        )
    }

    @Volatile private var cached: OkHttpClient? = null

    fun invalidate() { cached = null }

    fun client(): OkHttpClient = cached ?: build().also { cached = it }

    private fun build(): OkHttpClient {
        // SECURE / CUSTOM are STRICT: an invalid configuration or an unreachable resolver makes lookups FAIL.
        // There is deliberately no fallback to the system resolver (that would silently leak the very queries
        // the user asked to protect). Only DnsMode.SYSTEM uses the system resolver.
        val dns: Dns = when (settings.dnsMode) {
            DnsMode.SYSTEM -> Dns.SYSTEM
            DnsMode.SECURE -> providers.firstOrNull { it.id == settings.dnsProvider }
                ?.let { doh(it.url, it.bootstrap) } ?: FailClosedDns("unknown DNS provider")
            DnsMode.CUSTOM -> when (val v = DohEndpoint.validate(settings.dnsCustomUrl)) {
                is DohEndpoint.Result.Valid -> doh(v.url, emptyList())
                is DohEndpoint.Result.Invalid -> FailClosedDns("custom DoH endpoint rejected: ${v.reason}")
            }
        }
        // Remember the scheme/host of the ORIGINAL request; the tag survives OkHttp's redirect follow-ups.
        val tagger = Interceptor { chain ->
            val r = chain.request()
            chain.proceed(r.newBuilder().tag(Origin::class.java, Origin(r.isHttps, r.url.host)).build())
        }
        // Network interceptors see every hop BEFORE it is sent (an application interceptor only sees the final
        // response, i.e. after a plaintext request was already made).
        val hopGuard = Interceptor { chain ->
            val r = chain.request()
            val origin = r.tag(Origin::class.java)
            if (origin != null && origin.https && !r.isHttps) throw IOException("HTTPS downgrade blocked")
            // A Cookie header we attached for host A must never be replayed to host B after a redirect.
            if (origin != null && r.url.host != origin.host && r.header("Cookie") != null) {
                chain.proceed(r.newBuilder().removeHeader("Cookie").build())
            } else chain.proceed(r)
        }
        return OkHttpClient.Builder()
            .dns(dns)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(tagger)
            .addNetworkInterceptor(hopGuard)
            .build()
    }

    private class Origin(val https: Boolean, val host: String)

    /** Why strict secure DNS cannot work with the current settings, or null if it is configured correctly (or not used). */
    fun configurationError(): String? = when (settings.dnsMode) {
        DnsMode.SYSTEM -> null
        DnsMode.SECURE -> if (providers.any { it.id == settings.dnsProvider }) null else "unknown DNS provider"
        DnsMode.CUSTOM -> (DohEndpoint.validate(settings.dnsCustomUrl) as? DohEndpoint.Result.Invalid)?.reason
    }

    private fun doh(url: String, bootstrap: List<String>): Dns {
        val httpUrl = url.toHttpUrlOrNull() ?: return FailClosedDns("unparseable DoH URL")
        if (!httpUrl.isHttps) return FailClosedDns("DoH endpoint must use https")
        val builder = DnsOverHttps.Builder().client(OkHttpClient.Builder().build()).url(httpUrl).includeIPv6(true)
        if (bootstrap.isNotEmpty()) builder.bootstrapDnsHosts(bootstrap.map { InetAddress.getByName(it) })
        return builder.build()
    }
}

/** Resolver used when strict secure DNS is selected but cannot be used: every lookup fails (no silent downgrade). */
class FailClosedDns(private val reason: String) : Dns {
    override fun lookup(hostname: String): List<InetAddress> =
        throw UnknownHostException("Secure DNS unavailable ($reason). Not falling back to the system resolver.")
}
