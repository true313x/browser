/* Ormus Browser — on-demand blob: download reader. Evaluated by the app in the MAIN frame of the tab that started
 * the download. %URL%, %SID% and %CHUNK% are replaced natively (URL as an escaped JS string literal).
 * Protocol over window.ShieldDownload (WebMessageListener); every message is one string:
 *   page → app   M|sid|size|type|name   metadata (type/name percent-encoded)   app → page   <sid>:go | <sid>:abort
 *                C|sid|seq|base64       one chunk; the page waits for        app → page   <sid>:ack | <sid>:abort
 *                D|sid                  finished
 *                E|sid|message          failed (message percent-encoded)
 * The page never gets more than one chunk in flight, so a slow disk back-pressures the page instead of filling memory. */
(function (url, sid, CH) {
  'use strict';
  var B = window.ShieldDownload;
  if (!B || typeof B.postMessage !== 'function') { return; }
  var waiter = null;
  function onMsg(ev) {
    var d = String(ev && ev.data);
    var i = d.indexOf(':');
    if (i < 0 || d.slice(0, i) !== sid) { return; }
    var w = waiter; waiter = null;
    if (w) { w(d.slice(i + 1)); }
  }
  B.addEventListener('message', onMsg);
  function next() { return new Promise(function (res) { waiter = res; }); }
  function send(s) { B.postMessage(s); }
  function readB64(blob) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onerror = function () { rej(new Error('read failed')); };
      fr.onload = function () { var r = String(fr.result); res(r.substring(r.indexOf(',') + 1)); };
      fr.readAsDataURL(blob);
    });
  }
  (async function () {
    try {
      var reg = window.__shieldBlobs;
      var blob = reg && reg.get ? reg.get(url) : null;
      if (!blob) {
        var r = await fetch(url);
        if (!r.ok) { throw new Error('HTTP ' + r.status); }
        blob = await r.blob();
      }
      var name = (reg && reg.name) ? (reg.name(url) || '') : '';
      send('M|' + sid + '|' + blob.size + '|' + encodeURIComponent(blob.type || '') + '|' + encodeURIComponent(name));
      if ((await next()) !== 'go') { return; }
      var off = 0, seq = 0;
      while (off < blob.size) {
        var b64 = await readB64(blob.slice(off, off + CH));
        send('C|' + sid + '|' + (seq++) + '|' + b64);
        off += CH;
        if ((await next()) !== 'ack') { return; }
      }
      send('D|' + sid);
    } catch (e) {
      try { send('E|' + sid + '|' + encodeURIComponent(String((e && e.message) || e).slice(0, 100))); } catch (x) {}
    } finally {
      B.removeEventListener('message', onMsg);
    }
  })();
})(%URL%, %SID%, %CHUNK%);
