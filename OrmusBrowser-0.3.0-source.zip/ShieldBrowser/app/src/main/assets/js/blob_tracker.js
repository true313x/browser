/* Ormus Browser — blob: download helper, document-start script (all frames, independent of the privacy shield).
 * WebView reports a blob: download only as a URL, long after the page may have revoked it. This script remembers the
 * Blob objects behind URL.createObjectURL() for a short time and the file name from <a download="...">, so the app
 * can later ask the page to stream the bytes (see blob_fetch.js). It sends nothing by itself. */
(function () {
  'use strict';
  try {
    if (window.__shieldBlobs) { return; }
    var MAX = 12, TTL = 180000, GRACE = 60000;
    var blobs = new Map();   // blob: URL -> { blob, t }
    var names = new Map();   // blob: URL -> suggested file name (download attribute)

    function prune() {
      var now = Date.now();
      blobs.forEach(function (v, k) { if (now - v.t > TTL) { blobs.delete(k); } });
      while (blobs.size > MAX) { blobs.delete(blobs.keys().next().value); }
      while (names.size > 50) { names.delete(names.keys().next().value); }
    }

    var origCreate = URL.createObjectURL;
    var origRevoke = URL.revokeObjectURL;
    URL.createObjectURL = function (obj) {
      var u = origCreate.apply(this, arguments);
      try { if (obj instanceof Blob) { blobs.set(u, { blob: obj, t: Date.now() }); prune(); } } catch (e) {}
      return u;
    };
    URL.revokeObjectURL = function (u) {
      // Pages often revoke right after click(); keep the Blob a little longer for the pending download request.
      try { var e = blobs.get(u); if (e) { e.t = Date.now(); setTimeout(function () { blobs.delete(u); }, GRACE); } } catch (x) {}
      return origRevoke.apply(this, arguments);
    };

    function note(a) {
      try {
        if (a && a.hasAttribute && a.hasAttribute('download')) {
          var h = a.href;
          if (typeof h === 'string' && h.indexOf('blob:') === 0) { names.set(h, a.getAttribute('download') || ''); }
        }
      } catch (e) {}
    }
    var AP = window.HTMLAnchorElement && HTMLAnchorElement.prototype;
    if (AP) {
      var origClick = AP.click;
      AP.click = function () { note(this); return origClick.apply(this, arguments); };
      ['href', 'download'].forEach(function (prop) {
        try {
          var d = Object.getOwnPropertyDescriptor(AP, prop);
          if (d && d.set) {
            Object.defineProperty(AP, prop, { configurable: true, enumerable: d.enumerable, get: d.get, set: function (v) { d.set.call(this, v); note(this); } });
          }
        } catch (e) {}
      });
    }
    document.addEventListener('click', function (ev) {
      try { note(ev.target && ev.target.closest ? ev.target.closest('a') : null); } catch (e) {}
    }, true);

    Object.defineProperty(window, '__shieldBlobs', {
      value: {
        get: function (u) { var e = blobs.get(u); return e ? e.blob : null; },
        name: function (u) { return names.get(u) || ''; }
      },
      enumerable: false
    });
  } catch (e) {}
})();
