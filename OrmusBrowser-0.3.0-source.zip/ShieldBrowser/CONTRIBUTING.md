# Contributing

1. Fork, create a branch, keep changes focused.
2. Run `gradle :app:testDebugUnitTest` (JVM tests) before opening a PR; add tests for logic that doesn't need Android
   (rules, URL handling, tab model, download safety live in pure-Kotlin classes for that reason).
3. **Privacy rules for contributors:** no analytics/telemetry/crash-reporting SDKs, no network calls that the user did not trigger,
   no advertising IDs, no new permissions without a clear user-facing feature. Be honest in docs: label a feature *Real*,
   *Best-effort* or *Not possible in the current engine*; never claim anonymity or 100 % protection, never report a build or test as passing unless it was run.
   No chatbots/AI agents, and no User-Agent or device-identity switching.
4. Keep modules decoupled (UI → browser/tabs → privacy/blocking/security → storage/network). New strings go in `values`, `values-ar`, `values-fa`.
5. Never commit keystores, `google-services.json`, tokens or passwords.
6. By contributing you agree your work is licensed under the MIT License.

Ideas that help most: bigger/cleaner blocklists, more tests, translations review (ar/fa), accessibility checks (TalkBack, large text, RTL), tablet layout.
