# Ormus Browser — repository audit and GeckoView migration plan

> **Status of this document: planning + audit. As of this commit the app still runs on Android WebView.
> No GeckoView code has been written.**
>
> **How it was produced / how far to trust it.** The audit was done by reading the source. The environment had **no
> Android SDK, no Gradle, no Kotlin compiler and no network**, so nothing here was compiled, run or checked against
> the GeckoView Javadoc. GeckoView API names below are written from knowledge of the upstream project and are tagged
> **(verify)**: confirm every one against the Javadoc of the exact release you pin
> (<https://mozilla.github.io/geckoview/>) before coding against it.

---

## 1. Audit summary (facts)

| Item | Finding |
|---|---|
| Code base | ~7.6 k lines Kotlin, one `:app` module, View/XML UI (no Compose), manual DI (`AppContainer`), SQLite via `SQLiteOpenHelper`, `androidx.preference` settings screens. |
| **Has it ever compiled?** | **No.** The original README states it was written without a compiler. Treat the first real build as untested. |
| Toolchain | AGP 8.5.2, Kotlin 1.9.24, Gradle 8.7 (wrapper *jar* not committed), compileSdk/targetSdk 34, minSdk 26, JVM 17. |
| Dependencies | AndroidX, Material 1.12, `androidx.webkit` 1.12.1, coroutines, OkHttp 4.12 (+DoH). No analytics/ads/crash SDKs. |
| Engine | System WebView (Chromium). 12 files import `android.webkit`/`androidx.webkit`. |
| Tests | 11 JVM test classes (≈ 100 tests), 5 instrumented classes. **None has been executed** in this audit. |
| CI | `.github/workflows/build.yml` (unit tests + `assembleDebug`, pinned Gradle). No release job, no lint gate. |
| Logging | No `Log.*`/`println` calls in `main`; nothing sensitive can leak through logcat. |

**Recommendation #1 (gating):** before any engine work, run `gradle :app:testDebugUnitTest :app:assembleDebug` on a
machine with the Android SDK and fix whatever the never-compiled baseline produces. Migrating a codebase that has
never built multiplies unknowns.

## 2. Current architecture

```
MainActivity (View/XML, implements BrowserHost)
   └─ TabManager (app-scoped; owns one WebView per tab, MutableContextWrapper trick for rotation)
        ├─ WebViewConfigurator  → hardening, JS injection (addDocumentStartJavaScript), WebMessageListeners
        ├─ TabWebViewClient     → shouldOverrideUrlLoading / shouldInterceptRequest (blocking!) / SSL / errors
        ├─ TabWebChromeClient   → popups, permissions, file chooser, fullscreen, JS dialogs
        ├─ ProfileManager       → WebView multi-profile (private tabs, strict isolation)
        └─ NavigationPolicy, ScriptBridge, BrowserTab (runtime state)
privacy/ blocking/ security/ downloads/ settings/ storage/ network/  (mostly engine-independent)
```

### Engine-independent code that survives the migration unchanged
`blocking/*` (rule model, parser, `DomainUtils`), `privacy/UrlCleaner`, `browser/UrlInput`, `SearchEngines`,
`tabs/TabList`, `security/ExternalIntentGuard`, `downloads/DownloadSafety`, `storage/*`, `history/*`, `bookmarks/*`,
`settings/*` (except engine toggles), `network/*`. These have the JVM tests.

### WebView-coupled code (must be rewritten)
`browser/{TabManager, WebViewConfigurator, TabWebViewClient, TabWebChromeClient, ProfileManager, BrowserTab,
BrowserHost}`, `ui/MainActivity` (807 lines), `ui/DevToolsActivity`, `privacy/CookieController`,
`downloads/BlobDownloadManager` (+ `BlobProtocol`, `assets/js/blob_*.js`), `assets/js/shield_core.js`
(JS is reusable as content-script material, the injection mechanism is not), manifest `WebView.*` meta-data.

## 3. Feature → GeckoView mapping

Legend: ✅ documented equivalent · ⚠ equivalent differs / needs design · ❌ no equivalent (decision needed).

| Feature | Today (WebView) | GeckoView approach | |
|---|---|---|---|
| Engine lifetime | one `WebView` per tab | **one `GeckoRuntime` per process** (create in `Application`), one `GeckoSession` per tab, `GeckoView.setSession()` for the visible tab, `session.close()` on tab close | ✅ |
| Navigation | `loadUrl/goBack/reload/stopLoading` | `session.loadUri/goBack/goForward/reload/stop`; `NavigationDelegate.onLocationChange/onCanGoBack/onCanGoForward` | ✅ |
| Progress / title / security | `WebViewClient`, `WebChromeClient` | `ProgressDelegate.onPageStart/onPageStop/onProgressChange/onSecurityChange`, `ContentDelegate.onTitleChange` | ✅ |
| Tab state restore | `saveState/restoreState(Bundle)` | `ProgressDelegate.onSessionStateChange(SessionState)` → persist; `session.restoreState()`. Keep the "N live sessions, freeze the rest" policy | ✅ (verify serialisation) |
| Private browsing | `WebViewCompat.setProfile` (multi-profile) | `GeckoSessionSettings.usePrivateMode(true)` (own cookies/cache, nothing persisted); optional per-tab `contextId` for strict isolation | ✅ — simpler than today |
| **Request interception (ad/tracker blocking)** | `shouldInterceptRequest` sees **every** sub-resource | **No per-request hook in the embedding API.** Options: (a) Gecko ETP / `ContentBlocking.Settings` (Disconnect lists), (b) a **built-in WebExtension** using `webRequest.onBeforeRequest` blocking (the mechanism Firefox for Android's extension ecosystem, e.g. uBlock Origin, relies on) fed by the Kotlin rule engine over native messaging; must be enabled for private sessions (`WebExtensionController.setAllowedInPrivateBrowsing`) | ⚠ core redesign |
| Blocked-request statistics | counted where the engine returns a block | extension counts **only** requests it actually cancelled + `ContentBlocking.Delegate.onContentBlocked` for ETP; report the two sources separately | ⚠ |
| Cosmetic filtering | injected CSS via script | extension content script (`document_start`) injecting CSS | ⚠ |
| Document-start JS (fingerprint mitigations) | `addDocumentStartJavaScript` | ❌ no embedding API; use extension content scripts (`run_at: document_start`, MAIN world needs a recent Gecko — verify) **and** Gecko's native protections first | ⚠ |
| JS ↔ native bridge | `WebMessageListener` | extension `runtime.sendNativeMessage/connectNative` ↔ `WebExtension.MessageDelegate`. No `@JavascriptInterface` equivalent exists, which is a security plus | ⚠ |
| Top-level navigation policy / redirects | `shouldOverrideUrlLoading` (+ `hasGesture`) | `NavigationDelegate.onLoadRequest` (returns `AllowOrDeny`; check what gesture info the pinned version provides — verify) | ⚠ |
| Popups / new windows | `onCreateWindow` + transport | `NavigationDelegate.onNewSession` (return a new `GeckoSession` or deny). Gecko has its own popup blocker (verify default) | ✅ |
| Permissions | `onPermissionRequest`, geolocation prompt | `PermissionDelegate.onContentPermissionRequest / onMediaPermissionRequest / onAndroidPermissionsRequest` | ✅ |
| JS dialogs, file chooser, auth | `onJs*`, `onShowFileChooser`, `HttpAuthHandler` | `PromptDelegate` (alert/button/text/file/auth/popup/beforeUnload) | ✅ |
| Find in page | `findAllAsync/findNext` | `session.finder` (`SessionFinder.find/clear`, `FinderResult`) | ✅ |
| Fullscreen video | `onShowCustomView` | `ContentDelegate.onFullScreen` | ✅ |
| Per-site JS on/off | `settings.javaScriptEnabled` | `GeckoSessionSettings.allowJavascript` (verify per-session mutability) | ✅ |
| Cookies policy | `CookieManager` (+ best-effort per-site hacks) | `ContentBlocking.Settings.cookieBehavior` (incl. first-party isolation / "total cookie protection"), per-site ETP exceptions via `ContentBlockingController` | ✅ — real, not best-effort |
| Clear data / per-site / on exit | `CookieManager`, `WebStorage` | `StorageController.clearData(flags)` and per-host/base-domain variants (verify exact names) | ✅ |
| HTTPS-only | in-app upgrade + interstitial | `GeckoRuntimeSettings.allowInsecureConnections` (HTTPS-only modes) (verify); keep own interstitial only if needed | ✅ |
| TLS errors | `onReceivedSslError` (cancel / per-host proceed) | `NavigationDelegate.onLoadError` with a security-category `WebRequestError`; `onSecurityChange` for the indicator. **A certificate-override flow is not assumed to exist for embedders** — v1 never offers "continue anyway" (stricter than today; revisit only after verifying an API) | ⚠ |
| Page traffic trust store | Android system CAs + Network Security Config | **Gecko uses its own NSS / root store.** Android NSC no longer applies to page traffic | ⚠ doc change |
| DNS / secure DNS | system resolver only (DoH for app's own OkHttp traffic) | **Gecko TRR (DoH)** through `GeckoRuntimeSettings` (`trustedRecursiveResolverMode/Uri`, bootstrap address; mode "only" = no fallback) (verify names) → first time page traffic can actually use DoH | ✅ |
| Downloads | `DownloadListener` → OkHttp | `ContentDelegate.onExternalResponse(WebResponse)` (stream) and/or `GeckoWebExecutor.fetch()` so DNS/TLS/cookies use Gecko's stack. `blob:` should arrive as a normal response → **`BlobDownloadManager` and the blob JS helpers are expected to become obsolete** (verify) | ⚠ |
| History | `onPageFinished` writes DB | `HistoryDelegate.onVisited/getVisited` (not for private sessions — still guard in app code) | ✅ |
| Crashes | `onRenderProcessGone` | `ContentDelegate.onCrash/onKill` (recreate/reload session), `GeckoRuntimeSettings.crashHandler` for the main process | ✅ |
| Text zoom / dark mode | `textZoom`, algorithmic darkening | `fontSizeFactor`, `preferredColorScheme` | ✅ |
| WebRTC IP exposure | JS patching | Gecko prefs (e.g. ICE default-address / no-host) or `privacy.network.webRTCIPHandlingPolicy` from the extension (verify availability) | ⚠ |
| Client Hints | headers from Chromium | Gecko does not implement UA Client Hints (verify for pinned version) — nothing to strip | ✅ |
| User-Agent | profile manager | **Removed** (prohibited by project rules). Engine-defined UA only | — |
| Safe Browsing | Google, opt-in | `ContentBlocking` safe-browsing lists contact Google/Mozilla services → default **off**, document; local deterministic lists instead | ⚠ |
| Internal pages (`shield://`, interstitials) | `loadDataWithBaseURL` + nonce links | packaged `resource://android/assets/…` pages or `onLoadError` custom pages; links handled in `onLoadRequest`, keep nonce | ⚠ |

## 4. Design decisions and why

1. **Blocking moves into an extension, rules stay in Kotlin.** Parsing, validation, dedup, versioning and unit tests stay in
   the pure-Kotlin engine; a *compiled* representation (host set + token-indexed patterns, exceptions, options) is pushed to a
   small built-in MV2 extension that cancels requests. Duplicating the parser in JS would diverge.
2. **Prefer Gecko-native protections over JS patching** for fingerprinting/tracking (ETP, cookie isolation, fingerprinting
   protection/resist-fingerprinting prefs where `GeckoRuntimeSettings` or the preference controller exposes them — verify).
   The existing JS mitigations become an *optional, documented best-effort* layer, never claimed as complete.
3. **Certificate errors are never bypassable in v1.**
4. **Strict DNS means strict.** TRR "only" mode, valid https endpoint, bootstrap address; no silent downgrade (already
   implemented for the app's own traffic in this commit: `FailClosedDns`, `DohEndpoint`).
5. **Do not mix big changes.** Gecko inside the existing View UI first, Compose second.

## 5. Staged plan (compile + test after every stage)

| Stage | Work | Exit criterion |
|---|---|---|
| **G0** | Build the *current* WebView app on a dev machine; fix baseline compile errors; run the 11 JVM test classes | `testDebugUnitTest` + `assembleDebug` green |
| G1 | Add Mozilla Maven repo (`https://maven.mozilla.org/maven2/` — `FAIL_ON_PROJECT_REPOS` is on, so it must be added in `settings.gradle.kts` with a `content { includeGroup("org.mozilla.geckoview") }` filter), pin a **stable** GeckoView release, ABI splits, R8 rules, `GeckoRuntime` singleton in `ShieldApp` | App launches and renders a local page |
| G2 | `BrowserTab.session`, `TabManager` create/select/close/restore on `GeckoSession`; navigation + progress + title + security delegates; remove `WebView` from layouts | Navigate, back/forward, tabs, rotation, process recreation |
| G3 | Private sessions, history delegate, permissions, prompts, popups, find, fullscreen, downloads (`onExternalResponse`), crash handling | P1 list of the project spec passes manually |
| G4 | Built-in extension: `webRequest` blocking from compiled rules, counters, per-site allowlist, private-session enablement | Counters equal cancelled requests on a local test page |
| G5 | Gecko privacy settings (cookie behaviour, ETP, fingerprinting prefs, HTTPS-only, WebRTC), TRR/DoH settings UI | Verified on independent test pages (record results) |
| G6 | ABP-format list support (see §6) + safe updater (staging, validation, atomic swap, versioning) | Parser/matcher tests green, malformed-list tests green |
| G7 | Compose + Material 3 UI, wallpapers (Photo Picker / `OpenDocument`, no storage permission), home screen, RTL | UI tests on small/large/RTL |
| G8 | Delete obsolete WebView/blob code, update docs, set `cleartextTrafficPermitted=false` if no app traffic needs it | `grep -r android.webkit` empty |
| G9 | Benchmarks (startup, memory, tab switch, list parse, size per ABI), release build, signing doc | Measured numbers recorded with device model |

## 6. Ad-block format scope (to be implemented in G6 — nothing here is implemented yet)

*Planned as supported:* `||host^`, `|` anchors, `*` wildcards, `^` separator, `@@` exceptions, `$third-party`,
`$domain=`, resource-type options (`script,image,stylesheet,xmlhttprequest,subdocument,ping,media,font,websocket,other`),
`$important`, `$badfilter`, simple `##` / `#@#` CSS cosmetic rules, hosts files.
*Planned as explicitly unsupported (counted and reported, never silently ignored):* `#?#`, `#$#`, scriptlets, `$redirect`,
`$removeparam`, `$csp`, `$replace`, HTML filtering `##^`, extended CSS. No claim of "full EasyList/EasyPrivacy compatibility"
until the maintained lists are run through the parser and the supported-rule percentage is measured and published.

## 7. Security audit findings

| # | Sev. | Finding | Status |
|---|---|---|---|
| S1 | **High** | `SecurePrefs` overwrote an undecryptable `settings.enc` with an empty file at start-up, so a transient Keystore failure permanently destroyed all settings (open tabs, allow/block lists). | **Fixed**: unreadable file is preserved (`settings.enc.unreadable-<ms>`, newest 3), never overwritten, auto-merged back when readable again. 7 new unit tests (not executed). |
| S2 | Med | Strict secure DNS silently fell back to the system resolver on an invalid/non-https/unknown endpoint. | **Fixed**: `FailClosedDns`; `DohEndpoint` validator (https only, no credentials, no loopback/private/link-local/CGNAT targets). 7 new unit tests (not executed). |
| S3 | Med | When the Keystore was unusable, the open-tab URL list was written to disk **in plaintext**. | **Fixed**: excluded from the unencrypted fallback format. |
| S4 | Low | Imported rule lists were written non-atomically; an HTML error/captive-portal page could be parsed as a list. | **Fixed**: temp-file + rename; HTML rejected. |
| S5 | Prohibited feature | User-Agent profile manager (13 profiles + custom, `navigator.*` spoofing) violates project rules. | **Removed** (code, UI, strings ×3 locales, tests, stale stored keys deleted at start-up). |
| S6 | Info | AES-256-GCM / Keystore review: key non-exportable, IV generated by the Keystore per encryption (randomised, 96-bit), 128-bit tag, header as AAD, atomic write, no hard-coded keys. Sound. Keep alias `shield_settings_key_v1` unchanged or existing data becomes unreadable. | OK |
| S7 | Info | History, bookmarks, per-site rules and download list are **unencrypted SQLite** (`secure_delete` on, `allowBackup=false`, backup rules empty). SQLCipher would add a native library and key/migration work; justified only if the threat model includes extracting app files from a locked device. | Decision deferred; documented |
| S8 | Med (open) | `usesCleartextTraffic=true` and NSC `cleartextTrafficPermitted=true` exist so WebView can load http after a warning. After G8 page traffic is Gecko's, so cleartext for app traffic should be turned off (route http downloads through Gecko). | Open → G8 |
| S9 | Info | Exported components: only `MainActivity` (needed). Service/receiver/FileProvider are not exported. FileProvider paths are scoped to app dirs. | OK |
| S10 | Info | `REQUEST_INSTALL_PACKAGES` is declared for APK hand-off; justified only because APKs can be downloaded. Remove if that feature is dropped. | Review |
| S11 | Info | `DownloadEngine` redirect/downgrade guards and file-name sanitising were read at sampling level only, not exhaustively audited. | Open |
| S12 | Info | Dependency CVE scan not possible offline. Run OWASP dependency-check / `gradle dependencies` + advisory review on a networked machine. | Open |

## 8. Tests

*Authored in this commit (**not executed**):* `SettingsCryptoTest` (+7), `DohEndpointTest` (7), `RuleListParserTest` (+1),
`PageScriptBuilderTest` (rewritten, 4). *Removed:* `UserAgentProfilesTest`, `customUserAgentProfile` instrumented test.
*Still to write, by stage:* extension matcher (Node-runnable), ABP parser/matcher, list-update staging, tab/session
lifecycle (instrumented), private-session isolation (instrumented), Compose/RTL/wallpaper UI tests, GeckoView
integration against a local page.

## 9. First-compile checklist

- [ ] Generate the wrapper (`gradle wrapper --gradle-version 8.7`) or use the pinned Gradle in CI.
- [ ] Add the Mozilla Maven repo with an `includeGroup` content filter; **do not** use `+`/dynamic versions.
- [ ] Choose the GeckoView version, then re-read its Javadoc for every **(verify)** above (and its minSdk / JDK / AGP requirements).
- [ ] If Compose is added with Kotlin 1.9.24, the matching Compose compiler is 1.5.14 (verify against the Compose–Kotlin compatibility map).
- [ ] Measure APK size per ABI; GeckoView is large — use ABI splits for release.
- [ ] Review R8: GeckoView ships consumer rules (verify) — keep release smoke test in CI.
