# Changelog

## 0.3.0 — Ormus Browser: audit fixes and rebrand (unreleased, **not built or run**)
### Changed
- **Renamed to Ormus Browser.** App label is the Latin-script name in every locale (the Arabic and Persian locales previously used a translated name). New launcher icon (adaptive + monochrome) and About-dialog logo/version generated from the Ormus eagle artwork; splash background aligned. `applicationId`, package, Keystore alias and database/file names are intentionally unchanged to keep existing data.
- Documentation updated; `docs/GECKOVIEW_MIGRATION.md` added (audit, feature mapping, staged plan, findings).
### Security
- **Settings store no longer destroys unreadable data**: an undecryptable `settings.enc` is preserved (newest 3 copies), never overwritten, and merged back automatically when decryptable again.
- The unencrypted fallback no longer writes the saved tab-session URLs.
- **Strict secure DNS**: invalid/non-https/unknown DoH configuration now makes lookups fail instead of silently using the system resolver; custom endpoints are validated (`DohEndpoint`).
- Rule-list import: atomic replace, HTML/captive-portal pages rejected.
### Removed
- User-Agent profile manager (13 profiles + custom UA, `navigator.*` identity patching), its menu entry, settings, strings (en/ar/fa), tests; stale stored keys are deleted at start-up.
### Tests (authored, **not executed**)
- `SettingsCryptoTest` +7, `DohEndpointTest` (new, 7), `RuleListParserTest` +1, `PageScriptBuilderTest` rewritten.
### Not done
- GeckoView migration, Compose/Material 3 UI, wallpapers, ABP-format list engine, extension-based blocking, Gecko privacy/DoH settings — see the plan. No build, lint or test was run.

## 0.2.0 — Review fixes + five features (unreleased)
### Added
- **Encrypted local settings**: AES-256-GCM file with a non-exportable Android Keystore key replaces the plain SharedPreferences XML (one-time migration + secure wipe). Status row in Settings.
- **`blob:` downloads**: acknowledged chunk streaming from the page (`ShieldDownload` bridge), per-site policy and dialog applied before any byte is accepted, 2 GB cap, cancel from Downloads/notification.
- **Download notifications**: progress/paused/finished/failed with Pause/Resume/Cancel/Retry, aggregate foreground service (`dataSync`), Android 13+ permission requested at the first download (and again when you switch the setting on later); private downloads show no file names; setting to turn it off. A late "Cancel" tap can no longer turn a finished download into a cancelled one.
- **Find in page**: find bar with match counter, next/previous, menu entry, Ctrl+F; cleared on navigation/tab switch.
- **Tablet layout** (`sw600dp`): top toolbar, two-column tab switcher, centred list/settings screens, bottom sheets expanded and limited to 640dp, Ctrl+L/T/W shortcuts; the activity re-creates when the smallest width class changes (fold/unfold) but not on rotation.
### Fixed
- Pause/Cancel of a stalled HTTP download did nothing until the next bytes arrived (the blocking OkHttp call was never cancelled); a resumed download could race with its cancelled predecessor on the same `.part` file.
- HTTPS→HTTP redirect guard ran *after* the plaintext request was sent, and the manually attached `Cookie` header was replayed to other hosts after a redirect. Both are now enforced per hop by a network interceptor.
- Every internal write (saved session, exit flag) re-built the blocker and reloaded scripts in all tabs; internal keys are now ignored by the settings listener.
- Block interstitials for blocked main-frame URLs were stored in history and counted for cookie post-processing.
- `intent:` links could request arbitrary actions; only VIEW/SENDTO/SEND/DIAL are accepted now.
- Imported block lists without `Content-Length` could be read into memory without limit.
- File-name sanitiser only removed U+202E; all bidi controls and zero-width characters are removed now.
- Popup handling created a blank tab before validating the window transport (leaked tab).
- Stats updates for a second tab could be dropped within the 300 ms coalescing window.
- A file chooser left open when the activity was destroyed froze the page's `<input type=file>`.
- Static "New private tab" shortcut targeted the release package, so it failed in debug builds (`.debug` suffix).
- Bottom sheet minimum height (420dp) clipped the buttons on landscape phones.

## 0.1.0 — MVP (unreleased)
- WebView engine with request interception: ad/tracker/miner/malware rule engine (domain, URL, resource, script rules; categories; allow/block lists; per-site shield).
- Tracking-parameter cleaner and redirect-shim unwrapping; HTTPS-only with interstitials; TLS error warning pages.
- Fingerprint protection modes (Off/Standard/Strict/Maximum), User-Agent manager (13 profiles + custom), WebRTC, referrer and clipboard controls.
- Cookie manager (third-party blocking, per-site policy, clear on exit, session-only), private tabs with isolated WebView profiles, strict site isolation.
- Per-site permissions, popup/redirect/dialog/auto-download protection, external-app confirmation.
- Download manager (resume, SHA-256, risk warnings, APK gate), Downloads/Files screen with categories.
- History, bookmarks, reading list, tab groups/search/restore, privacy dashboard, security info, session report, developer tools.
- Material 3 UI, light/dark, English/Arabic/Persian with RTL.
- Unit tests (rules, URL cleaner, URL input, download safety, tab model, UA profiles, script config) and instrumentation tests (storage, settings, downloads, private mode).
