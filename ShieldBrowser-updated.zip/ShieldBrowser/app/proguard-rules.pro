# WebView message listeners / JS bridges are not used via @JavascriptInterface reflection.
-keepattributes SourceFile,LineNumberTable
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
