package com.shieldbrowser.app.settings

import android.content.Context
import android.content.SharedPreferences
import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.blocking.BlockerConfig
import com.shieldbrowser.app.fingerprint.FingerprintMode
import com.shieldbrowser.app.fingerprint.UserAgentProfile
import com.shieldbrowser.app.fingerprint.UserAgentProfiles

object K {
    const val BLOCK_ADS = "pref_block_ads"
    const val BLOCK_ANALYTICS = "pref_block_analytics"
    const val BLOCK_TRACKING = "pref_block_tracking"
    const val BLOCK_SOCIAL = "pref_block_social"
    const val BLOCK_CRYPTOMINING = "pref_block_cryptomining"
    const val BLOCK_MALWARE = "pref_block_malware"
    const val COSMETIC = "pref_cosmetic"
    const val URL_CLEANING = "pref_url_cleaning"
    const val UNWRAP_REDIRECTS = "pref_unwrap_redirects"
    const val FINGERPRINT_MODE = "pref_fingerprint_mode"
    const val REFERRER_MODE = "pref_referrer_mode"
    const val WEBRTC_MODE = "pref_webrtc_mode"
    const val MINING_HEURISTIC = "pref_mining_heuristic"
    const val BLOCK_CLIPBOARD_READ = "pref_block_clipboard_read"
    const val CLEAR_CLIPBOARD_EXIT = "pref_clear_clipboard_exit"
    const val COOKIE_MODE = "pref_cookie_mode"
    const val CLEAR_COOKIES_EXIT = "pref_clear_cookies_exit"
    const val STRICT_ISOLATION = "pref_strict_isolation"
    const val HTTPS_ONLY = "pref_https_only"
    const val BLOCK_AUTO_REDIRECTS = "pref_block_auto_redirects"
    const val BLOCK_POPUPS = "pref_block_popups"
    const val BLOCK_AUTO_DOWNLOADS = "pref_block_auto_downloads"
    const val EXTERNAL_APPS = "pref_external_apps"
    const val SAFE_BROWSING = "pref_safe_browsing"
    const val SCREENSHOTS = "pref_screenshots"
    const val JS_DEFAULT = "pref_js_default"
    const val SEARCH_ENGINE = "pref_search_engine"
    const val SEARCH_CUSTOM_URL = "pref_search_custom_url"
    const val HOMEPAGE = "pref_homepage"
    const val UA_PROFILE = "pref_ua_profile"
    const val UA_CUSTOM_STRING = "pref_ua_custom_string"
    const val UA_CUSTOM_PLATFORM = "pref_ua_custom_platform"
    const val DNS_MODE = "pref_dns_mode"
    const val DNS_PROVIDER = "pref_dns_provider"
    const val DNS_CUSTOM_URL = "pref_dns_custom_url"
    const val WARN_DANGEROUS = "pref_warn_dangerous"
    const val ASK_DOWNLOAD = "pref_ask_download"
    const val AUTOPLAY = "pref_autoplay"
    const val HISTORY_ENABLED = "pref_history_enabled"
    const val HISTORY_DAYS = "pref_history_days"
    const val THEME = "pref_theme"
    const val LANGUAGE = "pref_language"
    const val FORCE_DARK = "pref_force_dark"
    const val TEXT_SCALE = "pref_text_scale"
    const val DEVELOPER_MODE = "pref_developer_mode"
    const val USER_ALLOW = "pref_user_allow"
    const val USER_BLOCK = "pref_user_block"
    const val DOWNLOAD_NOTIFICATIONS = "pref_download_notifications"
    const val EXIT_PENDING = "internal_exit_cleanup_pending"
    const val SESSION = "internal_session"
    const val NOTIF_PERM_ASKED = "internal_notif_permission_asked"

    /** Bookkeeping keys: changing them must not trigger a blocker/script/tab refresh. */
    val INTERNAL_KEYS: Set<String> = setOf(EXIT_PENDING, SESSION, NOTIF_PERM_ASKED)
}

enum class CookieMode { ALLOW_ALL, BLOCK_THIRD_PARTY, BLOCK_ALL }
enum class ReferrerMode(val policy: String?) { DEFAULT(null), ORIGIN("strict-origin"), SAME_ORIGIN("same-origin"), NONE("no-referrer") }
enum class WebRtcMode { DEFAULT, RELAY, BLOCK }
enum class ExternalAppMode { ASK, BLOCK, ALLOW }
enum class ScreenshotMode { NEVER, PRIVATE, ALWAYS }
enum class DnsMode { SYSTEM, SECURE, CUSTOM }
enum class JsMode { ALLOW, ASK, BLOCK }

/**
 * Typed wrapper over SharedPreferences. All values are local-only and ENCRYPTED at rest: [prefs] is a [SecurePrefs]
 * (AES-256-GCM, key in the Android Keystore). See SECURITY.md > "Encrypted local settings" for scope and limits.
 */
class BrowserSettings(context: Context) {
    private val securePrefs: SecurePrefs = SecurePrefs.get(context.applicationContext)
    val prefs: SharedPreferences get() = securePrefs

    /** True when settings are really encrypted (false only on devices whose Keystore is unusable). */
    val isEncrypted: Boolean get() = securePrefs.isEncrypted
    /** True when an unreadable settings file had to be reset to defaults. */
    val recoveredFromCorruption: Boolean get() = securePrefs.recoveredFromCorruption

    private fun b(k: String, d: Boolean) = prefs.getBoolean(k, d)
    private fun s(k: String, d: String) = prefs.getString(k, d) ?: d
    private inline fun <reified T : Enum<T>> e(k: String, d: T): T {
        val v = prefs.getString(k, null) ?: return d
        return enumValues<T>().firstOrNull { it.name.equals(v, ignoreCase = true) } ?: d
    }

    val blockAds get() = b(K.BLOCK_ADS, true)
    val blockAnalytics get() = b(K.BLOCK_ANALYTICS, true)
    val blockTracking get() = b(K.BLOCK_TRACKING, true)
    val blockSocial get() = b(K.BLOCK_SOCIAL, true)
    val blockCryptomining get() = b(K.BLOCK_CRYPTOMINING, true)
    val blockMalware get() = b(K.BLOCK_MALWARE, true)
    val cosmeticFiltering get() = b(K.COSMETIC, true)
    val urlCleaning get() = b(K.URL_CLEANING, true)
    val unwrapRedirects get() = b(K.UNWRAP_REDIRECTS, true)
    val fingerprintMode get() = e(K.FINGERPRINT_MODE, FingerprintMode.STANDARD)
    val referrerMode get() = e(K.REFERRER_MODE, ReferrerMode.ORIGIN)
    val webRtcMode get() = e(K.WEBRTC_MODE, WebRtcMode.DEFAULT)
    val miningHeuristic get() = b(K.MINING_HEURISTIC, true)
    val blockClipboardRead get() = b(K.BLOCK_CLIPBOARD_READ, true)
    val clearClipboardOnExit get() = b(K.CLEAR_CLIPBOARD_EXIT, false)
    val cookieMode get() = e(K.COOKIE_MODE, CookieMode.BLOCK_THIRD_PARTY)
    val clearCookiesOnExit get() = b(K.CLEAR_COOKIES_EXIT, false)
    val strictIsolation get() = b(K.STRICT_ISOLATION, false)
    val httpsOnly get() = b(K.HTTPS_ONLY, true)
    val blockAutoRedirects get() = b(K.BLOCK_AUTO_REDIRECTS, true)
    val blockPopups get() = b(K.BLOCK_POPUPS, true)
    val blockAutoDownloads get() = b(K.BLOCK_AUTO_DOWNLOADS, true)
    val externalApps get() = e(K.EXTERNAL_APPS, ExternalAppMode.ASK)
    val safeBrowsing get() = b(K.SAFE_BROWSING, false)
    val screenshots get() = e(K.SCREENSHOTS, ScreenshotMode.PRIVATE)
    val jsDefault get() = e(K.JS_DEFAULT, JsMode.ALLOW)
    val searchEngineId get() = s(K.SEARCH_ENGINE, "duckduckgo")
    val searchCustomUrl get() = s(K.SEARCH_CUSTOM_URL, "")
    val homepage get() = s(K.HOMEPAGE, "shield://start").ifBlank { "shield://start" }
    val uaProfileId get() = s(K.UA_PROFILE, UserAgentProfiles.DEFAULT_ID)
    val dnsMode get() = e(K.DNS_MODE, DnsMode.SYSTEM)
    val dnsProvider get() = s(K.DNS_PROVIDER, "cloudflare")
    val dnsCustomUrl get() = s(K.DNS_CUSTOM_URL, "")
    val warnDangerous get() = b(K.WARN_DANGEROUS, true)
    val askBeforeDownload get() = b(K.ASK_DOWNLOAD, true)
    val autoplayAllowed get() = s(K.AUTOPLAY, "block") == "allow"
    val historyEnabled get() = b(K.HISTORY_ENABLED, true)
    val historyDays get() = s(K.HISTORY_DAYS, "0").toIntOrNull() ?: 0
    val theme get() = s(K.THEME, "system")
    val language get() = s(K.LANGUAGE, "system")
    val forceDark get() = b(K.FORCE_DARK, false)
    val textScale get() = (s(K.TEXT_SCALE, "100").toIntOrNull() ?: 100).coerceIn(50, 200)
    val developerMode get() = b(K.DEVELOPER_MODE, false)
    val downloadNotifications get() = b(K.DOWNLOAD_NOTIFICATIONS, true)

    var userAllow: Set<String>
        get() = prefs.getStringSet(K.USER_ALLOW, emptySet()) ?: emptySet()
        set(v) { prefs.edit().putStringSet(K.USER_ALLOW, v.toSet()).apply() }
    var userBlock: Set<String>
        get() = prefs.getStringSet(K.USER_BLOCK, emptySet()) ?: emptySet()
        set(v) { prefs.edit().putStringSet(K.USER_BLOCK, v.toSet()).apply() }
    var exitCleanupPending: Boolean
        get() = prefs.getBoolean(K.EXIT_PENDING, false)
        set(v) { prefs.edit().putBoolean(K.EXIT_PENDING, v).apply() }
    var notifPermissionAsked: Boolean
        get() = prefs.getBoolean(K.NOTIF_PERM_ASKED, false)
        set(v) { prefs.edit().putBoolean(K.NOTIF_PERM_ASKED, v).apply() }
    var sessionJson: String
        get() = prefs.getString(K.SESSION, "") ?: ""
        set(v) { prefs.edit().putString(K.SESSION, v).apply() }

    fun blockerConfig(): BlockerConfig {
        val c = HashSet<BlockCategory>()
        if (blockAds) c.add(BlockCategory.ADVERTISING)
        if (blockAnalytics) c.add(BlockCategory.ANALYTICS)
        if (blockTracking) c.add(BlockCategory.TRACKING)
        if (blockSocial) c.add(BlockCategory.SOCIAL_TRACKING)
        if (blockCryptomining) c.add(BlockCategory.CRYPTOMINING)
        if (blockMalware) c.add(BlockCategory.MALWARE)
        return BlockerConfig(enabled = c.isNotEmpty(), categories = c)
    }

    /** Active UA profile (built-in or the single custom slot). */
    fun userAgentProfile(): UserAgentProfile {
        val id = uaProfileId
        if (id == UserAgentProfiles.CUSTOM_ID) {
            val p = UserAgentProfiles.custom(
                "Custom", s(K.UA_CUSTOM_STRING, ""), s(K.UA_CUSTOM_PLATFORM, ""), mobile = s(K.UA_CUSTOM_STRING, "").contains("Mobile")
            )
            if (p != null) return p
        }
        return UserAgentProfiles.find(id) ?: UserAgentProfiles.builtIns.first()
    }

    fun setUaProfile(id: String) { prefs.edit().putString(K.UA_PROFILE, id).apply() }
    fun setBool(key: String, v: Boolean) { prefs.edit().putBoolean(key, v).apply() }
}
