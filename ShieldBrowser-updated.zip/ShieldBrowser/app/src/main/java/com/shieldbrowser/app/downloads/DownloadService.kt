package com.shieldbrowser.app.downloads

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.shieldbrowser.app.app.container
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service (type dataSync) that keeps the process alive while downloads run, so they survive the user
 * leaving the app. It stops itself as soon as no download is active. The downloads themselves still run in
 * [DownloadEngine]; this service only holds the process and shows the aggregate notification.
 */
class DownloadService : Service() {
    companion object {
        @Volatile var running = false
            private set

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
            } catch (_: Exception) {
                // e.g. started while the app is not allowed to start foreground services: downloads still run in-process
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        running = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val c = applicationContext.container
        val notifier = c.downloadNotifier
        ServiceCompat.startForeground(
            this, DownloadNotifier.ID_FOREGROUND, notifier.foregroundNotification(c.downloads.items.value),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        job?.cancel()
        job = scope.launch {
            var lastUpdate = 0L
            c.downloads.items.collect { list ->
                if (list.none { it.isActive }) {
                    ServiceCompat.stopForeground(this@DownloadService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastUpdate >= 1000) {
                        lastUpdate = now
                        try {
                            val nm = NotificationManagerCompat.from(this@DownloadService)
                            if (nm.areNotificationsEnabled()) nm.notify(DownloadNotifier.ID_FOREGROUND, notifier.foregroundNotification(list))
                        } catch (_: SecurityException) { }
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
