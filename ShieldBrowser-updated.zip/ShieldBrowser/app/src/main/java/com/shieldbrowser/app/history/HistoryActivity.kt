package com.shieldbrowser.app.history

import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.shieldbrowser.app.R
import com.shieldbrowser.app.ui.centerContent
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.ActivityListBinding
import com.shieldbrowser.app.ui.Entry
import com.shieldbrowser.app.ui.EntryAdapter
import com.shieldbrowser.app.ui.formatWhen
import com.shieldbrowser.app.ui.openInBrowser
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivityListBinding
    private lateinit var adapter: EntryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.tabs, b.search, b.recycler.parent as? View)
        b.toolbar.title = getString(R.string.history)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.menu_history)
        b.toolbar.setOnMenuItemClickListener { m ->
            lifecycleScope.launch {
                when (m.itemId) {
                    R.id.h_today -> container.history.deleteToday()
                    R.id.h_all -> container.history.deleteAll()
                }
                load()
            }
            true
        }
        adapter = EntryAdapter(
            onClick = { openInBrowser(it.key) },
            onMore = { e, anchor ->
                PopupMenu(this, anchor).apply {
                    menu.add(R.string.delete)
                    setOnMenuItemClickListener { lifecycleScope.launch { container.history.delete(e.id); load() }; true }
                }.show()
            }
        )
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.search.addTextChangedListener { load() }
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            val items = container.history.list(b.search.text.toString())
            adapter.submit(items.map { Entry(it.id, it.title, it.url.removePrefix("https://") + "  ·  " + formatWhen(it.visitedAt), it.url) })
            b.empty.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }
}
