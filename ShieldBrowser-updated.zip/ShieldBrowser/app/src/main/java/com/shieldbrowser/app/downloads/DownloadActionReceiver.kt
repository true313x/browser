package com.shieldbrowser.app.downloads

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.shieldbrowser.app.app.container

/** Handles the Pause / Resume / Cancel / Retry buttons of download notifications. Not exported. */
class DownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(DownloadNotifier.EXTRA_ID, Long.MIN_VALUE)
        if (id == Long.MIN_VALUE) return
        val downloads = context.applicationContext.container.downloads
        when (intent.action) {
            DownloadNotifier.ACTION_PAUSE -> downloads.pause(id)
            DownloadNotifier.ACTION_RESUME -> downloads.resume(id)
            DownloadNotifier.ACTION_CANCEL -> downloads.cancel(id)
        }
    }
}
