package com.shieldbrowser.app.storage

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Local SQLite store (official Android API, no annotation processors). Nothing here ever leaves the device.
 * `PRAGMA secure_delete` is enabled so deleted history/downloads rows are overwritten, not just unlinked.
 * Private-mode downloads are never written here.
 */
class AppDatabase(context: Context, name: String? = "shield.db") :
    SQLiteOpenHelper(context.applicationContext, name, null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        try { db.rawQuery("PRAGMA secure_delete = ON", null).use { it.moveToFirst() } } catch (_: Exception) {}
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, " +
                "title TEXT NOT NULL DEFAULT '', visited_at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_history_time ON history(visited_at DESC)")
        db.execSQL("CREATE INDEX idx_history_url ON history(url)")
        db.execSQL(
            "CREATE TABLE bookmarks (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, " +
                "title TEXT NOT NULL DEFAULT '', kind INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, " +
                "is_read INTEGER NOT NULL DEFAULT 0, UNIQUE(url, kind))"
        )
        db.execSQL(
            "CREATE TABLE site_settings (host TEXT PRIMARY KEY, shield INTEGER NOT NULL DEFAULT 1, " +
                "js INTEGER NOT NULL DEFAULT -1, cookies INTEGER NOT NULL DEFAULT -1, popups INTEGER NOT NULL DEFAULT -1, " +
                "camera INTEGER NOT NULL DEFAULT -1, mic INTEGER NOT NULL DEFAULT -1, location INTEGER NOT NULL DEFAULT -1, " +
                "notifications INTEGER NOT NULL DEFAULT -1, clipboard INTEGER NOT NULL DEFAULT -1, " +
                "downloads INTEGER NOT NULL DEFAULT -1, autoplay INTEGER NOT NULL DEFAULT -1, fingerprint INTEGER NOT NULL DEFAULT -1)"
        )
        db.execSQL(
            "CREATE TABLE downloads (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, file_name TEXT NOT NULL, " +
                "file_path TEXT NOT NULL, mime TEXT, total_bytes INTEGER NOT NULL DEFAULT -1, " +
                "downloaded_bytes INTEGER NOT NULL DEFAULT 0, state INTEGER NOT NULL, created_at INTEGER NOT NULL, " +
                "sha256 TEXT, source_host TEXT, risk TEXT, error TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { /* v1 only */ }

    companion object {
        /** Escapes LIKE wildcards; use with `ESCAPE '\'`. */
        fun likeArg(q: String): String =
            "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    }
}
