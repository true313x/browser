package com.shieldbrowser.app.downloads

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.format.Formatter
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.shieldbrowser.app.R
import com.shieldbrowser.app.settings.BrowserSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Download notifications (progress, paused, finished, failed) + the aggregate notification of [DownloadService].
 *
 * Privacy rules:
 *  - PRIVATE downloads never get a per-file notification; they only count in the generic foreground notification
 *    ("Private download in progress"), so no file name or host reaches the notification shade or its history.
 *  - Every notification has a generic public version (lock screen shows "Downloads", never a file name).
 *  - Tapping a notification only opens the Downloads screen (never opens a file / installs an APK directly).
 * Turning the setting off also turns off the foreground service (Android requires it to show a notification);
 * downloads then only continue while the app process is alive.
 */
class DownloadNotifier(
    private val context: Context,
    private val engine: DownloadEngine,
    private val settings: BrowserSettings,
    private val scope: CoroutineScope
) {
    companion object {
        const val CHANNEL_PROGRESS = "downloads_progress"
        const val CHANNEL_DONE = "downloads_done"
        const val ID_FOREGROUND = 0x5D01
        const val EXTRA_ID = "download_id"
        const val ACTION_PAUSE = "com.shieldbrowser.app.action.DOWNLOAD_PAUSE"
        const val ACTION_RESUME = "com.shieldbrowser.app.action.DOWNLOAD_RESUME"
        const val ACTION_CANCEL = "com.shieldbrowser.app.action.DOWNLOAD_CANCEL"
        private const val ID_ITEM_BASE = 20_000
        private const val PROGRESS_INTERVAL_MS = 1000L
    }

    private val nm = NotificationManagerCompat.from(context)
    // Touched only by the single collector coroutine started in start().
    private val lastState = HashMap<Long, DownloadState>()
    private val lastShown = HashMap<Long, Long>()
    private var seeded = false
    private var wasEnabled = true
    @Volatile private var lastServiceStart = 0L

    fun start() {
        createChannels()
        clearStale()
        scope.launch { engine.items.collect { onItems(it) } }
    }

    private fun createChannels() {
        val sys = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val progress = NotificationChannel(CHANNEL_PROGRESS, context.getString(R.string.notif_channel_progress), NotificationManager.IMPORTANCE_LOW)
        progress.setShowBadge(false)
        val done = NotificationChannel(CHANNEL_DONE, context.getString(R.string.notif_channel_done), NotificationManager.IMPORTANCE_DEFAULT)
        sys.createNotificationChannels(listOf(progress, done))
    }

    /** A killed process can leave "ongoing" progress notifications behind; remove them at the next start. */
    private fun clearStale() {
        try {
            val sys = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            for (sn in sys.activeNotifications) {
                if (sn.id == ID_FOREGROUND || sn.id >= ID_ITEM_BASE) nm.cancel(sn.id)
            }
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ state machine
    private fun onItems(list: List<DownloadItem>) {
        val now = SystemClock.elapsedRealtime()
        if (!seeded) {                                   // history loaded from the DB must not raise notifications
            seeded = true
            for (i in list) lastState[i.id] = i.state
            return
        }
        val enabled = settings.downloadNotifications
        if (!enabled && wasEnabled) for (i in list) nm.cancel(itemNotifId(i.id))
        wasEnabled = enabled

        val present = HashSet<Long>()
        for (i in list) {
            present.add(i.id)
            val prev = lastState[i.id]
            if (enabled && !i.isPrivate) show(i, prev, now)
            lastState[i.id] = i.state
        }
        val gone = lastState.keys.filter { it !in present }
        for (id in gone) { lastState.remove(id); lastShown.remove(id); nm.cancel(itemNotifId(id)) }

        if (enabled && list.any { it.isActive }) ensureService(now)
    }

    private fun show(i: DownloadItem, prev: DownloadState?, now: Long) {
        val nid = itemNotifId(i.id)
        when (i.state) {
            DownloadState.RUNNING, DownloadState.QUEUED -> {
                val last = lastShown[i.id] ?: 0L
                if (prev == i.state && now - last < PROGRESS_INTERVAL_MS) return
                lastShown[i.id] = now
                notifySafe(nid, progressNotification(i))
            }
            DownloadState.PAUSED -> if (prev != DownloadState.PAUSED) notifySafe(nid, pausedNotification(i))
            DownloadState.COMPLETED -> if (prev != DownloadState.COMPLETED) notifySafe(nid, doneNotification(i, true))
            DownloadState.FAILED -> if (prev != DownloadState.FAILED) notifySafe(nid, doneNotification(i, false))
            DownloadState.CANCELED -> if (prev != DownloadState.CANCELED) nm.cancel(nid)
        }
    }

    private fun ensureService(now: Long) {
        if (DownloadService.running || now - lastServiceStart < 3000) return
        lastServiceStart = now
        DownloadService.start(context)
    }

    // ------------------------------------------------------------------ builders
    private fun str(res: Int) = context.getString(res)

    private fun itemNotifId(id: Long): Int = ID_ITEM_BASE + (id and 0x3FFFFFFL).toInt()

    private fun publicVersion(channel: String): Notification =
        NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(str(R.string.notif_public_text))
            .build()

    private fun base(channel: String): NotificationCompat.Builder =
        NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentIntent(openDownloads())
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion(channel))

    private fun openDownloads(): PendingIntent {
        val intent = Intent(context, DownloadsActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun actionIntent(action: String, id: Long): PendingIntent {
        val intent = Intent(context, DownloadActionReceiver::class.java).setAction(action).putExtra(EXTRA_ID, id)
        val requestCode = id.hashCode() * 31 + action.hashCode()
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun size(bytes: Long): String = Formatter.formatShortFileSize(context, bytes)

    private fun progressText(i: DownloadItem): String = buildString {
        append(size(i.downloadedBytes))
        if (i.totalBytes > 0) append(" / ").append(size(i.totalBytes))
        if (i.speedBps > 0) append(" · ").append(size(i.speedBps)).append("/s")
    }

    private fun progressNotification(i: DownloadItem): Notification {
        val b = base(CHANNEL_PROGRESS)
            .setContentTitle(i.fileName)
            .setContentText(progressText(i))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, i.progress.coerceAtLeast(0), i.progress < 0)
        if (!i.isBlob) b.addAction(0, str(R.string.notif_action_pause), actionIntent(ACTION_PAUSE, i.id))
        b.addAction(0, str(R.string.notif_action_cancel), actionIntent(ACTION_CANCEL, i.id))
        return b.build()
    }

    private fun pausedNotification(i: DownloadItem): Notification =
        base(CHANNEL_PROGRESS)
            .setContentTitle(i.fileName)
            .setContentText(str(R.string.notif_paused_title) + " · " + size(i.downloadedBytes))
            .setOnlyAlertOnce(true)
            .addAction(0, str(R.string.notif_action_resume), actionIntent(ACTION_RESUME, i.id))
            .addAction(0, str(R.string.notif_action_cancel), actionIntent(ACTION_CANCEL, i.id))
            .build()

    private fun doneNotification(i: DownloadItem, ok: Boolean): Notification {
        val b = base(CHANNEL_DONE)
            .setContentTitle(i.fileName)
            .setContentText(str(if (ok) R.string.notif_done_title else R.string.notif_failed_title))
            .setAutoCancel(true)
            .setCategory(if (ok) NotificationCompat.CATEGORY_STATUS else NotificationCompat.CATEGORY_ERROR)
        if (!ok && !i.isBlob) b.addAction(0, str(R.string.notif_action_retry), actionIntent(ACTION_RESUME, i.id))
        return b.build()
    }

    /** The notification Android requires while [DownloadService] runs. It never shows file names or hosts. */
    fun foregroundNotification(list: List<DownloadItem>): Notification {
        val active = list.filter { it.isActive }
        val onlyPrivate = active.isNotEmpty() && active.all { it.isPrivate }
        val title = when {
            onlyPrivate -> str(R.string.notif_private_active)
            active.size > 1 -> context.getString(R.string.notif_active_many, active.size)
            else -> str(R.string.notif_active_one)
        }
        val known = active.isNotEmpty() && active.all { it.totalBytes > 0 }
        val total = active.sumOf { it.totalBytes.coerceAtLeast(0L) }
        val done = active.sumOf { it.downloadedBytes }
        val pct = if (known && total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
        return NotificationCompat.Builder(context, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(title)
            .setContentIntent(openDownloads())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion(CHANNEL_PROGRESS))
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setProgress(100, pct, !known)
            .build()
    }

    @SuppressLint("MissingPermission")
    private fun notifySafe(id: Int, n: Notification) {
        try { if (nm.areNotificationsEnabled()) nm.notify(id, n) } catch (_: SecurityException) { }
    }
}
