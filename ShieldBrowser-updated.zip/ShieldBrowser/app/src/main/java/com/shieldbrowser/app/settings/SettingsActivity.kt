package com.shieldbrowser.app.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.databinding.ActivitySettingsBinding
import com.shieldbrowser.app.privacy.ClipboardGuard
import com.shieldbrowser.app.ui.centerContent
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.settingsContainer)
        b.toolbar.setNavigationOnClickListener { finish() }
        if (savedInstanceState == null) supportFragmentManager.beginTransaction().replace(R.id.settingsContainer, SettingsFragment()).commit()
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        private val pickList = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            chooseCategory { cat ->
                viewLifecycleOwner.lifecycleScope.launch {
                    val text = try { requireContext().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } } catch (_: Exception) { null }
                    if (text == null || text.length > 15_000_000) { toast(getString(R.string.import_failed)); return@launch }
                    val n = requireContext().container.ruleUpdater.importFromText("file-" + (uri.hashCode() and 0xffff), text, cat)
                    toast(getString(R.string.import_done, n))
                }
            }
        }

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            val c = requireContext().container
            // All settings go through the encrypted store (never a plain shared_prefs XML file).
            preferenceManager.preferenceDataStore = SecureSettingsDataStore(c.settings.prefs)
            setPreferencesFromResource(R.xml.preferences, rootKey)
            findPreference<Preference>("act_settings_encryption")?.summary = getString(
                when {
                    !c.settings.isEncrypted -> R.string.settings_enc_off
                    c.settings.recoveredFromCorruption -> R.string.settings_enc_reset
                    else -> R.string.settings_enc_on
                }
            )
            click("act_site_settings") { startActivity(Intent(requireContext(), SiteSettingsActivity::class.java)) }
            click("act_private_dns") { try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (_: Exception) { } }
            click("act_default_browser") { try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } catch (_: Exception) {} }
            click("act_clear_history") { lifecycleScope.launch { c.history.deleteAll(); toast(getString(R.string.cleared)) } }
            click("act_clear_cookies") { c.cookies.clearAll(); toast(getString(R.string.cleared)) }
            click("act_clear_all") {
                MaterialAlertDialogBuilder(requireContext()).setMessage(R.string.clear_all_confirm)
                    .setPositiveButton(R.string.clear) { _, _ ->
                        lifecycleScope.launch {
                            c.history.deleteAll(); c.cookies.clearAll(); c.sessionReport.clear()
                            c.downloads.clearFinished(deleteFiles = false); c.siteSettings.clearAll()
                            ClipboardGuard.clear(requireContext()); toast(getString(R.string.cleared))
                        }
                    }.setNegativeButton(android.R.string.cancel, null).show()
            }
            click("act_import_url") { importUrlDialog() }
            click("act_import_file") { pickList.launch(arrayOf("text/*", "application/octet-stream")) }
            click("act_reset_lists") {
                c.ruleStore.clearImported(); c.ruleStore.loadInto(c.ruleEngine); toast(getString(R.string.cleared))
            }
            click("act_allow_list") { editList(R.string.act_allow_list, c.settings.userAllow) { c.settings.userAllow = it } }
            click("act_block_list") { editList(R.string.act_block_list, c.settings.userBlock) { c.settings.userBlock = it } }
            click("act_notifications_info") { }
            click("act_about") { showAbout() }
            findPreference<Preference>("act_import_url")?.summary =
                getString(R.string.rules_loaded, c.ruleEngine.domainRuleCount(), c.ruleEngine.patternRuleCount())
        }

        private fun click(key: String, f: () -> Unit) {
            findPreference<Preference>(key)?.setOnPreferenceClickListener { f(); true }
        }

        private fun toast(msg: String) { Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show() }

        private fun chooseCategory(done: (BlockCategory) -> Unit) {
            val cats = listOf(BlockCategory.ADVERTISING, BlockCategory.ANALYTICS, BlockCategory.TRACKING, BlockCategory.MALWARE)
            val names = arrayOf(getString(R.string.cat_advertising), getString(R.string.cat_analytics), getString(R.string.cat_tracking), getString(R.string.cat_malware))
            MaterialAlertDialogBuilder(requireContext()).setTitle(R.string.import_category)
                .setItems(names) { _, i -> done(cats[i]) }.show()
        }

        private fun importUrlDialog() {
            val input = EditText(requireContext()).apply { hint = "https://…/hosts.txt"; setSingleLine() }
            MaterialAlertDialogBuilder(requireContext()).setTitle(R.string.act_import_url).setMessage(R.string.import_url_note).setView(input)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    val url = input.text.toString().trim()
                    chooseCategory { cat ->
                        viewLifecycleOwner.lifecycleScope.launch {
                            val r = requireContext().container.ruleUpdater.importFromUrl(url, cat)
                            toast(r.fold({ getString(R.string.import_done, it) }, { getString(R.string.import_failed) }))
                        }
                    }
                }.setNegativeButton(android.R.string.cancel, null).show()
        }

        private fun editList(title: Int, current: Set<String>, save: (Set<String>) -> Unit) {
            val input = EditText(requireContext()).apply {
                setText(current.sorted().joinToString("\n")); minLines = 5; gravity = android.view.Gravity.TOP
                hint = "example.com"
            }
            MaterialAlertDialogBuilder(requireContext()).setTitle(title).setMessage(R.string.one_domain_per_line).setView(input)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    save(input.text.lines().map { it.trim().lowercase().removePrefix("*.") }.filter { it.contains('.') && !it.contains(' ') && it.length < 254 }.toSet())
                }.setNegativeButton(android.R.string.cancel, null).show()
        }

        private fun showAbout() {
            MaterialAlertDialogBuilder(requireContext()).setTitle(R.string.app_name).setMessage(R.string.about_limitations)
                .setPositiveButton(android.R.string.ok, null).show()
        }
    }
}
