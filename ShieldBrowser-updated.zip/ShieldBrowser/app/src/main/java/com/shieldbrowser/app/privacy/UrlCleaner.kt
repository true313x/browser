package com.shieldbrowser.app.privacy

import com.shieldbrowser.app.blocking.DomainUtils
import java.net.URLDecoder

/**
 * Removes well-known tracking query parameters and unwraps well-known redirect wrappers.
 * Pure Kotlin. Returns the *same* String instance when nothing was changed.
 *
 * LIMITATION: only known parameters are removed; unknown/custom tracking IDs are left alone on purpose
 * (removing arbitrary parameters would break sites).
 */
object UrlCleaner {
    private val globalParams = setOf(
        "fbclid", "gclid", "gclsrc", "dclid", "msclkid", "gbraid", "wbraid", "yclid", "ttclid", "twclid",
        "li_fat_id", "igshid", "mc_eid", "mc_cid", "_hsenc", "_hsmi", "__hssc", "__hstc", "__hsfp",
        "hsctatracking", "mkt_tok", "oly_enc_id", "oly_anon_id", "vero_id", "vero_conv", "s_cid", "_ga", "_gl",
        "ref_src", "ref_url", "srsltid", "wickedid", "rb_clickid", "soc_src", "soc_trk", "icid", "sc_cid",
        "ml_subscriber", "ml_subscriber_hash", "_openstat", "yclid", "zanpid", "irclickid"
    )
    private val globalPrefixes = listOf("utm_", "pk_", "mtm_", "piwik_", "hsa_", "stm_")

    private data class HostRule(val hostSuffix: String, val params: Set<String>, val prefixes: List<String> = emptyList())

    private val hostRules = listOf(
        HostRule("youtube.com", setOf("si", "feature", "pp")),
        HostRule("youtu.be", setOf("si", "feature", "pp")),
        HostRule("instagram.com", setOf("igsh", "igshid")),
        HostRule("facebook.com", setOf("__tn__", "__cft__", "refsrc", "fref", "mibextid", "_rdr", "sfnsn")),
        HostRule("linkedin.com", setOf("trk", "trackingid", "lipi", "midtoken", "midsig", "eid", "otptoken", "trkemail")),
        HostRule("spotify.com", setOf("si")),
        HostRule("tiktok.com", setOf("_r", "_t", "is_from_webapp", "sender_device", "sender_web_id", "checksum")),
        HostRule("twitter.com", setOf("s", "t", "ref_src")),
        HostRule("x.com", setOf("s", "t", "ref_src")),
        HostRule("amazon.", setOf("ref", "ref_", "tag", "th", "psc", "qid", "sr", "crid", "sprefix", "linkcode", "linkid", "creative", "creativeasin", "camp"), listOf("pf_rd_", "pd_rd_"))
    )

    data class Result(val url: String, val removed: List<String>)

    fun clean(url: String): String = cleanDetailed(url).url

    fun cleanDetailed(url: String): Result {
        val scheme = DomainUtils.schemeOf(url)
        if (scheme != "http" && scheme != "https") return Result(url, emptyList())
        val q = url.indexOf('?')
        if (q < 0) return Result(url, emptyList())
        val hashIdx = url.indexOf('#', q)
        val base = url.substring(0, q)
        val query = if (hashIdx >= 0) url.substring(q + 1, hashIdx) else url.substring(q + 1)
        val fragment = if (hashIdx >= 0) url.substring(hashIdx) else ""
        val host = DomainUtils.hostOf(url).orEmpty()

        val removed = ArrayList<String>()
        val kept = ArrayList<String>()
        for (pair in query.split('&')) {
            if (pair.isEmpty()) continue
            val key = pair.substringBefore('=').lowercase()
            if (isTracking(key, host)) removed.add(key) else kept.add(pair)
        }
        if (removed.isEmpty()) return Result(url, emptyList())
        val rebuilt = if (kept.isEmpty()) base + fragment else base + "?" + kept.joinToString("&") + fragment
        return Result(rebuilt, removed)
    }

    private fun isTracking(key: String, host: String): Boolean {
        if (key in globalParams) return true
        if (globalPrefixes.any { key.startsWith(it) }) return true
        for (r in hostRules) {
            val match = if (r.hostSuffix.endsWith(".")) host.contains(".${r.hostSuffix}") || host.startsWith(r.hostSuffix)
            else host == r.hostSuffix || host.endsWith("." + r.hostSuffix)
            if (!match) continue
            if (key in r.params || r.prefixes.any { key.startsWith(it) }) return true
        }
        return false
    }

    /** Unwraps link-shim redirects (google.com/url?q=..., l.facebook.com/l.php?u=...). Returns null if not a wrapper. */
    fun unwrapRedirect(url: String): String? {
        val scheme = DomainUtils.schemeOf(url)
        if (scheme != "http" && scheme != "https") return null
        val host = DomainUtils.hostOf(url) ?: return null
        val afterHost = url.substringAfter("://").substringAfter('/', "")
        val path = "/" + afterHost.substringBefore('?').substringBefore('#')
        val query = url.substringAfter('?', "").substringBefore('#')
        val key = when {
            (host.startsWith("www.google.") || host.startsWith("google.")) && path == "/url" -> "q|url"
            host == "l.facebook.com" || host == "lm.facebook.com" -> "u"
            host == "out.reddit.com" -> "url"
            host.endsWith("youtube.com") && path == "/redirect" -> "q"
            host == "slack-redir.net" -> "url"
            host == "away.vk.com" -> "to"
            else -> null
        } ?: return null
        val keys = key.split('|')
        for (pair in query.split('&')) {
            val k = pair.substringBefore('=')
            if (k in keys) {
                val v = try { URLDecoder.decode(pair.substringAfter('=', ""), "UTF-8") } catch (_: Exception) { return null }
                val s = DomainUtils.schemeOf(v)
                if (s == "http" || s == "https") return v
            }
        }
        return null
    }
}
