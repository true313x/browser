package com.shieldbrowser.app.app

import android.app.Application
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.shieldbrowser.app.blocking.RuleEngine
import com.shieldbrowser.app.blocking.RuleStore
import com.shieldbrowser.app.blocking.RuleUpdater
import com.shieldbrowser.app.bookmarks.BookmarkRepository
import com.shieldbrowser.app.browser.NavigationPolicy
import com.shieldbrowser.app.browser.ProfileManager
import com.shieldbrowser.app.browser.TabManager
import com.shieldbrowser.app.downloads.BlobDownloadManager
import com.shieldbrowser.app.downloads.DownloadEngine
import com.shieldbrowser.app.downloads.DownloadNotifier
import com.shieldbrowser.app.history.HistoryRepository
import com.shieldbrowser.app.network.DnsProvider
import com.shieldbrowser.app.privacy.ClipboardGuard
import com.shieldbrowser.app.privacy.CookieController
import com.shieldbrowser.app.privacy.SessionReport
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.K
import com.shieldbrowser.app.settings.SiteSettingsRepository
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Manual dependency container (no DI framework → fewer dependencies, simpler audit).
 * Layers: ui → browser/tabs (domain) → privacy/blocking/security/fingerprint → storage/network (data).
 */
class AppContainer(val context: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings = BrowserSettings(context)
    val db = AppDatabase(context)
    val history = HistoryRepository(db)
    val bookmarks = BookmarkRepository(db)
    val siteSettings = SiteSettingsRepository(db, scope)
    val sessionReport = SessionReport()
    val profiles = ProfileManager()
    val cookies = CookieController(settings, siteSettings, profiles)
    val dns = DnsProvider(settings)
    val ruleEngine = RuleEngine()
    val ruleStore = RuleStore(context)
    val ruleUpdater = RuleUpdater(dns, ruleStore, ruleEngine)
    val navPolicy = NavigationPolicy(settings)
    val downloads = DownloadEngine(context, db, dns, scope, settings, sessionReport)
    val downloadNotifier = DownloadNotifier(context, downloads, settings, scope)
    val tabs = TabManager(context, this)
    /** blob: downloads (needs [tabs] for the host/UI context, hence lazy). */
    val blobs: BlobDownloadManager by lazy { BlobDownloadManager(this, tabs) }

    // Kept as a field so the listener is never garbage-collected, whatever SharedPreferences implementation is used.
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onSettingsChanged(key) }

    fun onAppStart() {
        ruleStore.loadInto(ruleEngine)
        ruleEngine.siteShieldOff = { host -> !siteSettings.isShieldOn(host) }
        refreshBlocker()
        applyTheme()
        applyLocale()
        siteSettings.onChanged = { tabs.refreshScripts() }

        profiles.cleanupOrphans()
        if (settings.exitCleanupPending) runExitCleanup()     // previous process died without a clean exit
        settings.exitCleanupPending = true                      // cleared again by a clean exit

        val days = settings.historyDays
        if (days > 0) scope.launch { history.deleteOlderThan(days) }
        settings.prefs.registerOnSharedPreferenceChangeListener(prefListener)
        downloadNotifier.start()
        tabs.restoreSession()
    }

    private fun refreshBlocker() {
        ruleEngine.config = settings.blockerConfig()
        ruleEngine.userAllow = settings.userAllow
        ruleEngine.userBlock = settings.userBlock
    }

    fun applyTheme() {
        AppCompatDelegate.setDefaultNightMode(
            when (settings.theme) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun applyLocale() {
        val tag = settings.language
        AppCompatDelegate.setApplicationLocales(
            if (tag == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag)
        )
    }

    private fun onSettingsChanged(key: String?) {
        // Bookkeeping writes (saved session, exit flag) happen often; they must not rebuild the blocker or reload scripts.
        if (key != null && (key in K.INTERNAL_KEYS || key == K.DOWNLOAD_NOTIFICATIONS)) return
        refreshBlocker()
        when (key) {
            K.THEME -> applyTheme()
            K.LANGUAGE -> applyLocale()
            K.DNS_MODE, K.DNS_PROVIDER, K.DNS_CUSTOM_URL -> dns.invalidate()
        }
        tabs.applyPrefsAll()
    }

    /** Clean exit / crash-recovery cleanup (private session, cookies per policy, clipboard). */
    fun runExitCleanup() {
        try {
            tabs.endPrivateSession(createReplacement = false)
            cookies.exitCleanup()
            if (settings.clearClipboardOnExit) ClipboardGuard.clear(context)
        } finally {
            settings.exitCleanupPending = false
        }
    }
}
