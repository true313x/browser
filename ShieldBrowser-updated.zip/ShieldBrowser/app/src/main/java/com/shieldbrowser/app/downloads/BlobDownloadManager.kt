package com.shieldbrowser.app.downloads

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.webkit.JavaScriptReplyProxy
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.browser.BrowserTab
import com.shieldbrowser.app.browser.TabManager
import org.json.JSONObject
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Saves `blob:` downloads. WebView only tells us the blob URL; the bytes exist only inside the page, so we ask the
 * page (main frame of the tab that started the download) to stream them to us through the `ShieldDownload`
 * WebMessageListener, one acknowledged chunk at a time (see [BlobProtocol] and assets/js/blob_fetch.js).
 *
 * Security properties:
 *  - Only sessions this app started are accepted; each has a random 128-bit id and is bound to one tab.
 *  - Messages must come from the MAIN frame and from the origin that owns the blob URL.
 *  - The usual download policy (per-site block, ask, dangerous-file warning) runs BEFORE any byte is accepted.
 *  - Size is capped, chunks must arrive in order, and a watchdog ends stalled sessions.
 * A malicious page can only feed bytes into a download the user has just approved for that same page.
 */
class BlobDownloadManager(private val c: AppContainer, private val tabs: TabManager) {
    enum class BeginResult { STARTED, NO_JS, BUSY, NO_WEBVIEW, UNSUPPORTED }

    private enum class Stage { WAIT_META, WAIT_USER, TRANSFER, FINISHING }

    private class Session(val sid: String, val tabId: Long, val blobUrl: String, val origin: String) {
        @Volatile var stage = Stage.WAIT_META
        @Volatile var handle: DownloadEngine.PushHandle? = null
        @Volatile var reply: JavaScriptReplyProxy? = null
        var nextSeq = 0
        var name = ""
        var mime: String? = null
        var size = -1L
        var timeout: Runnable = Runnable { }
    }

    private val sessions = ConcurrentHashMap<String, Session>()
    private val random = SecureRandom()
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "blob-download").also { it.isDaemon = true } }

    private val template: String by lazy {
        try { c.context.assets.open("js/blob_fetch.js").bufferedReader().use { it.readText() } } catch (_: Exception) { "" }
    }

    // ------------------------------------------------------------------ start (main thread)
    fun begin(tab: BrowserTab, blobUrl: String): BeginResult {
        val wv = tab.webView ?: return BeginResult.NO_WEBVIEW
        if (!tabs.configurator.messageListenerSupported || template.isEmpty()) return BeginResult.UNSUPPORTED
        val origin = BlobProtocol.originOf(blobUrl) ?: return BeginResult.UNSUPPORTED
        if (!wv.settings.javaScriptEnabled) return BeginResult.NO_JS
        if (sessions.values.any { it.tabId == tab.id }) return BeginResult.BUSY

        val sid = newSid()
        val s = Session(sid, tab.id, blobUrl, origin)
        s.timeout = Runnable { fail(s, R.string.blob_failed, "Timed out") }
        sessions[sid] = s
        arm(s, 20_000)
        wv.evaluateJavascript(BlobProtocol.fillTemplate(template, blobUrl, sid) { JSONObject.quote(it) }, null)
        return BeginResult.STARTED
    }

    /** A tab was closed/destroyed: end its transfers. */
    fun onTabGone(tabId: Long) {
        for (s in sessions.values.toList()) if (s.tabId == tabId) fail(s, null, "Tab closed")
    }

    private fun newSid(): String {
        val b = ByteArray(16)
        random.nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    // ------------------------------------------------------------------ messages from the page (UI thread)
    fun onMessage(tab: BrowserTab, raw: String?, sourceOrigin: Uri, isMainFrame: Boolean, reply: JavaScriptReplyProxy) {
        val msg = BlobProtocol.parse(raw) ?: return
        val s = sessions[msg.sid] ?: return
        if (!isMainFrame || s.tabId != tab.id || !BlobProtocol.sameOrigin(s.origin, sourceOrigin.toString())) return
        s.reply = reply
        when (msg) {
            is BlobProtocol.Msg.Meta -> onMeta(s, tab, msg)
            is BlobProtocol.Msg.Chunk -> onChunk(s, msg)
            is BlobProtocol.Msg.Done -> onDone(s)
            is BlobProtocol.Msg.Failed -> fail(s, R.string.blob_failed, msg.reason)
        }
    }

    private fun onMeta(s: Session, tab: BrowserTab, m: BlobProtocol.Msg.Meta) {
        if (s.stage != Stage.WAIT_META) return
        ui.removeCallbacks(s.timeout)
        if (m.size > DownloadEngine.MAX_PUSH_BYTES) { fail(s, R.string.blob_too_large, "Too large"); return }
        s.name = BlobProtocol.chooseName(m.name, m.type)
        s.mime = m.type.ifBlank { null }
        s.size = m.size
        s.stage = Stage.WAIT_USER
        val host = tabs.host
        if (host == null) { fail(s, null, "No window"); return }
        host.confirmBlobDownload(tab, s.name, s.mime, s.size, s.blobUrl) { accepted ->
            if (s.stage != Stage.WAIT_USER) return@confirmBlobDownload
            if (!accepted) { send(s, "abort"); end(s); return@confirmBlobDownload }
            val handle = c.downloads.beginPush(DownloadEngine.PushRequest(s.blobUrl, s.name, s.mime, s.size, tab.isPrivate))
            if (handle == null) { fail(s, R.string.blob_too_large, "No space"); return@confirmBlobDownload }
            s.handle = handle
            s.stage = Stage.TRANSFER
            arm(s, 60_000)
            send(s, "go")
        }
    }

    private fun onChunk(s: Session, m: BlobProtocol.Msg.Chunk) {
        if (s.stage != Stage.TRANSFER) return
        if (m.seq != s.nextSeq) { fail(s, R.string.blob_failed, "Out of order"); return }
        s.nextSeq++
        arm(s, 60_000)
        val handle = s.handle ?: return
        io.execute {
            val bytes = try { Base64.decode(m.b64, Base64.DEFAULT) } catch (_: IllegalArgumentException) { null }
            if (bytes == null) c.downloads.failPush(handle, "Corrupt data")
            val ok = bytes != null && c.downloads.push(handle, bytes)
            ui.post { if (ok) send(s, "ack") else { send(s, "abort"); end(s) } }
        }
    }

    private fun onDone(s: Session) {
        if (s.stage != Stage.TRANSFER) return
        s.stage = Stage.FINISHING
        ui.removeCallbacks(s.timeout)
        val handle = s.handle
        io.execute {
            if (handle != null) c.downloads.finishPush(handle)
            ui.post { end(s) }
        }
    }

    // ------------------------------------------------------------------ helpers
    private fun arm(s: Session, ms: Long) {
        ui.removeCallbacks(s.timeout)
        ui.postDelayed(s.timeout, ms)
    }

    private fun send(s: Session, command: String) {
        val r = s.reply ?: return
        val text = s.sid + ":" + command
        ui.post { try { r.postMessage(text) } catch (_: Exception) { } }
    }

    private fun end(s: Session) {
        ui.removeCallbacks(s.timeout)
        sessions.remove(s.sid)
    }

    private fun fail(s: Session, messageRes: Int?, detail: String) {
        val handle = s.handle
        if (handle != null) io.execute { c.downloads.failPush(handle, detail) }
        send(s, "abort")
        end(s)
        if (messageRes != null) tabs.host?.toast(tabs.uiContext().getString(messageRes))
    }
}
