package com.shieldbrowser.app.app

import android.app.Application
import android.content.Context

class ShieldApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.onAppStart()
    }
}

val Context.container: AppContainer get() = (applicationContext as ShieldApp).container
