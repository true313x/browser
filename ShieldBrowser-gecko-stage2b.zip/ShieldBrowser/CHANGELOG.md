# Changelog

## 0.4.0-gecko (preview, unreleased) — encryption, Sealed Mode, payment protection
### Added
- Hybrid post-quantum crypto (X25519 + ML-KEM-768 / Kyber, HKDF, AES-256-GCM, Argon2id) for encrypted backups and a recovery key; Keystore-wrapped `KeyVault`.
- SQLCipher-encrypted local database with verified migration from the plaintext one.
- Tamper monitor and **Sealed Mode** (separate secrets-free process, session wipe, optional full wipe, biometric unlock).
- **Secure Payment tab**, payment-page hardening, phishing/lookalike guard, optional paranoid checkout, card-field detector (no contents read).
- Biometric app lock; Security Center sheet; strings in English, Arabic, Persian.
### Fixed
- Application start-up ran in every Gecko child process (settings-file corruption risk, repeated cleanup).
- Shield Blocker was inactive in private tabs; repeated POST re-sent silently; payment URLs stored in history/session; `file:`/`data:`/`javascript:` handed to external apps.
- Unit tests: `HybridKemTest`, `SealedBoxTest`, `PassphraseWrapTest`, `PaymentGuardTest`, `IntegrityChecksTest`, `PspListTest`; Node: `js-test/payment.test.js`. Not compiled by the author.

### Second review pass (see REVIEW.md)
- Fixed: Secure Payment tab self-blanking (TLS state unknown ≠ insecure), popup attach race, DB status shown before open, switch/TalkBack handling,
  lock-cover back/keys, FLAG_SECURE refresh, session URLs in backups, unchecked BC exceptions, over-broad Frida frame match, cert-pin typo/Play signing
  trap (build-time validation), late page-bridge signal, Android 15 FGS timeout, CI coverage. Added debug-only "Simulate tamper".
- New docs: REVIEW.md (findings, open items, device checklist), ROADMAP.md (phased plan).

## 0.3.0-gecko (preview, unreleased)
- New build flavor **gecko**: GeckoView engine (Mozilla), Material 3 browser screen with accent palettes / wallpaper colours,
  customizable start-page background (presets, own photo, blur, dimming), engine-level protection (ETP strict, Total Cookie
  Protection, HTTPS-only, DoH, GPC), protection levels Standard/Strict/Maximum (Gecko prefs incl. hybrid post-quantum TLS),
  built-in Shield Blocker WebExtension, find in page, engine-streamed downloads (incl. blob:) into the existing download list.
- Build toolchain raised (Gradle 8.14.3, AGP 8.10.1, Kotlin 2.2.20, compileSdk 36); flavor `classic` is the old WebView build.
- See GECKO.md: what is verified, what is not, known gaps. Not compiled by the author — expect first-build fixes.

## 0.2.0 — Review fixes + five features (unreleased)
### Added
- **Encrypted local settings**: AES-256-GCM file with a non-exportable Android Keystore key replaces the plain SharedPreferences XML (one-time migration + secure wipe). Status row in Settings.
- **`blob:` downloads**: acknowledged chunk streaming from the page (`ShieldDownload` bridge), per-site policy and dialog applied before any byte is accepted, 2 GB cap, cancel from Downloads/notification.
- **Download notifications**: progress/paused/finished/failed with Pause/Resume/Cancel/Retry, aggregate foreground service (`dataSync`), Android 13+ permission requested at the first download (and again when you switch the setting on later); private downloads show no file names; setting to turn it off. A late "Cancel" tap can no longer turn a finished download into a cancelled one.
- **Find in page**: find bar with match counter, next/previous, menu entry, Ctrl+F; cleared on navigation/tab switch.
- **Tablet layout** (`sw600dp`): top toolbar, two-column tab switcher, centred list/settings screens, bottom sheets expanded and limited to 640dp, Ctrl+L/T/W shortcuts; the activity re-creates when the smallest width class changes (fold/unfold) but not on rotation.
### Fixed
- Pause/Cancel of a stalled HTTP download did nothing until the next bytes arrived (the blocking OkHttp call was never cancelled); a resumed download could race with its cancelled predecessor on the same `.part` file.
- HTTPS→HTTP redirect guard ran *after* the plaintext request was sent, and the manually attached `Cookie` header was replayed to other hosts after a redirect. Both are now enforced per hop by a network interceptor.
- Every internal write (saved session, exit flag) re-built the blocker and reloaded scripts in all tabs; internal keys are now ignored by the settings listener.
- Block interstitials for blocked main-frame URLs were stored in history and counted for cookie post-processing.
- `intent:` links could request arbitrary actions; only VIEW/SENDTO/SEND/DIAL are accepted now.
- Imported block lists without `Content-Length` could be read into memory without limit.
- File-name sanitiser only removed U+202E; all bidi controls and zero-width characters are removed now.
- Popup handling created a blank tab before validating the window transport (leaked tab).
- Stats updates for a second tab could be dropped within the 300 ms coalescing window.
- A file chooser left open when the activity was destroyed froze the page's `<input type=file>`.
- Static "New private tab" shortcut targeted the release package, so it failed in debug builds (`.debug` suffix).
- Bottom sheet minimum height (420dp) clipped the buttons on landscape phones.

## 0.1.0 — MVP (unreleased)
- WebView engine with request interception: ad/tracker/miner/malware rule engine (domain, URL, resource, script rules; categories; allow/block lists; per-site shield).
- Tracking-parameter cleaner and redirect-shim unwrapping; HTTPS-only with interstitials; TLS error warning pages.
- Fingerprint protection modes (Off/Standard/Strict/Maximum), User-Agent manager (13 profiles + custom), WebRTC, referrer and clipboard controls.
- Cookie manager (third-party blocking, per-site policy, clear on exit, session-only), private tabs with isolated WebView profiles, strict site isolation.
- Per-site permissions, popup/redirect/dialog/auto-download protection, external-app confirmation.
- Download manager (resume, SHA-256, risk warnings, APK gate), Downloads/Files screen with categories.
- History, bookmarks, reading list, tab groups/search/restore, privacy dashboard, security info, session report, developer tools.
- Material 3 UI, light/dark, English/Arabic/Persian with RTL.
- Unit tests (rules, URL cleaner, URL input, download safety, tab model, UA profiles, script config) and instrumentation tests (storage, settings, downloads, private mode).
