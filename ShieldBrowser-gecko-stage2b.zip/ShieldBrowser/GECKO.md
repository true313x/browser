# ShieldBrowser on GeckoView (flavor `gecko`) — Stage 1

ShieldBrowser now has two build flavors:

| Flavor | Engine | Status |
|---|---|---|
| `classic` | Android System WebView | The stable build you already have. Unchanged. |
| `gecko` | **GeckoView** (Mozilla's engine, independent of Chromium) | **Stage 1 preview.** New browser screen, engine-level protections, Material 3 UI. Never compiled or run by the author of this change — see "What is and is not verified". |

The `gecko` APK contains both screens (two launcher icons) so you can compare them side by side. A compile error in the
Gecko code cannot break the `classic` build.

## Build

```
gradle :app:testClassicDebugUnitTest          # JVM unit tests (shared code, incl. the protection-level table)
gradle :app:assembleClassicDebug              # stable WebView build
gradle :app:assembleGeckoDebug                # Gecko build (needs network once: GeckoView is ~100 MB)
```

* `gradle.properties` → `geckoview.version` and `geckoview.abi` (`arm64-v8a` for phones, `x86_64` for the emulator).
  Pick a version from <https://maven.mozilla.org/?prefix=maven2/org/mozilla/geckoview/geckoview-omni-arm64-v8a/>.
  The pinned value was taken from a public listing and **not resolved by the author**: if Gradle says it cannot find it, choose the newest listed.
* **Update GeckoView regularly (about every 4 weeks).** Every Gecko release carries security fixes; an old engine is the
  biggest risk of a privacy browser. Turn on Dependabot/Renovate for `geckoview.version`.
* The toolchain was raised for GeckoView's dependencies: Gradle 8.14.3, AGP 8.10.1, Kotlin 2.2.20, compileSdk 36.

## Layers of protection (all in `app/src/gecko`, table in `app/src/main/.../privacy/GeckoPrefs.kt`)

1. **Runtime settings** (`GeckoEngine.create`): Enhanced Tracking Protection STRICT (ads, analytics, social, cryptominers,
   fingerprinters), Total Cookie Protection (`ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS`), cookie purging, query-parameter
   stripping, HTTPS-only, DNS-over-HTTPS (from your DNS settings), Global Privacy Control, Safe Browsing, no `about:config`,
   no remote debugging, no login autofill.
2. **Gecko preferences by level** (`GeckoPrefs`, applied with `GeckoPreferenceController`): Standard / Strict / Maximum.
   Lowering the level writes the "off" value back, because Gecko keeps user-branch values. Includes the hybrid
   post-quantum TLS switches (`security.tls.enable_kyber`, `network.http.http3.enable_kyber`).
3. **Built-in "Shield Blocker" WebExtension** (`assets/shield-ext`): cancels sub-resource requests to hosts on the bundled
   list. **The bundled list is small (233 domains, 29 never-block hosts)** — it is a safety net, not the main blocker.
4. **Native start page** with customizable background (presets, own photo, blur, dimming) and Material 3 accent palettes
   or wallpaper colours (Android 12+).

### About "100× stronger"
Nobody can honestly promise a multiplier, so here is what actually changed and how to check it:

* Old blocker: ~233 domains + a few URL patterns, applied in Java; fingerprint "protection" was JavaScript patched
  into pages (which pages can detect and sometimes bypass).
* New: engine-level lists (Disconnect, maintained by Mozilla), Total Cookie Protection, and the engine's own
  fingerprinting protection / resistFingerprinting (done inside Gecko, not by page-visible JS patches).
* **Measure it:** menu → Shield → *Privacy lab* opens EFF Cover Your Tracks, CreepJS, BrowserLeaks and an IP/DNS/WebRTC
  leak test. Run each in `classic` and in `gecko` at *Standard*, *Strict* and *Maximum* and compare. Keep the results.
* Strongest ad blocking additionally needs filter lists + cosmetic filtering (uBlock Origin). Installing it needs
  `WebExtensionController` install/permission prompts that are **not implemented yet** (Stage 2).

## What is and is not verified

Verified against Mozilla's published API docs (mozilla-central javadoc, 2026-10-13/14): `ContentBlocking.Settings.Builder`
methods and `CookieBehavior`, `BlockEvent`, `GeckoRuntimeSettings.Builder` (there is **no** fingerprinting setter, which is
why preferences are used), `GeckoPreferenceController.setGeckoPrefs`, `GeckoResult.accept(Consumer…)`,
`NavigationDelegate.onLocationChange(…, hasUserGesture)`, `PromptDelegate` choice/auth/file prompts (**file prompts need
`file://` Uris, so picked files are copied to the cache first**), `SessionFinder.find/clear`, Maven coordinates.

NOT verified (written from knowledge of the API, never compiled): the rest of the delegate method signatures
(`onExternalResponse`, `onContextMenu`, `ButtonPrompt.Type`, `TextPrompt.confirm`, `ensureBuiltIn`, `MessageDelegate`,
`SafeBrowsing.DEFAULT`, `HTTPS_ONLY`, `TRR_MODE_FIRST`, `StorageController.ClearFlags.ALL`), the exact behaviour of each
Gecko pref on Android, and the whole UI. Expect a handful of compile errors on the first build; paste the log and they
are one-line fixes. Please run `assembleGeckoDebug` first and report.

## Known gaps in Stage 1 (not ported yet)
* `<input type=date/time/color>` pickers and the share sheet prompt (default: dismissed).
* Per-site settings other than "downloads" (per-site JS/cookies/permissions are not enforced in the Gecko screen).
* Visited-link colouring (no HistoryDelegate: all links look unvisited — privacy-positive), session restore keeps URLs only.
* Tablet-specific layout for the Gecko screen, tab strip, reader mode, per-tab desktop mode.
* Install of uBlock Origin / other add-ons, per-site "no scripts" via CSP.
* Downloads from the Gecko screen cannot be paused/resumed (the engine hands over a stream).

## Stage 2 — encryption, tamper response, payment protection (code written, NOT compiled)

**Verified against published docs (2026-10-17):** `WebExtensionController.ensureBuiltIn` / `setAllowedInPrivateBrowsing`,
`WebExtension.SessionController.setMessageDelegate` (content-script messages go to the *session* delegate),
`StorageController.ClearFlags.ALL` and `clearDataForSessionContext`, `GeckoSessionSettings.Builder.contextId`,
Bouncy Castle ≥ 1.84 ML-KEM package/class names (`org.bouncycastle.crypto.{params,generators,kems}.MLKEM*`; the old
`pqc.crypto.mlkem` copies are deprecated), SQLCipher-for-Android 4.19.0 + `androidx.sqlite:sqlite:2.7.0` coordinates.
Also verified: `SecurityInformation.isException`, `GeckoSessionSettings.Builder.contextId`/`usePrivateMode`.
**Still unverified:** the exact `net.zetetic…SQLiteDatabase.openOrCreateDatabase(String, String, null, null, null)` overload,
`ContentBlocking`/prompt signatures listed above, and everything at runtime. See REVIEW.md (findings, open items, device checklist) and ROADMAP.md.
Run `./gradlew testClassicDebugUnitTest testGeckoDebugUnitTest` first (crypto, payment guard, integrity parsers, prefs, PSP-list sync)
and `node app/src/gecko/js-test/payment.test.js` (passes here).

### Bugs fixed on the way
* **`ShieldApp.onCreate` ran the whole container in every Gecko child process** (`:tab`, `:gpu`, `:socket` … live inside this
  package and each creates the Application). Several writers on the encrypted settings file, start-up cleanup re-run in
  children. Now only the main process initialises (`ProcessUtil`).
* **The Shield Blocker did not run in private tabs** (extensions are off there by default) → `setAllowedInPrivateBrowsing`.
* **A repeated POST (payment) was re-sent silently** (`onRepostConfirmPrompt` always ALLOW) → now asks.
* Payment URLs (tokens in the path) were stored in history and in the saved session → excluded for payment tabs.
* `file:`, `content:`, `javascript:`, `data:`, `ftp:` top-level loads were handed to the "open in another app" prompt → denied.
* Gecko flavour no longer allows cleartext traffic for the app's own HTTP stack.
* Plain SQLite history/bookmarks/rules/downloads list → **SQLCipher**, key = HKDF(Keystore-wrapped master key); an existing plaintext
  `shield.db` is migrated table-by-table, verified by row counts, swapped, and the plaintext file overwritten. On any failure
  the plaintext file is kept (no data loss); if the key is lost the unreadable file is replaced by an empty one instead of crashing.

### Kyber / post-quantum (what it does and what it cannot)
* `crypto/HybridKem.kt`: **X25519 + ML-KEM-768** hybrid KEM (secret is safe if either holds), HKDF-SHA256 combiner that binds
  both ciphertexts and the recipient key. `SealedBox`: KEM → AES-256-GCM public-key encryption. `PassphraseWrap`: Argon2id → AES-GCM.
* Used for **backups/exports** (`.shieldvault`, sealed to the device key, authenticated with an HMAC derived from the private
  key so a forged file made with the *public* key is refused) and the **recovery key** (`.shieldkey`, passphrase-protected).
  That is where harvest-now-decrypt-later matters: data that leaves the device.
* Local data at rest is AES-256 (SQLCipher / AES-GCM), which quantum computers do not break in any known way; adding a KEM there
  would add nothing. **Website TLS** gets its post-quantum hybrid from Gecko, not from app code.

### Tamper response → Sealed Mode (`security/`)
Signals: debugger, ptrace tracer, debuggable repack, signature ≠ `shield.certSha256`, Frida/Xposed/LSPosed markers (maps, threads,
stack), frida-server port (warn), root (warn), emulator (warn). On a CRITICAL one (policy "Seal", default): flag written
synchronously → `SealedActivity` starts in its own process `:sealed` (no container, DB, keys, GeckoView, nothing to steal)
→ every other app process is killed → Gecko profile, WebView data, caches, clipboard are deleted → normal start-up is blocked
until the owner passes the system biometric/PIN prompt. "Seal + wipe" also destroys DB, settings and Keystore keys.
**Honest limit:** these checks run inside a process an attacker with root may already control; this is deterrence and damage
limiting (the sessions are gone, the process is dead), not an impenetrable container. No Android app can promise that.

### Payment protection
* **Secure Payment tab** (menu, or offered when a payment page is detected): private, own Gecko storage context deleted on close,
  https only, no downloads / permissions / external apps / blob:, never in history or saved session, optional biometric first,
  idle auto-close (5 min), device check first (root/emulator/hooking/third-party keyboard/screen-reader app → warn or refuse).
* **Every payment page** (provider domain, `/checkout`-style path, or card fields seen by the extension — field *contents* are never read):
  `FLAG_SECURE` (no screenshots/recording/casting, blank recents), `filterTouchesWhenObscured` + `setHideOverlayWindows`
  (overlay/tap-jacking), autofill and accessibility-data off for the page view, Gecko card/address/login autofill off, CRLite enforced.
* **Phishing guard:** lookalike domains (paypa1.com, paypal.com.evil.net, secure-paypal.com, homoglyph/mixed-script IDN), userinfo `@`,
  raw IPs, odd ports, certificate exceptions, not-https → warning; blocking in a Secure Payment tab.
* **Paranoid checkout** (opt-in): on payment pages, third-party script / XHR / beacon / WebSocket outside the provider list are
  cancelled (Magecart skimmers). Some checkouts will break; that is why it is opt-in.
* Not stoppable by app code: a keylogging keyboard, root malware, a compromised merchant server, a phone you cannot trust.
* Added: encrypted-backup flows, biometric **app lock** (UI-level, does not wrap keys), Security Center sheet (menu).

### Still not done
Crypto-bound biometrics (keys that need a fresh fingerprint per use), a decoy browsing session inside the sealed process,
per-site Gecko settings, date/time pickers, pause/resume of Gecko downloads, add-on install. Stage-1 gap list above still applies.
