# WebView message listeners / JS bridges are not used via @JavascriptInterface reflection.
-keepattributes SourceFile,LineNumberTable
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# SQLCipher: JNI calls back into these classes by name.
-keep class net.zetetic.database.** { *; }
-dontwarn net.zetetic.database.**
# Bouncy Castle is used through direct references only (no reflection / service loading), R8 may shrink it freely.
