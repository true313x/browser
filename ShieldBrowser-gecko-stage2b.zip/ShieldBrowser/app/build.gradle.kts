plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shieldbrowser.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.shieldbrowser.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        // SHA-256 (hex, no colons; several separated by commas) of the certificate you sign RELEASE builds with.
        // When set, TamperMonitor treats a different signer (= repackaged APK) as a critical tamper signal.
        // Get it with: apksigner verify --print-certs app-release.apk   (see SECURITY.md)
        val certPin = providers.gradleProperty("shield.certSha256").getOrElse("").replace(":", "").replace(" ", "")
        // A typo here would make EVERY launch look like a repackaged app (Sealed Mode every time): fail the build instead.
        require(certPin.isEmpty() || certPin.split(',').all { Regex("[0-9a-fA-F]{64}").matches(it) }) {
            "shield.certSha256 must be one or more 64-hex-digit SHA-256 digests separated by commas"
        }
        buildConfigField("String", "EXPECTED_CERT_SHA256", "\"" + certPin + "\"")
    }

    androidResources { localeFilters += listOf("en", "ar", "fa") }

    // "classic" = system WebView (the existing, stable build). "gecko" = Mozilla's GeckoView engine (new, in progress).
    flavorDimensions += "engine"
    productFlavors {
        create("classic") { dimension = "engine" }
        create("gecko") {
            dimension = "engine"
            versionNameSuffix = "-gecko"
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Signing is intentionally NOT configured here (no secrets in the repo).
            // See README.md > "Signing a release build".
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    testOptions { unitTests.isReturnDefaultValues = true }
    lint { abortOnError = false }
    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/versions/9/OSGI-INF/MANIFEST.MF", "META-INF/versions/**/OSGI-INF/MANIFEST.MF")
    }
}

kotlin {
    compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) }
}

val geckoViewVersion = providers.gradleProperty("geckoview.version").get()
val geckoAbi = providers.gradleProperty("geckoview.abi").getOrElse("arm64-v8a")

dependencies {
    // Engine of the "gecko" flavor only; the classic flavor does not contain it.
    "geckoImplementation"("org.mozilla.geckoview:geckoview-omni-$geckoAbi:$geckoViewVersion")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // OkHttp is used ONLY for the app's own traffic (downloads, optional rule-list import)
    // so that DNS-over-HTTPS can be honoured there. Page traffic uses Chromium's network stack.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.12.0")

    // Post-quantum hybrid KEM (X25519 + ML-KEM-768/Kyber), HKDF and Argon2id. Pinned: >= 1.84 has the non-deprecated
    // org.bouncycastle.crypto.{params,generators,kems}.MLKEM* classes used in crypto/HybridKem.kt.
    implementation("org.bouncycastle:bcprov-jdk18on:1.84")
    // Biometric / device-credential prompt (app lock, secure payment tab, sealed-mode unlock).
    implementation("androidx.biometric:biometric:1.1.0")
    // Encrypted local database (history, bookmarks, site rules, downloads list). The @aar form does not pull
    // transitive dependencies, so androidx.sqlite is listed explicitly (as the SQLCipher README requires).
    implementation("net.zetetic:sqlcipher-android:4.19.0@aar")
    implementation("androidx.sqlite:sqlite:2.7.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:core-ktx:1.6.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
}
