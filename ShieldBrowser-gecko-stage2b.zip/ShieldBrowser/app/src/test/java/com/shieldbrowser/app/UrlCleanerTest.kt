package com.shieldbrowser.app

import com.shieldbrowser.app.privacy.UrlCleaner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test

class UrlCleanerTest {
    @Test fun removesUtmAndClickIds() =
        assertEquals("https://example.com/page", UrlCleaner.clean("https://example.com/page?utm_source=x&fbclid=123"))

    @Test fun keepsOtherParamsAndFragment() =
        assertEquals("https://example.com/?q=kotlin&id=5#top", UrlCleaner.clean("https://example.com/?q=kotlin&utm_medium=email&id=5#top"))

    @Test fun returnsSameInstanceWhenNothingToClean() {
        val u = "https://example.com/a?x=1"
        assertSame(u, UrlCleaner.clean(u))
    }

    @Test fun removesGclidMsclkidDclid() =
        assertEquals("https://a.org/", UrlCleaner.clean("https://a.org/?gclid=1&msclkid=2&dclid=3"))

    @Test fun hostSpecificYoutubeShareId() =
        assertEquals("https://www.youtube.com/watch?v=abc", UrlCleaner.clean("https://www.youtube.com/watch?v=abc&si=XYZ"))

    @Test fun hostSpecificAmazon() =
        assertEquals("https://www.amazon.com/dp/B000?keywords=book",
            UrlCleaner.clean("https://www.amazon.com/dp/B000?ref=nav&th=1&pf_rd_r=XYZ&keywords=book"))

    @Test fun nonWebUrlsUntouched() {
        val u = "mailto:a@b.com?utm_source=x"
        assertSame(u, UrlCleaner.clean(u))
    }

    @Test fun unwrapsGoogleRedirect() =
        assertEquals("https://example.org/p",
            UrlCleaner.unwrapRedirect("https://www.google.com/url?sa=t&q=https%3A%2F%2Fexample.org%2Fp&usg=abc"))

    @Test fun unwrapsFacebookShim() =
        assertEquals("https://example.org/", UrlCleaner.unwrapRedirect("https://l.facebook.com/l.php?u=https%3A%2F%2Fexample.org%2F&h=AT0"))

    @Test fun ordinaryUrlIsNotAWrapper() = assertNull(UrlCleaner.unwrapRedirect("https://example.com/url?q=https://x.y"))

    @Test fun refusesNonHttpTargets() =
        assertNull(UrlCleaner.unwrapRedirect("https://www.google.com/url?q=javascript%3Aalert(1)"))
}
