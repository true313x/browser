package com.shieldbrowser.app

import com.shieldbrowser.app.crypto.HybridKem
import com.shieldbrowser.app.crypto.HybridPrivateKey
import com.shieldbrowser.app.crypto.HybridPublicKey
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.GeneralSecurityException

class HybridKemTest {
    @Test fun roundTripGivesTheSameSecret() {
        val kp = HybridKem.generate()
        val (enc, secret) = HybridKem.encapsulate(kp.pub)
        assertEquals(32, secret.size)
        assertEquals(HybridKem.MLKEM768_CT, enc.mlkemCt.size)
        assertArrayEquals(secret, HybridKem.decapsulate(kp.priv, enc))
    }

    @Test fun eachEncapsulationIsFresh() {
        val kp = HybridKem.generate()
        val (e1, s1) = HybridKem.encapsulate(kp.pub)
        val (e2, s2) = HybridKem.encapsulate(kp.pub)
        assertFalse(s1.contentEquals(s2))
        assertFalse(e1.mlkemCt.contentEquals(e2.mlkemCt))
    }

    @Test fun anotherKeyCannotDerivePeersSecret() {
        val a = HybridKem.generate()
        val b = HybridKem.generate()
        val (enc, secret) = HybridKem.encapsulate(a.pub)
        // ML-KEM uses implicit rejection (returns a pseudo-random secret), the combiner binds the recipient key too.
        val other = try { HybridKem.decapsulate(b.priv, enc) } catch (_: GeneralSecurityException) { null }
        if (other != null) assertFalse(other.contentEquals(secret))
    }

    @Test fun keysSurviveEncodeDecode() {
        val kp = HybridKem.generate()
        val pub2 = HybridPublicKey.decode(kp.pub.encode())
        val priv2 = HybridPrivateKey.decode(kp.priv.encode())     // also proves the ML-KEM private-key encoding round-trips
        val (enc, secret) = HybridKem.encapsulate(pub2)
        assertArrayEquals(secret, HybridKem.decapsulate(priv2, enc))
        assertEquals(kp.pub.fingerprint(), pub2.fingerprint())
    }

    @Test fun fingerprintLooksRight() {
        val fp = HybridKem.generate().pub.fingerprint()
        assertTrue(fp, Regex("([0-9a-f]{4} ){7}[0-9a-f]{4}").matches(fp))
        assertNotEquals(fp, HybridKem.generate().pub.fingerprint())
    }

    @Test(expected = GeneralSecurityException::class)
    fun truncatedPublicKeyIsRejected() {
        HybridPublicKey.decode(HybridKem.generate().pub.encode().copyOf(50))
    }
}
