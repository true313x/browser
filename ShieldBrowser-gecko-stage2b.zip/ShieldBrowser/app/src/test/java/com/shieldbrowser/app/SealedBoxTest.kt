package com.shieldbrowser.app

import com.shieldbrowser.app.crypto.HybridKem
import com.shieldbrowser.app.crypto.SealedBox
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import java.security.GeneralSecurityException

class SealedBoxTest {
    private val kp = HybridKem.generate()
    private val msg = "bookmarks + settings \u0627\u062e\u062a\u0628\u0627\u0631".toByteArray()

    @Test fun sealAndOpen() {
        val blob = SealedBox.seal(kp.pub, msg)
        assertArrayEquals(msg, SealedBox.open(kp.priv, blob))
    }

    @Test fun plaintextIsNotVisibleInTheBlob() {
        val blob = SealedBox.seal(kp.pub, "SECRET-MARKER-SECRET".toByteArray())
        assertFalse(String(blob, Charsets.ISO_8859_1).contains("SECRET-MARKER"))
    }

    @Test fun contextMustMatch() {
        val blob = SealedBox.seal(kp.pub, msg, "ctx-a".toByteArray())
        assertArrayEquals(msg, SealedBox.open(kp.priv, blob, "ctx-a".toByteArray()))
        try { SealedBox.open(kp.priv, blob, "ctx-b".toByteArray()); throw AssertionError("opened with the wrong context") }
        catch (_: GeneralSecurityException) { }
    }

    @Test fun anyBitFlipIsDetected() {
        val blob = SealedBox.seal(kp.pub, msg)
        for (pos in listOf(blob.size - 1, blob.size - 20, blob.size / 2, 40)) {
            val bad = blob.copyOf().also { it[pos] = (it[pos].toInt() xor 1).toByte() }
            try { SealedBox.open(kp.priv, bad); throw AssertionError("flip at $pos was not detected") }
            catch (_: GeneralSecurityException) { }
        }
    }

    @Test fun wrongRecipientCannotOpen() {
        val blob = SealedBox.seal(kp.pub, msg)
        try { SealedBox.open(HybridKem.generate().priv, blob); throw AssertionError("opened with a foreign key") }
        catch (_: GeneralSecurityException) { }
    }

    @Test fun garbageIsRejectedCleanly() {
        for (g in listOf(ByteArray(0), ByteArray(3), ByteArray(100) { 7 })) {
            try { SealedBox.open(kp.priv, g); throw AssertionError("garbage accepted") } catch (_: GeneralSecurityException) { }
        }
    }
}
