package com.shieldbrowser.app

import com.shieldbrowser.app.downloads.BlobProtocol
import com.shieldbrowser.app.downloads.BlobProtocol.Msg
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BlobProtocolTest {
    private val sid = "0123456789abcdef0123456789abcdef"

    @Test fun parsesMetadataWithPercentEncodedFields() {
        val m = BlobProtocol.parse("M|$sid|1000|application%2Fpdf|%D9%85%D9%84%D9%81.pdf") as Msg.Meta
        assertEquals(1000L, m.size); assertEquals("application/pdf", m.type); assertEquals("\u0645\u0644\u0641.pdf", m.name)
    }

    @Test fun pipeInFileNameSurvives() {
        val m = BlobProtocol.parse("M|$sid|1|text%2Fplain|a%7Cb.txt") as Msg.Meta
        assertEquals("a|b.txt", m.name)
    }

    @Test fun parsesChunkDoneAndFailure() {
        val c = BlobProtocol.parse("C|$sid|3|QUJD") as Msg.Chunk
        assertEquals(3, c.seq); assertEquals("QUJD", c.b64)
        assertEquals(Msg.Done(sid), BlobProtocol.parse("D|$sid"))
        assertEquals(Msg.Failed(sid, "HTTP 404"), BlobProtocol.parse("E|$sid|HTTP%20404"))
    }

    @Test fun rejectsMalformedMessages() {
        assertNull(BlobProtocol.parse(null))
        assertNull(BlobProtocol.parse(""))
        assertNull(BlobProtocol.parse("X|$sid|1"))                                  // unknown kind
        assertNull(BlobProtocol.parse("M|nothex|1|a|b"))                           // bad session id
        assertNull(BlobProtocol.parse("M|${sid.uppercase()}|1|a|b"))               // session ids are lower-case hex
        assertNull(BlobProtocol.parse("M|$sid|-5|a|b"))                            // negative size
        assertNull(BlobProtocol.parse("M|$sid|abc|a|b"))                           // size not a number
        assertNull(BlobProtocol.parse("M|$sid|1|a"))                               // missing field
        assertNull(BlobProtocol.parse("C|$sid|-1|QUJD"))                           // negative sequence
        assertNull(BlobProtocol.parse("C|$sid|1|"))                                // empty chunk
        assertNull(BlobProtocol.parse("D|short"))
        assertNull(BlobProtocol.parse("C|$sid|0|" + "A".repeat(BlobProtocol.MAX_MESSAGE_CHARS)))   // oversized
    }

    @Test fun absurdlyLongNameIsDropped() {
        val m = BlobProtocol.parse("M|$sid|1|a|" + "%41".repeat(5000)) as Msg.Meta
        assertEquals("", m.name)
    }

    @Test fun originOfBlobUrl() {
        assertEquals("https://example.com", BlobProtocol.originOf("blob:https://example.com/3b1f-uuid"))
        assertEquals("https://example.com", BlobProtocol.originOf("blob:https://EXAMPLE.com:443/x"))
        assertEquals("http://localhost:8080", BlobProtocol.originOf("blob:http://localhost:8080/x"))
        assertNull(BlobProtocol.originOf("blob:null/3b1f"))                         // opaque origin
        assertNull(BlobProtocol.originOf("https://example.com/file"))
        assertNull(BlobProtocol.originOf("blob:file:///x"))
    }

    @Test fun senderOriginMustMatchBlobOrigin() {
        val o = BlobProtocol.originOf("blob:https://example.com/u")!!
        assertTrue(BlobProtocol.sameOrigin(o, "https://example.com"))
        assertTrue(BlobProtocol.sameOrigin(o, "https://example.com:443"))
        assertFalse(BlobProtocol.sameOrigin(o, "http://example.com"))
        assertFalse(BlobProtocol.sameOrigin(o, "https://evil.example.com"))
        assertFalse(BlobProtocol.sameOrigin(o, "https://example.com.evil.org"))
        assertFalse(BlobProtocol.sameOrigin(o, "null"))
    }

    @Test fun urlTextCanNeverBecomeAPlaceholder() {
        val tpl = "run(%URL%, %SID%, %CHUNK%)"
        val out = BlobProtocol.fillTemplate(tpl, "blob:https://x.org/%SID%%CHUNK%", sid) { "\"" + it + "\"" }
        assertEquals("run(\"blob:https://x.org/%SID%%CHUNK%\", \"$sid\", ${BlobProtocol.CHUNK_BYTES})", out)
    }

    @Test fun fileNameChoice() {
        assertEquals("report.pdf", BlobProtocol.chooseName("report.pdf", "application/pdf"))
        assertEquals("download.pdf", BlobProtocol.chooseName("", "application/pdf; charset=binary"))
        assertEquals("download.bin", BlobProtocol.chooseName("  ", "application/x-weird"))
        assertEquals("passwd", BlobProtocol.chooseName("../../etc/passwd", ""))      // path tricks are stripped
        assertNotNull(BlobProtocol.chooseName("a\u202Egpj.exe", ""))
        assertFalse(BlobProtocol.chooseName("a\u202Egpj.exe", "").contains('\u202E'))
    }
}
