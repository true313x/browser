package com.shieldbrowser.app

import com.shieldbrowser.app.downloads.DownloadSafety
import com.shieldbrowser.app.downloads.FileCategory
import com.shieldbrowser.app.downloads.RiskLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadSafetyTest {
    @Test fun executableIsHighRisk() {
        val a = DownloadSafety.assess("setup.exe", "application/octet-stream", "https://x.org/setup.exe")
        assertEquals(RiskLevel.HIGH, a.level); assertTrue("executable" in a.reasons)
    }
    @Test fun plainImageIsLow() = assertEquals(RiskLevel.LOW, DownloadSafety.assess("photo.jpg", "image/jpeg", "https://x.org/p.jpg").level)
    @Test fun doubleExtensionDetected() {
        val a = DownloadSafety.assess("invoice.pdf.exe", null, "https://x.org/i")
        assertEquals(RiskLevel.HIGH, a.level); assertTrue("double_extension" in a.reasons)
    }
    @Test fun apkIsFlagged() {
        val a = DownloadSafety.assess("app.apk", "application/vnd.android.package-archive", "https://x.org/a")
        assertEquals(RiskLevel.HIGH, a.level); assertTrue("apk" in a.reasons)
    }
    @Test fun htmlOverHttpIsMediumWithReasons() {
        val a = DownloadSafety.assess("page.html", "text/html", "http://x.org/p")
        assertEquals(RiskLevel.MEDIUM, a.level); assertTrue("active_content" in a.reasons && "insecure_source" in a.reasons)
    }
    @Test fun rtlOverrideSpoofIsHigh() =
        assertEquals(RiskLevel.HIGH, DownloadSafety.assess("photo\u202Egpj.exe", null, "https://x.org/").level)
    @Test fun categories() {
        assertEquals(FileCategory.VIDEO, DownloadSafety.categoryOf("movie.mp4", null))
        assertEquals(FileCategory.ARCHIVE, DownloadSafety.categoryOf("a.zip", null))
        assertEquals(FileCategory.APK, DownloadSafety.categoryOf("x.apk", null))
        assertEquals(FileCategory.DOCUMENT, DownloadSafety.categoryOf("d.pdf", "application/pdf"))
        assertEquals(FileCategory.IMAGE, DownloadSafety.categoryOf("img", "image/png"))
        assertEquals(FileCategory.OTHER, DownloadSafety.categoryOf("x.bin", null))
    }
    @Test fun sanitizeFileName() {
        assertEquals("passwd", DownloadSafety.sanitizeFileName("../../etc/passwd"))
        assertEquals("abc.txt", DownloadSafety.sanitizeFileName("a<b>:c.txt"))
        assertEquals("hidden", DownloadSafety.sanitizeFileName(".hidden"))
        assertEquals("download", DownloadSafety.sanitizeFileName(""))
        assertEquals("download", DownloadSafety.sanitizeFileName(null))
        val long = DownloadSafety.sanitizeFileName("a".repeat(300) + ".pdf")
        assertTrue(long.length <= 120 && long.endsWith(".pdf"))
    }
    @Test fun uniqueName() {
        assertEquals("a (2).txt", DownloadSafety.uniqueName("a.txt") { it == "a.txt" || it == "a (1).txt" })
        assertEquals("noext", DownloadSafety.uniqueName("noext") { false })
    }
    @Test fun sanitizerRemovesBidiAndZeroWidthCharacters() {
        assertEquals("photogpj.exe", DownloadSafety.sanitizeFileName("photo\u202Egpj.exe"))
        assertEquals("ab.txt", DownloadSafety.sanitizeFileName("a\u200Bb\u2066.txt"))
        assertEquals("download", DownloadSafety.sanitizeFileName("\u202E\u200B"))
    }
    @Test fun sanitizerStripsPathsAndTrailingDots() {
        assertEquals("passwd", DownloadSafety.sanitizeFileName("../../etc/passwd"))
        assertEquals("a.txt", DownloadSafety.sanitizeFileName("a.txt. "))
    }
}
