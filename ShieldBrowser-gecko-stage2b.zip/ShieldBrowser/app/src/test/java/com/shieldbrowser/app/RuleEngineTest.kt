package com.shieldbrowser.app

import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.blocking.BlockerConfig
import com.shieldbrowser.app.blocking.PatternParser
import com.shieldbrowser.app.blocking.RuleEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Covers both the ad blocker and the tracker blocker (they share one engine, split by category). */
class RuleEngineTest {
    private lateinit var engine: RuleEngine

    @Before fun setUp() {
        engine = RuleEngine()
        engine.load(
            domains = mapOf(
                "doubleclick.net" to BlockCategory.ADVERTISING,
                "google-analytics.com" to BlockCategory.ANALYTICS,
                "tracker.example" to BlockCategory.TRACKING,
                "connect.facebook.net" to BlockCategory.SOCIAL_TRACKING,
                "coinhive.com" to BlockCategory.CRYPTOMINING,
                "cdn.jsdelivr.net" to BlockCategory.ADVERTISING
            ),
            patterns = PatternParser.parse("url advertising 1 */ads/*\nscript cryptomining 0 *coinhive*\n# comment\nbad line"),
            essential = setOf("cdn.jsdelivr.net")
        )
    }

    private fun eval(url: String, page: String? = "news.example.com", main: Boolean = false) = engine.evaluate(url, page, main)

    @Test fun blocksThirdPartyAdDomainIncludingSubdomains() {
        val d = eval("https://stats.g.doubleclick.net/x.js")
        assertTrue(d.block); assertEquals(BlockCategory.ADVERTISING, d.category); assertTrue(d.thirdParty)
    }

    @Test fun blocksAnalyticsAndSocialTrackers() {
        assertEquals(BlockCategory.ANALYTICS, eval("https://www.google-analytics.com/collect").category)
        assertEquals(BlockCategory.SOCIAL_TRACKING, eval("https://connect.facebook.net/en_US/sdk.js").category)
    }

    @Test fun firstPartyRequestsAreNotBlockedByDomainRules() =
        assertFalse(eval("https://ads.doubleclick.net/x", page = "doubleclick.net").block)

    @Test fun disabledCategoriesAreAllowed() {
        engine.config = BlockerConfig(true, setOf(BlockCategory.ANALYTICS))
        assertFalse(eval("https://ad.doubleclick.net/x").block)
        assertTrue(eval("https://www.google-analytics.com/collect").block)
    }

    @Test fun engineOffAllowsEverything() {
        engine.config = BlockerConfig(false, emptySet())
        assertFalse(eval("https://ad.doubleclick.net/x").block)
    }

    @Test fun mainFrameIsNeverBlockedExceptMiners() {
        assertFalse(eval("https://doubleclick.net/", page = null, main = true).block)
        assertTrue(eval("https://coinhive.com/", page = null, main = true).block)
    }

    @Test fun essentialAllowListWins() = assertFalse(eval("https://cdn.jsdelivr.net/npm/x.js").block)

    @Test fun patternRulesApplyToThirdPartyOnly() {
        assertTrue(eval("https://cdn.other.example/ads/banner.png").block)
        assertFalse(eval("https://news.example.com/ads/banner.png").block)
    }

    @Test fun minerScriptPatternBlocksEvenFirstParty() {
        val d = eval("https://site.com/lib/coinhive.min.js", page = "site.com")
        assertTrue(d.block); assertEquals(BlockCategory.CRYPTOMINING, d.category)
    }

    @Test fun userAllowAndBlockLists() {
        engine.userAllow = setOf("doubleclick.net")
        assertFalse(eval("https://ad.doubleclick.net/x").block)
        engine.userBlock = setOf("annoying.example")
        val d = eval("https://cdn.annoying.example/a.js")
        assertTrue(d.block); assertTrue(d.rule!!.startsWith("user-block"))
    }

    @Test fun perSiteShieldOff() {
        engine.siteShieldOff = { it == "news.example.com" }
        assertFalse(eval("https://ad.doubleclick.net/x").block)
        assertTrue(eval("https://ad.doubleclick.net/x", page = "other.org").block)
    }

    @Test fun ruleCountsAndClassification() {
        assertEquals(6, engine.domainRuleCount()); assertEquals(2, engine.patternRuleCount())
        assertEquals(BlockCategory.TRACKING, engine.classifyHost("a.b.tracker.example"))
    }
}
