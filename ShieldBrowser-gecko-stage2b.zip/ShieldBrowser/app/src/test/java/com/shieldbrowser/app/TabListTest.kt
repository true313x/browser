package com.shieldbrowser.app

import com.shieldbrowser.app.tabs.TabList
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Tab manager model + private-mode separation. */
class TabListTest {
    @Test fun openSelectsNewTab() {
        val l = TabList(); val a = l.open("https://a.org", false); val b = l.open("https://b.org", false)
        assertEquals(b.id, l.activeId); assertEquals(listOf(a.id, b.id), l.tabs.map { it.id })
    }

    @Test fun closingActiveSelectsNeighbourOfSamePrivacy() {
        val l = TabList(); val n1 = l.open("https://1", false); l.open("https://p", true); val n2 = l.open("https://2", false)
        l.close(n2.id)
        assertEquals(n1.id, l.activeId)
    }

    @Test fun closingLastTabLeavesNoActive() {
        val l = TabList(); val a = l.open("https://a", false); l.close(a.id)
        assertEquals(-1L, l.activeId); assertTrue(l.tabs.isEmpty())
    }

    @Test fun duplicateInsertsAfterSourceAndSelects() {
        val l = TabList(); val a = l.open("https://a", false); l.open("https://b", false)
        val d = l.duplicate(a.id)!!
        assertEquals(1, l.tabs.indexOf(d)); assertEquals("https://a", d.url); assertEquals(d.id, l.activeId)
    }

    @Test fun restoreClosedTabsButNeverPrivateOnes() {
        val l = TabList()
        val a = l.open("https://a.org", false).also { it.title = "A" }
        val p = l.open("https://secret.org", true)
        l.close(a.id); l.close(p.id)
        assertEquals(1, l.recentlyClosed().size)
        val r = l.restoreClosed()!!
        assertEquals("https://a.org", r.url); assertEquals("A", r.title); assertNull(l.restoreClosed())
    }

    @Test fun blankTabsAreNotRemembered() {
        val l = TabList(); val a = l.open("", false); l.close(a.id)
        assertTrue(l.recentlyClosed().isEmpty())
    }

    @Test fun closeAllCanTargetPrivateTabsOnly() {
        val l = TabList(); l.open("https://a", false); l.open("https://p1", true); l.open("https://p2", true)
        l.closeAll(privateOnly = true)
        assertEquals(1, l.tabs.size); assertEquals(0, l.count(true)); assertEquals(1, l.count(false))
        assertTrue(l.active() != null && !l.active()!!.isPrivate)
    }

    @Test fun searchMatchesTitleAndUrl() {
        val l = TabList(); l.open("https://kotlinlang.org", false).title = "Kotlin"; l.open("https://example.com", false)
        assertEquals(1, l.search("kotlin").size); assertEquals(1, l.search("EXAMPLE").size); assertEquals(2, l.search("").size)
    }

    @Test fun groups() {
        val l = TabList(); val a = l.open("https://a", false); val g = l.createGroup("Work")
        l.assign(a.id, g.id); assertEquals(g.id, a.groupId)
        l.assign(a.id, 999L); assertNull(a.groupId)      // unknown group is ignored
        l.assign(a.id, g.id); l.deleteGroup(g.id); assertNull(a.groupId); assertTrue(l.groups.isEmpty())
    }

    @Test fun restoreFromSession() {
        val l = TabList(); l.restore(listOf(Triple("https://a", "A", null), Triple("https://b", "B", null)), 1)
        assertEquals(2, l.tabs.size); assertEquals("https://b", l.active()!!.url)
    }
}
