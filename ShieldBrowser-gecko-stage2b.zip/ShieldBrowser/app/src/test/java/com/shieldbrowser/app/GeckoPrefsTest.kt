package com.shieldbrowser.app

import com.shieldbrowser.app.privacy.GeckoPrefs
import com.shieldbrowser.app.privacy.ProtectionLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GeckoPrefsTest {
    private fun map(l: ProtectionLevel) = GeckoPrefs.plan(l).toMap()

    @Test fun namesAreUniqueAndTypesSupported() {
        val names = GeckoPrefs.all.map { it.name }
        assertEquals(names.size, names.toSet().size)
        for (p in GeckoPrefs.all) {
            assertTrue(p.name, p.value is Boolean || p.value is Int || p.value is String)
            val off = p.offValue
            if (off != null) assertEquals(p.name, p.value::class, off::class)     // off value has the same type
        }
    }

    @Test fun standardPrefsAreActiveAtEveryLevel() {
        for (p in GeckoPrefs.all.filter { it.minLevel == ProtectionLevel.STANDARD })
            for (l in ProtectionLevel.values()) assertEquals(p.name, p.value, map(l)[p.name])
    }

    @Test fun higherLevelsActivateMorePrefs() {
        fun active(l: ProtectionLevel) = GeckoPrefs.all.count { l.ordinal >= it.minLevel.ordinal }
        assertTrue(active(ProtectionLevel.STANDARD) < active(ProtectionLevel.STRICT))
        assertTrue(active(ProtectionLevel.STRICT) < active(ProtectionLevel.MAXIMUM))
    }

    @Test fun loweringTheLevelSwitchesStrongPrefsBackOff() {
        assertEquals(true, map(ProtectionLevel.MAXIMUM)["privacy.resistFingerprinting"])
        assertEquals(false, map(ProtectionLevel.STRICT)["privacy.resistFingerprinting"])
        assertEquals(false, map(ProtectionLevel.STANDARD)["webgl.disabled"])
        assertEquals(true, map(ProtectionLevel.STANDARD)["media.peerconnection.enabled"])
        assertEquals("", map(ProtectionLevel.STANDARD)["privacy.fingerprintingProtection.overrides"])
        assertEquals("+AllTargets", map(ProtectionLevel.STRICT)["privacy.fingerprintingProtection.overrides"])
    }

    @Test fun postQuantumTlsIsOnAtEveryLevel() {
        for (l in ProtectionLevel.values()) {
            assertEquals(true, map(l)["security.tls.enable_kyber"])
            assertEquals(true, map(l)["network.http.http3.enable_kyber"])
        }
    }

    @Test fun webRtcLeakProtectionIsOnAtEveryLevel() {
        for (l in ProtectionLevel.values()) assertEquals(true, map(l)["media.peerconnection.ice.default_address_only"])
    }

    @Test fun paymentAutofillAndLoginStorageAreOffAtEveryLevel() {
        for (l in ProtectionLevel.values()) {
            assertEquals(false, map(l)["extensions.formautofill.creditCards.enabled"])
            assertEquals(false, map(l)["signon.rememberSignons"])
            assertEquals(2, map(l)["security.pki.crlite_mode"])
        }
        assertEquals(false, map(ProtectionLevel.STANDARD)["security.ssl.require_safe_negotiation"])
        assertEquals(true, map(ProtectionLevel.STRICT)["security.ssl.require_safe_negotiation"])
    }

    @Test fun levelParsingFallsBackToStrict() {
        assertEquals(ProtectionLevel.STRICT, ProtectionLevel.of(null))
        assertEquals(ProtectionLevel.STRICT, ProtectionLevel.of("nonsense"))
        assertEquals(ProtectionLevel.MAXIMUM, ProtectionLevel.of("maximum"))
        assertFalse(ProtectionLevel.of("standard") == ProtectionLevel.MAXIMUM)
    }
}
