package com.shieldbrowser.app

import com.shieldbrowser.app.crypto.PassphraseWrap
import org.junit.Assert.assertArrayEquals
import org.junit.Test
import java.security.GeneralSecurityException

class PassphraseWrapTest {
    private val cheap = PassphraseWrap.Cost(memoryKiB = 64, iterations = 1, parallelism = 1)   // fast for unit tests only
    private val secret = ByteArray(2000) { (it * 31).toByte() }

    @Test fun roundTrip() {
        val blob = PassphraseWrap.wrap(secret, "correct horse".toCharArray(), cheap)
        assertArrayEquals(secret, PassphraseWrap.unwrap(blob, "correct horse".toCharArray()))
    }

    @Test fun wrongPassphraseFails() {
        val blob = PassphraseWrap.wrap(secret, "correct horse".toCharArray(), cheap)
        try { PassphraseWrap.unwrap(blob, "wrong".toCharArray()); throw AssertionError("accepted") } catch (_: GeneralSecurityException) { }
    }

    @Test fun headerTamperingFails() {
        val blob = PassphraseWrap.wrap(secret, "pw".toCharArray(), cheap)
        val bad = blob.copyOf().also { it[10] = (it[10].toInt() xor 1).toByte() }    // changes the stored cost -> key and AAD differ
        try { PassphraseWrap.unwrap(bad, "pw".toCharArray()); throw AssertionError("accepted") } catch (_: GeneralSecurityException) { }
    }

    @Test fun hugeMemoryRequestIsRefused() {
        val blob = PassphraseWrap.wrap(secret, "pw".toCharArray(), cheap)
        val bad = blob.copyOf()
        bad[5] = 0x7f                                   // memKiB high byte -> ~2 GiB
        try { PassphraseWrap.unwrap(bad, "pw".toCharArray()); throw AssertionError("accepted") } catch (_: GeneralSecurityException) { }
    }
}
