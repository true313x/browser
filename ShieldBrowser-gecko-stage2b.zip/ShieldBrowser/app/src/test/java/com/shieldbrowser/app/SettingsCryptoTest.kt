package com.shieldbrowser.app

import com.shieldbrowser.app.storage.AesGcmCipher
import com.shieldbrowser.app.storage.EncryptedSettingsStore
import com.shieldbrowser.app.storage.SettingsCodec
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import javax.crypto.spec.SecretKeySpec

class SettingsCryptoTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun cipher(seed: Int = 1) = AesGcmCipher { SecretKeySpec(ByteArray(32) { (it + seed).toByte() }, "AES") }

    private val sample: Map<String, Any> = mapOf(
        "b" to true, "i" to 42, "l" to 1234567890123L, "f" to 1.5f,
        "s" to "https://example.org/?q=\u00e4\u0645", "pref_user_block_list" to setOf("a.com", "b.org"), "empty" to ""
    )

    private fun store(file: File, seed: Int = 1) = EncryptedSettingsStore(file, cipher(seed))

    @Test fun codecRoundTripsEveryType() {
        assertEquals(sample, SettingsCodec.decode(SettingsCodec.encode(sample)))
    }

    @Test fun codecHandlesStringsLongerThan64k() {
        val big = "x".repeat(200_000)
        assertEquals(big, SettingsCodec.decode(SettingsCodec.encode(mapOf("session" to big)))["session"])
    }

    @Test fun savedFileHoldsNoPlaintext() {
        val f = File(tmp.root, "settings.enc")
        store(f).save(sample)
        val raw = f.readBytes()
        assertArrayEquals(EncryptedSettingsStore.MAGIC_ENC, raw.copyOfRange(0, 4))
        assertFalse(String(raw, Charsets.ISO_8859_1).contains("example.org"))
        assertFalse(String(raw, Charsets.ISO_8859_1).contains("pref_user_block_list"))   // key names are encrypted too
        assertFalse(File(f.path + ".tmp").exists())
    }

    @Test fun loadReturnsWhatWasSaved() {
        val f = File(tmp.root, "settings.enc")
        store(f).save(sample)
        val r = store(f).load()
        assertEquals(sample, r.values); assertFalse(r.corrupted); assertFalse(r.needsUpgrade)
    }

    @Test fun missingFileIsNotCorruption() {
        val r = store(File(tmp.root, "none.enc")).load()
        assertTrue(r.values.isEmpty()); assertFalse(r.corrupted)
    }

    @Test fun tamperedFileIsRejected() {
        val f = File(tmp.root, "settings.enc")
        store(f).save(sample)
        val raw = f.readBytes(); raw[raw.size - 1] = (raw[raw.size - 1].toInt() xor 1).toByte(); f.writeBytes(raw)
        val r = store(f).load()
        assertTrue(r.corrupted); assertTrue(r.values.isEmpty())
    }

    @Test fun wrongKeyIsRejected() {
        val f = File(tmp.root, "settings.enc")
        store(f, seed = 1).save(sample)
        assertTrue(store(f, seed = 2).load().corrupted)
    }

    @Test fun headerCannotBeSwappedToPlainFormat() {
        val f = File(tmp.root, "settings.enc")
        store(f).save(sample)
        val raw = f.readBytes()
        EncryptedSettingsStore.MAGIC_PLAIN.copyInto(raw)                     // "SHE1" -> "SHP1"
        f.writeBytes(raw)
        assertTrue(store(f).load().corrupted)
    }

    @Test fun plainFallbackFileIsUpgradedWhenAKeyBecomesAvailable() {
        val f = File(tmp.root, "settings.enc")
        EncryptedSettingsStore(f, null).save(sample)
        assertArrayEquals(EncryptedSettingsStore.MAGIC_PLAIN, f.readBytes().copyOfRange(0, 4))
        val r = store(f).load()
        assertEquals(sample, r.values); assertTrue(r.needsUpgrade)
    }

    @Test fun encryptedFileWithoutKeyIsReportedCorrupt() {
        val f = File(tmp.root, "settings.enc")
        store(f).save(sample)
        assertTrue(EncryptedSettingsStore(f, null).load().corrupted)
    }

    @Test fun overwritingKeepsOnlyLatestValues() {
        val f = File(tmp.root, "settings.enc")
        val s = store(f)
        s.save(mapOf("a" to 1)); s.save(mapOf("b" to 2))
        assertEquals(mapOf<String, Any>("b" to 2), s.load().values)
    }
}
