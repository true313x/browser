package com.shieldbrowser.app

import com.shieldbrowser.app.fingerprint.UserAgentProfiles
import com.shieldbrowser.app.privacy.PageScriptBuilder
import com.shieldbrowser.app.privacy.PageScriptConfig
import com.shieldbrowser.app.privacy.SiteScriptOverride
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PageScriptBuilderTest {
    private fun cfg(profileId: String, ovr: Map<String, SiteScriptOverride> = emptyMap()) = PageScriptConfig(
        fingerprintLevel = 2, profile = UserAgentProfiles.find(profileId), referrerPolicy = "strict-origin", webRtc = "relay",
        blockClipboardRead = true, miningHeuristic = true, cosmetic = false, seed = 42, overrides = ovr
    )
    private val b = PageScriptBuilder("/*core*/")

    @Test fun prefixesConfigBeforeTemplate() {
        val s = b.build(cfg("default"))
        assertTrue(s.startsWith("var __SHIELD_CFG = {")); assertTrue(s.endsWith("/*core*/"))
    }
    @Test fun defaultProfileDoesNotSpoofIdentity() = assertTrue(b.configJson(cfg("default")).contains("\"id\":null"))
    @Test fun customProfileSpoofsPlatformAndTouch() {
        val j = b.configJson(cfg("iphone"))
        assertTrue(j.contains("\"platform\":\"iPhone\"") && j.contains("\"touch\":5") && j.contains("\"uad\":false"))
    }
    @Test fun perSiteOverridesAreEmbedded() {
        val j = b.configJson(cfg("default", mapOf("example.com" to SiteScriptOverride(off = true, noCookie = true))))
        assertTrue(j.contains("\"example.com\":{\"off\":true,\"nocookie\":true"))
    }
    @Test fun configCannotBreakOutOfTheScript() {
        val j = b.configJson(cfg("default", mapOf("evil\"</script>" to SiteScriptOverride())))
        assertTrue(!j.contains("</script>")); assertEquals(j.count { it == '{' }, j.count { it == '}' })
    }
}
