package com.shieldbrowser.app

import com.shieldbrowser.app.browser.UrlInput
import com.shieldbrowser.app.browser.UrlInput.Resolved
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlInputTest {
    private val tpl = "https://duckduckgo.com/?q=%s"
    private fun r(s: String) = UrlInput.resolve(s, tpl)

    @Test fun bareDomainBecomesHttps() = assertEquals(Resolved.Url("https://example.com"), r("example.com"))
    @Test fun localhostAndIpUseHttp() {
        assertEquals(Resolved.Url("http://localhost:3000/app"), r("localhost:3000/app"))
        assertEquals(Resolved.Url("http://192.168.0.1/admin"), r("192.168.0.1/admin"))
    }
    @Test fun spacesMeanSearch() =
        assertEquals(Resolved.Search("kotlin coroutines", "https://duckduckgo.com/?q=kotlin+coroutines"), r("kotlin coroutines"))
    @Test fun dangerousSchemesBecomeSearches() {
        assertTrue(r("javascript:alert(1)") is Resolved.Search)
        assertTrue(r("data:text/html,hi") is Resolved.Search)
        assertTrue(r("ftp://x.com") is Resolved.Search)
    }
    @Test fun internalAndHttpSchemesPass() {
        assertEquals(Resolved.Url("shield://start"), r("shield://start"))
        assertEquals(Resolved.Url("http://example.com/a"), r("http://example.com/a"))
    }
    @Test fun singleLetterTldIsASearch() = assertTrue(r("a.b") is Resolved.Search)
    @Test fun displayUrlStripsNoise() = assertEquals("example.com", UrlInput.displayUrl("https://www.example.com/"))
}
