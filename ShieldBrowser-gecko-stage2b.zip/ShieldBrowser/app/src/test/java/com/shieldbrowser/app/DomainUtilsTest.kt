package com.shieldbrowser.app

import com.shieldbrowser.app.blocking.DomainUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainUtilsTest {
    @Test fun hostParsing() {
        assertEquals("sub.example.com", DomainUtils.hostOf("https://User:pw@Sub.Example.COM:8443/a?b#c"))
        assertEquals("[::1]", DomainUtils.hostOf("https://[::1]:8080/x"))
        assertEquals("example.com", DomainUtils.hostOf("http://example.com?x=1"))
        assertNull(DomainUtils.hostOf("mailto:a@b.com"))
    }

    @Test fun registrableDomain() {
        assertEquals("example.com", DomainUtils.registrableDomain("www.example.com"))
        assertEquals("example.com", DomainUtils.registrableDomain("example.com"))
        assertEquals("example.co.uk", DomainUtils.registrableDomain("a.b.example.co.uk"))
        assertEquals("192.168.1.1", DomainUtils.registrableDomain("192.168.1.1"))
    }

    @Test fun thirdPartyDetection() {
        assertFalse(DomainUtils.isThirdParty("cdn.example.com", "www.example.com"))
        assertTrue(DomainUtils.isThirdParty("tracker.net", "www.example.com"))
        assertFalse(DomainUtils.isThirdParty("tracker.net", null))
    }

    @Test fun parentWalkStopsBeforeTld() =
        assertEquals(listOf("a.b.c.com", "b.c.com", "c.com"), DomainUtils.parents("a.b.c.com").toList())

    @Test fun localHosts() {
        assertTrue(DomainUtils.isLocalHost("localhost")); assertTrue(DomainUtils.isLocalHost("192.168.1.5"))
        assertTrue(DomainUtils.isLocalHost("172.20.0.1")); assertFalse(DomainUtils.isLocalHost("172.32.0.1"))
        assertFalse(DomainUtils.isLocalHost("example.com"))
    }
}
