package com.shieldbrowser.app

import com.shieldbrowser.app.security.IntegrityChecks
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IntegrityChecksTest {
    @Test fun tracerPid() {
        assertEquals(0, IntegrityChecks.tracerPid("Name:\tx\nTracerPid:\t0\nUid:\t1"))
        assertEquals(4242, IntegrityChecks.tracerPid("State:\tS\nTracerPid:\t4242\n"))
        assertEquals(-1, IntegrityChecks.tracerPid("nothing here"))
    }

    @Test fun hookMarkers() {
        val clean = "7f00-7f10 r-xp 0 00:00 0 /system/lib64/libc.so\n7f20-7f30 r--p 0 00:00 0 /data/app/x/base.apk"
        assertTrue(IntegrityChecks.hookMarkers(clean).isEmpty())
        val dirty = "7f00-7f10 r-xp 0 00:00 0 /data/local/tmp/re.frida.server/frida-agent-64.so\n" +
            "7f20-7f30 r--p 0 00:00 0 /system/framework/XposedBridge.jar"
        val m = IntegrityChecks.hookMarkers(dirty)
        assertTrue("frida-agent" in m); assertTrue("xposedbridge" in m)
    }

    @Test fun fridaThreads() {
        assertTrue(IntegrityChecks.hookThreads(listOf("main", "gum-js-loop", "RenderThread")).isNotEmpty())
        assertTrue(IntegrityChecks.hookThreads(listOf("main", "gmain", "RenderThread")).isEmpty())
        assertTrue(IntegrityChecks.hookThreads(listOf("main", "OkHttp Dispatcher")).isEmpty())
    }

    @Test fun hookFrames() {
        assertTrue(IntegrityChecks.hookFrames(listOf("com.x.A", "de.robv.android.xposed.XposedBridge")))
        assertFalse(IntegrityChecks.hookFrames(listOf("com.shieldbrowser.app.Foo", "android.os.Handler")))
        assertFalse("must not match unrelated names", IntegrityChecks.hookFrames(listOf("com.example.FridayReport", "com.example.Fridays")))
        assertTrue(IntegrityChecks.hookFrames(listOf("re.frida.Gadget")))
    }

    @Test fun emulator() {
        assertTrue(IntegrityChecks.looksLikeEmulator("generic/sdk_gphone64_x86_64/emu", "ranchu", "sdk_gphone64_x86_64", "sdk_gphone64", "Google"))
        assertFalse(IntegrityChecks.looksLikeEmulator("samsung/dm1q/dm1q:14/UP1A/1:user/release-keys", "qcom", "dm1qxxx", "SM-S911B", "samsung"))
    }

    @Test fun digestCompare() {
        assertTrue(IntegrityChecks.sameDigest("AB12", "ab12"))
        assertFalse(IntegrityChecks.sameDigest("ab12", "ab13"))
        assertFalse(IntegrityChecks.sameDigest("ab12", "ab1"))
    }
}
