package com.shieldbrowser.app

import com.shieldbrowser.app.security.PaymentGuard
import com.shieldbrowser.app.security.PaymentGuard.Issue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PaymentGuardTest {
    private fun v(url: String, secure: Boolean? = true, exc: Boolean = false, field: Boolean = false) = PaymentGuard.assess(url, secure, exc, field)

    @Test fun realBrandsAreNotLookalikes() {
        for (h in listOf("www.paypal.com", "checkout.stripe.com", "paytabs.sa", "secure.paytabs.com", "pay.moyasar.com", "tabby.ai"))
            assertNull(h, PaymentGuard.lookalikeOf(h))
    }

    @Test fun typosquatsAreCaught() {
        assertEquals("paypal", PaymentGuard.lookalikeOf("paypa1.com"))
        assertEquals("paypal", PaymentGuard.lookalikeOf("paypal.com.verify-account.net"))
        assertEquals("paypal", PaymentGuard.lookalikeOf("secure-paypal.com"))
        assertEquals("paypal", PaymentGuard.lookalikeOf("paypalsecure.com"))
        assertEquals("paypal", PaymentGuard.lookalikeOf("paypall.com"))
        assertEquals("stripe", PaymentGuard.lookalikeOf("login.stripe.com.pay-now.xyz"))
        assertEquals("paypal", PaymentGuard.lookalikeOf("paypal.co"))
    }

    @Test fun innocentDomainsAreNotFlagged() {
        for (h in listOf("pinstripe.com", "example.com", "shop.example.co.uk", "mystore.sa", "tapestry.com"))
            assertNull(h, PaymentGuard.lookalikeOf(h))
    }

    @Test fun paymentContextDetection() {
        assertTrue(PaymentGuard.looksLikePaymentUrl("https://shop.example.com/checkout/step2?x=1"))
        assertTrue(PaymentGuard.looksLikePaymentUrl("https://js.stripe.com/v3/"))
        assertTrue(PaymentGuard.looksLikePaymentUrl("https://x.com/en/payment"))
        assertFalse(PaymentGuard.looksLikePaymentUrl("https://example.com/blog/how-to-pay-less"))
        assertFalse(PaymentGuard.looksLikePaymentUrl("https://example.com/"))
        assertTrue(v("https://example.com/", field = true).isPaymentContext)
    }

    @Test fun addressIssues() {
        assertTrue(Issue.NOT_HTTPS in v("http://shop.com/checkout").issues)
        assertTrue(v("http://shop.com/checkout").blocked)
        assertTrue(Issue.CREDENTIALS_IN_URL in v("https://paypal.com@evil.com/pay").issues)
        assertTrue(Issue.IP_HOST in v("https://203.0.113.9/checkout").issues)
        assertTrue(Issue.NON_STANDARD_PORT in v("https://shop.com:8443/checkout").issues)
        assertFalse(Issue.NON_STANDARD_PORT in v("https://shop.com:443/checkout").issues)
        assertTrue(Issue.PUNYCODE in v("https://xn--pypal-4ve.com/pay").issues)
        assertTrue(Issue.CERT_EXCEPTION in v("https://shop.com/pay", exc = true).issues)
        assertTrue(Issue.CONNECTION_NOT_SECURE in v("https://shop.com/pay", secure = false).issues)
        assertTrue(v("https://shop.com/pay").clean)
        assertTrue("unknown TLS state must not count as insecure", v("https://shop.com/pay", secure = null).clean)
    }

    @Test fun mixedScriptHomographs() {
        assertTrue(PaymentGuard.mixedScripts("p\u0430ypal.com"))               // Cyrillic a inside a Latin word
        assertFalse(PaymentGuard.mixedScripts("paypal.com"))
        assertFalse(PaymentGuard.mixedScripts("\u0645\u062b\u0627\u0644.\u0627\u062e\u062a\u0628\u0627\u0631"))   // pure Arabic IDN is fine
    }

    @Test fun displayDomain() {
        assertEquals("example.co.uk", PaymentGuard.displayDomain("https://pay.shop.example.co.uk/checkout"))
        assertNotNull(PaymentGuard.PSP_DOMAINS)
    }
}
