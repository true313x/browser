package com.shieldbrowser.app

import com.shieldbrowser.app.fingerprint.UserAgentProfiles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UserAgentProfilesTest {
    @Test fun allRequiredProfilesExist() {
        listOf("default", "android", "iphone", "ipad", "windows", "mac", "linux", "huawei", "xiaomi", "samsung", "realme", "vivo", "generic_mobile", "generic_desktop")
            .forEach { assertNotNull("missing $it", UserAgentProfiles.find(it)) }
    }
    @Test fun defaultKeepsSystemUserAgent() {
        assertTrue(UserAgentProfiles.find("default")!!.isDefault)
        assertTrue(UserAgentProfiles.builtIns.filter { it.id != "default" }.all { !it.userAgent.isNullOrBlank() })
    }
    @Test fun identityFieldsAreCoherent() {
        val iphone = UserAgentProfiles.find("iphone")!!
        assertTrue(iphone.userAgent!!.contains("iPhone")); assertEquals("iPhone", iphone.platform); assertFalse(iphone.exposesUserAgentData)
        val win = UserAgentProfiles.find("windows")!!
        assertEquals("Win32", win.platform); assertFalse(win.mobile); assertEquals(0, win.maxTouchPoints)
    }
    @Test fun customProfileValidation() {
        assertNull(UserAgentProfiles.custom("x", "short", "", true))
        val p = UserAgentProfiles.custom("  Mine ", "Mozilla/5.0 (X11)\u0007\n", "", false)!!
        assertEquals("Mine", p.name); assertEquals("Mozilla/5.0 (X11)", p.userAgent); assertEquals("Win32", p.platform)
        assertEquals(UserAgentProfiles.CUSTOM_ID, p.id); assertFalse(p.builtIn)
    }
}
