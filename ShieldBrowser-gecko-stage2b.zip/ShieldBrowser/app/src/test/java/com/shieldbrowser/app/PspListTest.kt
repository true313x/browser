package com.shieldbrowser.app

import com.shieldbrowser.app.security.PaymentGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The extension's lists/psp.txt must stay identical to PaymentGuard.PSP_DOMAINS (one source of truth in code). */
class PspListTest {
    @Test fun extensionListMatchesKotlinList() {
        val f = listOf("src/gecko/assets/shield-ext/lists/psp.txt", "app/src/gecko/assets/shield-ext/lists/psp.txt")
            .map { File(it) }.firstOrNull { it.exists() }
        assertTrue("psp.txt not found from ${File(".").absolutePath}", f != null)
        val fromFile = f!!.readLines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
        assertEquals(PaymentGuard.PSP_DOMAINS, fromFile)
    }
}
