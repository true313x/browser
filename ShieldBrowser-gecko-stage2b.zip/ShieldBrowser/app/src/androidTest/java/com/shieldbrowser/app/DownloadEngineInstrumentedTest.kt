package com.shieldbrowser.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.shieldbrowser.app.downloads.DownloadEngine
import com.shieldbrowser.app.downloads.DownloadItem
import com.shieldbrowser.app.downloads.DownloadRequest
import com.shieldbrowser.app.downloads.DownloadState
import com.shieldbrowser.app.network.DnsProvider
import com.shieldbrowser.app.privacy.SessionReport
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.net.ServerSocket
import java.security.MessageDigest
import kotlin.concurrent.thread

/** Runs the real engine against a tiny local HTTP server (cleartext to 127.0.0.1 is allowed by the network security config). */
@RunWith(AndroidJUnit4::class)
class DownloadEngineInstrumentedTest {
    private lateinit var ctx: Context
    private lateinit var db: AppDatabase
    private lateinit var engine: DownloadEngine
    private lateinit var server: ServerSocket
    private val payload = ByteArray(300_000) { (it * 31 % 251).toByte() }

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        db = AppDatabase(ctx, null)
        engine = DownloadEngine(ctx, db, DnsProvider(BrowserSettings(ctx)), CoroutineScope(SupervisorJob() + Dispatchers.Default), BrowserSettings(ctx), SessionReport())
        server = ServerSocket(0)
        thread(isDaemon = true) {
            while (!server.isClosed) {
                try {
                    val s = server.accept()
                    thread(isDaemon = true) {
                        s.use {
                            val r = it.getInputStream().bufferedReader()
                            while (true) { val line = r.readLine() ?: break; if (line.isEmpty()) break }
                            it.getOutputStream().apply {
                                write("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: ${payload.size}\r\nConnection: close\r\n\r\n".toByteArray())
                                write(payload); flush()
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    @After fun tearDown() {
        server.close()
        engine.items.value.forEach { engine.delete(it.id, true) }
        db.close()
    }

    private fun url() = "http://127.0.0.1:${server.localPort}/file.bin"
    private fun waitFor(id: Long, state: DownloadState): DownloadItem {
        val end = System.currentTimeMillis() + 15_000
        while (System.currentTimeMillis() < end) {
            engine.get(id)?.takeIf { it.state == state }?.let { return it }
            Thread.sleep(100)
        }
        throw AssertionError("download $id did not reach $state: ${engine.get(id)}")
    }

    @Test fun downloadsFileAndComputesSha256() {
        val id = engine.enqueue(DownloadRequest(url(), null, null, null, "../evil/file.bin", "application/octet-stream", payload.size.toLong(), false))
        val done = waitFor(id, DownloadState.COMPLETED)
        assertEquals("file.bin", done.fileName)                                  // path traversal stripped
        assertEquals(payload.size.toLong(), engine.fileOf(done).length())
        val expected = MessageDigest.getInstance("SHA-256").digest(payload).joinToString("") { "%02x".format(it) }
        assertEquals(expected, done.sha256)
    }

    @Test fun duplicateNamesGetUniqueFiles() {
        val a = engine.enqueue(DownloadRequest(url(), null, null, null, "same.bin", null, -1, false))
        val b = engine.enqueue(DownloadRequest(url(), null, null, null, "same.bin", null, -1, false))
        val da = waitFor(a, DownloadState.COMPLETED); val db2 = waitFor(b, DownloadState.COMPLETED)
        assertTrue(da.filePath != db2.filePath)
    }

    @Test fun privateDownloadsLiveInCacheAndAreWipedWithThePrivateSession() {
        val id = engine.enqueue(DownloadRequest(url(), null, null, null, "secret.bin", null, -1, true))
        val done = waitFor(id, DownloadState.COMPLETED)
        assertTrue(done.isPrivate && done.filePath.startsWith(ctx.cacheDir.absolutePath))
        assertTrue(done.id < 0)                                                  // never written to the database
        assertNotNull(engine.fileOf(done).takeIf { it.exists() })
        engine.clearPrivate()
        assertFalse(engine.fileOf(done).exists()); assertTrue(engine.items.value.none { it.isPrivate })
    }

    @Test fun deleteRemovesFileAndRow() {
        val id = engine.enqueue(DownloadRequest(url(), null, null, null, "gone.bin", null, -1, false))
        val done = waitFor(id, DownloadState.COMPLETED)
        engine.delete(id, true)
        assertFalse(engine.fileOf(done).exists()); assertTrue(engine.get(id) == null)
    }
}
