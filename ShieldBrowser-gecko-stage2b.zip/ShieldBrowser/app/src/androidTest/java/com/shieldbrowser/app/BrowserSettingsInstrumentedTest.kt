package com.shieldbrowser.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.fingerprint.FingerprintMode
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.CookieMode
import com.shieldbrowser.app.settings.K
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BrowserSettingsInstrumentedTest {
    private lateinit var s: BrowserSettings

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        s = BrowserSettings(ctx)
        s.prefs.edit().clear().commit()
    }

    @Test fun privacyFirstDefaults() {
        assertTrue(s.blockAds && s.blockAnalytics && s.blockTracking && s.blockCryptomining && s.httpsOnly && s.urlCleaning)
        assertEquals(CookieMode.BLOCK_THIRD_PARTY, s.cookieMode)
        assertEquals(FingerprintMode.STANDARD, s.fingerprintMode)
        assertFalse("Safe Browsing sends data to Google; must be opt-in", s.safeBrowsing)
        assertEquals("duckduckgo", s.searchEngineId)
    }

    @Test fun changesAreReflectedImmediately() {
        s.prefs.edit().putString(K.FINGERPRINT_MODE, "maximum").putString(K.COOKIE_MODE, "block_all").putBoolean(K.BLOCK_ADS, false).commit()
        assertEquals(FingerprintMode.MAXIMUM, s.fingerprintMode)
        assertEquals(CookieMode.BLOCK_ALL, s.cookieMode)
        assertFalse(BlockCategory.ADVERTISING in s.blockerConfig().categories)
    }

    @Test fun invalidValuesFallBackToDefaults() {
        s.prefs.edit().putString(K.FINGERPRINT_MODE, "bogus").commit()
        assertEquals(FingerprintMode.STANDARD, s.fingerprintMode)
    }

    @Test fun customUserAgentProfile() {
        s.prefs.edit().putString(K.UA_PROFILE, "custom").putString(K.UA_CUSTOM_STRING, "Mozilla/5.0 (Test) Mobile").commit()
        val p = s.userAgentProfile()
        assertEquals("custom", p.id); assertTrue(p.mobile)
        s.prefs.edit().putString(K.UA_CUSTOM_STRING, "x").commit()          // invalid custom → safe fallback to default
        assertEquals("default", s.userAgentProfile().id)
    }

    @Test fun userListsPersist() {
        s.userAllow = setOf("a.com", "b.com"); s.userBlock = setOf("c.com")
        assertEquals(setOf("a.com", "b.com"), s.userAllow); assertEquals(setOf("c.com"), s.userBlock)
    }
}
