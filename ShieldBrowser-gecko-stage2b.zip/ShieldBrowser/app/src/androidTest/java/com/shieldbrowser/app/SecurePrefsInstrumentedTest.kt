package com.shieldbrowser.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.K
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** Runs on a device/emulator: needs the real Android Keystore. */
@RunWith(AndroidJUnit4::class)
class SecurePrefsInstrumentedTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()

    @Test fun settingsAreEncryptedAtRest() {
        val s = BrowserSettings(ctx)
        assertTrue("Keystore should be usable on a test device", s.isEncrypted)
        s.prefs.edit().putString(K.SESSION, "https://secret-tab.example/very-private-path").commit()
        val file = File(ctx.filesDir, "settings.enc")
        assertTrue(file.exists())
        val raw = String(file.readBytes(), Charsets.ISO_8859_1)
        assertFalse(raw.contains("secret-tab.example"))
        assertFalse(raw.contains(K.SESSION))
        assertEquals("https://secret-tab.example/very-private-path", s.prefs.getString(K.SESSION, null))
        s.prefs.edit().remove(K.SESSION).commit()
    }

    @Test fun noPlainSharedPrefsFileIsLeftBehind() {
        BrowserSettings(ctx)
        val legacy = File(ctx.applicationInfo.dataDir, "shared_prefs/${ctx.packageName}_preferences.xml")
        assertFalse(legacy.exists())
    }

    @Test fun changeListenersFire() {
        val s = BrowserSettings(ctx)
        val latch = java.util.concurrent.CountDownLatch(1)
        val l = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key -> if (key == K.DOWNLOAD_NOTIFICATIONS) latch.countDown() }
        s.prefs.registerOnSharedPreferenceChangeListener(l)
        s.prefs.edit().putBoolean(K.DOWNLOAD_NOTIFICATIONS, !s.downloadNotifications).commit()
        assertTrue(latch.await(3, java.util.concurrent.TimeUnit.SECONDS))
        s.prefs.unregisterOnSharedPreferenceChangeListener(l)
        s.prefs.edit().remove(K.DOWNLOAD_NOTIFICATIONS).commit()
    }
}
