package com.shieldbrowser.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.shieldbrowser.app.bookmarks.BookmarkKind
import com.shieldbrowser.app.bookmarks.BookmarkRepository
import com.shieldbrowser.app.history.HistoryRepository
import com.shieldbrowser.app.settings.Perm
import com.shieldbrowser.app.settings.SiteCookies
import com.shieldbrowser.app.settings.SiteSettingsRepository
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class StorageInstrumentedTest {
    private lateinit var ctx: Context
    private lateinit var db: AppDatabase

    @Before fun setUp() { ctx = ApplicationProvider.getApplicationContext(); db = AppDatabase(ctx, null) }   // in-memory DB
    @After fun tearDown() { db.close() }

    @Test fun historyDedupesRecentVisitsAndEscapesLikeWildcards() = runBlocking {
        val h = HistoryRepository(db)
        h.add("https://a.org/", "A"); h.add("https://a.org/", "A2")
        h.add("https://x.org/100%_done", "Done"); h.add("https://y.org/abc", "Y")
        assertEquals(3, h.list().size)
        assertEquals("A2", h.list("a.org").single().title)
        assertEquals(listOf("https://x.org/100%_done"), h.list("%").map { it.url })     // '%' is literal, not a wildcard
        assertEquals(1, h.suggest("100%").size)
    }

    @Test fun historyDeletion() = runBlocking {
        val h = HistoryRepository(db)
        h.add("https://a.org/", "A"); h.add("https://b.org/", "B")
        h.delete(h.list().first().id); assertEquals(1, h.list().size)
        h.deleteAll(); assertTrue(h.list().isEmpty())
    }

    @Test fun bookmarksAndReadingListAreSeparate() = runBlocking {
        val b = BookmarkRepository(db)
        b.add("https://a.org", "A", BookmarkKind.BOOKMARK); b.add("https://a.org", "A", BookmarkKind.READING_LIST)
        assertTrue(b.contains("https://a.org", BookmarkKind.BOOKMARK))
        b.remove("https://a.org", BookmarkKind.BOOKMARK)
        assertFalse(b.contains("https://a.org", BookmarkKind.BOOKMARK)); assertTrue(b.contains("https://a.org", BookmarkKind.READING_LIST))
        val id = b.list(BookmarkKind.READING_LIST).single().id
        b.setRead(id, true); assertTrue(b.list(BookmarkKind.READING_LIST).single().read)
    }

    @Test fun siteSettingsAreKeyedByRegistrableDomain() {
        val r = SiteSettingsRepository(db, CoroutineScope(Dispatchers.IO))
        r.update("www.example.com") { it.copy(js = Perm.BLOCK, cookies = SiteCookies.BLOCK_ALL, shield = false) }
        val s = r.get("m.example.com")
        assertEquals(Perm.BLOCK, s.js); assertEquals(SiteCookies.BLOCK_ALL, s.cookies); assertFalse(r.isShieldOn("cdn.example.com"))
        assertEquals(Perm.INHERIT, r.get("other.org").js)
        r.reset("example.com"); assertTrue(r.all().isEmpty()); assertTrue(r.isShieldOn("example.com"))
    }
}
