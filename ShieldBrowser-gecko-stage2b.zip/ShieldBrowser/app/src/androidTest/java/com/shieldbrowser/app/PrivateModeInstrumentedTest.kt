package com.shieldbrowser.app

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebView
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import com.shieldbrowser.app.browser.BrowserTab
import com.shieldbrowser.app.browser.ProfileManager
import com.shieldbrowser.app.privacy.CookieController
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.SiteCookies
import com.shieldbrowser.app.settings.SiteSettingsRepository
import com.shieldbrowser.app.storage.AppDatabase
import com.shieldbrowser.app.tabs.TabData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Private mode / cookie manager behaviour on a real WebView. Isolation tests are skipped when the WebView lacks MULTI_PROFILE. */
@RunWith(AndroidJUnit4::class)
class PrivateModeInstrumentedTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private val inst = InstrumentationRegistry.getInstrumentation()

    private fun initWebView(): WebView { var w: WebView? = null; inst.runOnMainSync { w = WebView(ctx) }; return w!! }

    @Test fun profileNaming() {
        val pm = ProfileManager()
        assumeTrue(pm.supported)
        assertEquals(ProfileManager.PRIVATE_PROFILE, pm.profileNameFor(BrowserTab(TabData(1, "", "", true)), false))
        assertEquals("iso-2", pm.profileNameFor(BrowserTab(TabData(2, "", "", false)), true))
        assertNull(pm.profileNameFor(BrowserTab(TabData(3, "", "", false)), false))
    }

    @Test fun privateProfileCookiesDoNotLeakIntoDefaultProfile() {
        val pm = ProfileManager()
        assumeTrue(pm.supported)
        initWebView().destroy()
        val priv = ProfileStore.getInstance().getOrCreateProfile(ProfileManager.PRIVATE_PROFILE).cookieManager
        priv.setCookie("https://example.com/", "pm_test=secret; Path=/"); priv.flush()
        assertTrue(priv.getCookie("https://example.com/").orEmpty().contains("pm_test"))
        assertFalse(CookieManager.getInstance().getCookie("https://example.com/").orEmpty().contains("pm_test"))
        priv.removeAllCookies(null)
    }

    @Test fun cookieControllerExpiresCookiesAndClearsSites() {
        val db = AppDatabase(ctx, null)
        val sites = SiteSettingsRepository(db, CoroutineScope(Dispatchers.IO))
        val cc = CookieController(BrowserSettings(ctx), sites, ProfileManager())
        initWebView().destroy()
        val cm = CookieManager.getInstance()
        cm.setCookie("https://cookie-test.example/", "a=1; Path=/"); cm.setCookie("https://cookie-test.example/", "b=2; Path=/"); cm.flush()
        assertEquals(2, cc.expire(cm, "https://cookie-test.example/", "cookie-test.example"))
        assertFalse(cm.getCookie("https://cookie-test.example/").orEmpty().contains("a=1"))
        sites.update("cookie-test.example") { it.copy(cookies = SiteCookies.BLOCK_ALL) }
        assertEquals(SiteCookies.BLOCK_ALL, cc.effective("www.cookie-test.example"))
        db.close()
    }
}
