package com.shieldbrowser.app.gecko

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.bookmarks.BookmarkKind
import com.shieldbrowser.app.browser.SearchEngines
import com.shieldbrowser.app.browser.UrlInput
import com.shieldbrowser.app.databinding.ActivityGeckoBrowserBinding
import com.shieldbrowser.app.downloads.DownloadRequest
import com.shieldbrowser.app.downloads.DownloadSafety
import com.shieldbrowser.app.downloads.DownloadsActivity
import com.shieldbrowser.app.downloads.RiskLevel
import com.shieldbrowser.app.history.HistoryActivity
import com.shieldbrowser.app.bookmarks.BookmarksActivity
import com.shieldbrowser.app.privacy.ProtectionLevel
import com.shieldbrowser.app.settings.Perm
import com.shieldbrowser.app.settings.SettingsActivity
import com.shieldbrowser.app.ui.MainActivity
import com.shieldbrowser.app.ui.formatSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.mozilla.geckoview.GeckoSession
import java.io.File
import java.io.FileOutputStream
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.shieldbrowser.app.security.AppLock
import com.shieldbrowser.app.security.PaymentGuard
import com.shieldbrowser.app.security.SealedActivity
import com.shieldbrowser.app.security.SealedMode
import com.shieldbrowser.app.security.Severity
import com.shieldbrowser.app.security.TamperMonitor
import com.shieldbrowser.app.security.TamperPolicy
import com.shieldbrowser.app.security.TamperSignal

/**
 * The GeckoView browser screen (Material 3). Tabs live in [GeckoTabs] (process-wide), this activity only shows the
 * active one and answers its dialog/permission/download requests through [TabUi].
 */
class GeckoBrowserActivity : AppCompatActivity(), TabUi {
    private lateinit var b: ActivityGeckoBrowserBinding
    private lateinit var tabs: GeckoTabs
    private lateinit var backgrounds: BackgroundStore
    private lateinit var streamDownloads: StreamDownloads
    private val main = Handler(Looper.getMainLooper())
    private val container get() = applicationContext.container

    private var attached: GeckoTab? = null
    private var blockerTotal = 0
    private var findActive = false
    private var findTabId = -1L
    private var pendingFilePick: ((List<Uri>?) -> Unit)? = null
    private var pendingAndroidPerms: ((Boolean) -> Unit)? = null

    private lateinit var paymentShield: PaymentShield
    private val backup = BackupController(this, { container }, { msg -> toast(msg) })
    private var lockCover: View? = null
    private var unlockPromptOpen = false
    private var sealing = false
    private var lastInteraction = SystemClock.elapsedRealtime()
    @Volatile private var lastSignals: Set<TamperSignal> = emptySet()
    private var warnedCritical = false

    /** Every 15 s while the screen is in front: tamper scan + idle timeout of Secure Payment tabs. */
    private val tamperLoop = object : Runnable {
        override fun run() {
            scanEnvironment()
            checkPaymentIdle()
            main.postDelayed(this, 15_000)
        }
    }

    private val pickFilesLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> onFilesPicked(uris) }
    private val photoLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) saveBackground(uri) }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        pendingAndroidPerms?.invoke(res.values.all { it }); pendingAndroidPerms = null
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // ------------------------------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        if (SealedMode.isSealed(this)) { super.onCreate(savedInstanceState); goSealed(); return }    // before anything touches the container
        ThemeManager.apply(this, container.settings.prefs)
        super.onCreate(savedInstanceState)
        b = ActivityGeckoBrowserBinding.inflate(layoutInflater)
        setContentView(b.root)

        tabs = GeckoTabs.get(this, container)
        paymentShield = PaymentShield(this, b.geckoView)
        backgrounds = BackgroundStore(this, container.settings.prefs)
        streamDownloads = StreamDownloads(container)
        tabs.engine.onBlockedRequests = { n -> blockerTotal = n }
        deleteOldUploads()

        setupAddressBar()
        setupBottomBar()
        setupFindBar()
        b.startPage.onSearchClick = { b.urlInput.requestFocus(); showKeyboard(b.urlInput) }
        b.startPage.onTileClick = { url -> tabs.active?.load(url) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { handleBack() }
        })

        if (!tabs.restore() && tabs.count == 0) tabs.newTab(null, false)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (SealedMode.isSealed(this)) { goSealed(); return }
        if (!::tabs.isInitialized) return
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        tabs.ui = this
        tabs.active?.let { showTab(it) }
        maybeLock()
        tabs.active?.let { paymentShield.apply(it.isPaymentContext, container.security.appLock) }   // app-lock may have been toggled
        checkPaymentIdle()
        main.removeCallbacks(tamperLoop)
        main.post(tamperLoop)
    }

    override fun onStop() {
        tabs.persist()
        container.appLock.onBackground()
        main.removeCallbacks(tamperLoop)
        super.onStop()
    }

    override fun onDestroy() {
        if (!::tabs.isInitialized) { super.onDestroy(); return }       // finished early (sealed)
        main.removeCallbacks(tamperLoop)
        if (tabs.ui === this) tabs.ui = null
        try { b.geckoView.releaseSession() } catch (_: Exception) { }
        attached = null
        pendingFilePick?.invoke(null); pendingFilePick = null
        if (isFinishing && !isChangingConfigurations) tabs.closePrivateTabs()
        super.onDestroy()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        lastInteraction = SystemClock.elapsedRealtime()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (lockCover != null) return super.onKeyDown(keyCode, event)
        if (::tabs.isInitialized && event.isCtrlPressed) {
            when (keyCode) {
                KeyEvent.KEYCODE_F -> { showFindBar(); return true }
                KeyEvent.KEYCODE_L -> { b.urlInput.requestFocus(); return true }
                KeyEvent.KEYCODE_T -> { tabs.newTab(null, false); return true }
                KeyEvent.KEYCODE_W -> { tabs.active?.let { tabs.close(it) }; return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun handleIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (intent.action != Intent.ACTION_VIEW) return
        val url = data.toString()
        if (!url.startsWith("http")) return
        if (intent.getBooleanExtra(MainActivity.EXTRA_NEW_TAB, true)) tabs.newTab(url, false) else tabs.active?.load(url)
        intent.data = null
    }

    // ------------------------------------------------------------------------------------------ chrome
    private fun setupAddressBar() {
        b.urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                submit(b.urlInput.text.toString()); true
            } else false
        }
        b.btnReload.setOnClickListener { tabs.active?.let { if (it.loading) it.stop() else it.reload() } }
        b.btnSecurity.setOnClickListener { showShieldPanel() }
        b.btnTabs.setOnClickListener { showTabSwitcher() }
        b.btnMenu.setOnClickListener { showMenu(it) }
    }

    private fun setupBottomBar() {
        b.btnBack.setOnClickListener { handleBack() }
        b.btnForward.setOnClickListener { tabs.active?.goForward() }
        b.btnHome.setOnClickListener { tabs.active?.load("about:blank") }
        b.btnShield.setOnClickListener { showShieldPanel() }
        b.btnDownloads.setOnClickListener { startActivity(Intent(this, DownloadsActivity::class.java)) }
    }

    private fun submit(text: String) {
        val tab = tabs.active ?: return
        val template = SearchEngines.template(container.settings.searchEngineId, container.settings.searchCustomUrl)
        val target = when (val r = UrlInput.resolve(text, template)) {
            is UrlInput.Resolved.Url -> r.url
            is UrlInput.Resolved.Search -> r.url
        }
        val safeTarget = if (tab.securePay && target.startsWith("http://")) "https://" + target.removePrefix("http://") else target
        tab.load(if (safeTarget.startsWith("shield://") || safeTarget.isBlank()) "about:blank" else safeTarget)
        b.urlInput.clearFocus()
        hideKeyboard(b.urlInput)
    }

    private fun handleBack() {
        val tab = tabs.active
        when {
            lockCover != null -> moveTaskToBack(true)            // locked: back must not act on the hidden browser
            findActive -> hideFindBar()
            tab != null && tab.canGoBack -> tab.goBack()
            tab != null && !tab.isStartPage && tabs.count == 1 -> tab.load("about:blank")
            tabs.count > 1 && tab != null -> tabs.close(tab)
            else -> moveTaskToBack(true)
        }
    }

    private fun showTab(tab: GeckoTab, attempt: Int = 0) {
        val s = tab.session
        try {
            if (s.isOpen) b.geckoView.setSession(s)
            else if (tab.isPopup) {
                // GeckoView opens popup sessions itself right after onNewSession returns; opening it here too would throw.
                if (attempt < 20) main.postDelayed({ if (tabs.active === tab) showTab(tab, attempt + 1) }, 50)
                return
            } else b.geckoView.setSession(s, tabs.engine.runtime)
        } catch (_: Exception) { return }
        attached = tab
        updateChrome(tab)
    }

    private fun updateChrome(tab: GeckoTab) {
        if (findActive && (tab.id != findTabId)) hideFindBar()
        updateBanner(tab)
        paymentShield.apply(tab.isPaymentContext, container.security.appLock)
        val start = tab.isStartPage
        if (start && b.startPage.visibility != View.VISIBLE) refreshStartPage()
        b.startPage.visibility = if (start) View.VISIBLE else View.GONE
        val shown = if (start) "" else tab.url
        if (!b.urlInput.hasFocus() && b.urlInput.text.toString() != shown) b.urlInput.setText(shown)
        b.btnSecurity.setImageResource(
            when {
                start -> R.drawable.ic_shield
                tab.isPaymentContext && tab.verdict?.clean == false -> R.drawable.ic_warning
                tab.secure -> R.drawable.ic_lock
                else -> R.drawable.ic_lock_open
            }
        )
        b.btnReload.setImageResource(if (tab.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        b.progress.visibility = if (tab.loading) View.VISIBLE else View.INVISIBLE
        b.progress.progress = tab.progress
        b.btnBack.alpha = if (tab.canGoBack || !start) 1f else 0.4f
        b.btnForward.alpha = if (tab.canGoForward) 1f else 0.4f
        b.tabCount.text = tabs.count.toString()
    }

    override fun tabChanged(tab: GeckoTab) {
        main.post {
            if (tab !== tabs.active) { b.tabCount.text = tabs.count.toString(); return@post }
            if (attached !== tab) showTab(tab) else updateChrome(tab)
        }
    }

    // ------------------------------------------------------------------------------------------ start page
    private fun refreshStartPage() {
        b.startPage.setBackgroundConfig(backgrounds.drawable(), backgrounds.blur, backgrounds.dim)
        val level = when (tabs.engine.level) {
            ProtectionLevel.STANDARD -> R.string.gk_level_standard
            ProtectionLevel.STRICT -> R.string.gk_level_strict
            ProtectionLevel.MAXIMUM -> R.string.gk_level_maximum
        }
        b.startPage.setSummary(getString(R.string.gk_start_summary, getString(level)))
        lifecycleScope.launch {
            val saved = try { container.bookmarks.list(BookmarkKind.BOOKMARK).take(8) } catch (_: Exception) { emptyList() }
            val tiles = if (saved.isNotEmpty()) saved.map { (it.title.ifBlank { DomainUtils.hostOf(it.url) ?: it.url }) to it.url }
            else listOf(
                "DuckDuckGo" to "https://duckduckgo.com", "Wikipedia" to "https://wikipedia.org",
                "OpenStreetMap" to "https://www.openstreetmap.org", "Signal" to "https://signal.org"
            )
            b.startPage.setTiles(tiles)
        }
    }

    private fun saveBackground(uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { backgrounds.saveImage(uri) }
            if (ok) refreshStartPage() else toast(getString(R.string.gk_photo_failed))
        }
    }

    // ------------------------------------------------------------------------------------------ menu / sheets / switcher
    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val items = listOf(
            1 to R.string.gk_menu_new_tab, 2 to R.string.gk_menu_new_private_tab, 3 to R.string.gk_menu_close_tab,
            4 to R.string.find_in_page, 5 to R.string.gk_menu_add_bookmark, 6 to R.string.gk_menu_share,
            7 to R.string.gk_menu_appearance, 8 to R.string.gk_menu_history, 9 to R.string.gk_menu_bookmarks,
            10 to R.string.gk_menu_settings, 11 to R.string.gk_menu_close_private,
            12 to R.string.pay_menu_secure_tab, 13 to R.string.sc_title
        )
        for ((id, res) in items) pm.menu.add(0, id, id, res)
        pm.setOnMenuItemClickListener { item ->
            val tab = tabs.active
            when (item.itemId) {
                1 -> tabs.newTab(null, false)
                2 -> tabs.newTab(null, true)
                3 -> tab?.let { tabs.close(it) }
                4 -> showFindBar()
                5 -> if (tab != null && tab.url.startsWith("http")) lifecycleScope.launch { container.bookmarks.add(tab.url, tab.title) }
                6 -> if (tab != null && tab.url.startsWith("http")) share(tab.url)
                7 -> AppearanceSheet(this, container.settings.prefs, backgrounds, {
                    photoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, { refreshStartPage() }).show()
                8 -> startActivity(Intent(this, HistoryActivity::class.java))
                9 -> startActivity(Intent(this, BookmarksActivity::class.java))
                10 -> startActivity(Intent(this, SettingsActivity::class.java))
                11 -> tabs.closePrivateTabs()
                12 -> openSecurePayment(tab?.url?.takeIf { it.startsWith("https://") })
                13 -> SecurityCenterSheet(this, container, backup, onClosed = { tabs.active?.let { updateChrome(it) } }) { openSecurePayment(null) }.show()
            }
            true
        }
        pm.show()
    }

    private fun showShieldPanel() {
        ShieldPanelSheet(this, tabs.active, tabs.engine, blockerTotal, { url -> tabs.newTab(url, false) }) {
            tabs.engine.clearAllSiteData()
            toast(getString(R.string.gk_cleared))
        }.show()
    }

    private fun showTabSwitcher() {
        val labels = tabs.tabs.map { t ->
            val name = t.title.ifBlank { if (t.isStartPage) getString(R.string.gk_untitled) else (DomainUtils.hostOf(t.url) ?: t.url) }
            (if (t.securePay) "\uD83D\uDD12 " else if (t.isPrivate) "\uD83D\uDD76 " else "") + name
        }.toTypedArray()
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.gk_tabs_title, tabs.count))
            .setItems(labels) { _, which -> tabs.select(which) }
            .setPositiveButton(R.string.gk_menu_new_tab) { _, _ -> tabs.newTab(null, false) }
            .setNeutralButton(R.string.gk_menu_new_private_tab) { _, _ -> tabs.newTab(null, true) }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dlg.setOnShowListener {
            dlg.listView.setOnItemLongClickListener { _, _, pos, _ ->     // long-press closes a tab
                tabs.tabs.getOrNull(pos)?.let { tabs.close(it) }
                dlg.dismiss(); showTabSwitcher(); true
            }
        }
        dlg.show()
    }

    private fun share(url: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url), null))
    }

    // ------------------------------------------------------------------------------------------ find in page
    private fun setupFindBar() {
        b.findInput.addTextChangedListener { text -> if (findActive) runFind(text?.toString().orEmpty(), true) }
        b.findInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                runFind(null, true); true
            } else false
        }
        b.btnFindNext.setOnClickListener { runFind(null, true) }
        b.btnFindPrev.setOnClickListener { runFind(null, false) }
        b.btnFindClose.setOnClickListener { hideFindBar() }
    }

    private fun showFindBar() {
        val tab = tabs.active ?: return
        if (tab.isStartPage) return
        findActive = true
        findTabId = tab.id
        b.findBar.visibility = View.VISIBLE
        b.findInput.requestFocus()
        b.findInput.post { showKeyboard(b.findInput) }
    }

    private fun hideFindBar() {
        if (!findActive) return
        findActive = false
        tabs.tabs.firstOrNull { it.id == findTabId }?.session?.finder?.clear()
        b.findBar.visibility = View.GONE
        b.findCount.text = ""
        b.findInput.setText("")                       // never carry a (possibly private) query to another tab
        b.findInput.clearFocus()
        hideKeyboard(b.findInput)
    }

    /** [query] null = repeat the previous search (next/previous match). */
    private fun runFind(query: String?, forward: Boolean) {
        val tab = tabs.tabs.firstOrNull { it.id == findTabId } ?: return
        val finder = tab.session.finder
        if (query != null && query.isEmpty()) { finder.clear(); b.findCount.text = ""; return }
        val flags = if (forward) GeckoSession.FINDER_FIND_FORWARD else GeckoSession.FINDER_FIND_BACKWARDS
        finder.find(query, flags).accept({ r ->
            runOnUiThread {
                if (!findActive || r == null) return@runOnUiThread
                b.findCount.text = when {
                    !r.found || r.total == 0 -> getString(R.string.find_no_match)
                    r.total < 0 -> r.current.toString()
                    else -> "${r.current}/${r.total}"
                }
            }
        }, { _ -> })
    }

    // ------------------------------------------------------------------------------------------ TabUi: dialogs
    override fun alert(message: String, done: () -> Unit) {
        MaterialAlertDialogBuilder(this).setMessage(message)
            .setPositiveButton(android.R.string.ok) { _, _ -> done() }.setOnCancelListener { done() }.show()
    }

    override fun confirm(message: String, done: (Boolean) -> Unit) {
        MaterialAlertDialogBuilder(this).setMessage(message)
            .setPositiveButton(android.R.string.ok) { _, _ -> done(true) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> done(false) }
            .setOnCancelListener { done(false) }.show()
    }

    override fun prompt(message: String, default: String, done: (String?) -> Unit) {
        val input = EditText(this).apply { setText(default); setSelectAllOnFocus(true) }
        MaterialAlertDialogBuilder(this).setMessage(message).setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ -> done(input.text.toString()) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> done(null) }
            .setOnCancelListener { done(null) }.show()
    }

    override fun auth(host: String, passwordOnly: Boolean, done: (String?, String?) -> Unit) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }
        val user = EditText(this).apply { hint = getString(R.string.gk_username); inputType = android.text.InputType.TYPE_CLASS_TEXT }
        val pass = EditText(this).apply {
            hint = getString(R.string.gk_password)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        if (!passwordOnly) col.addView(user)
        col.addView(pass)
        MaterialAlertDialogBuilder(this).setTitle(getString(R.string.gk_auth_title, host)).setView(col)
            .setPositiveButton(android.R.string.ok) { _, _ -> done(user.text.toString(), pass.text.toString()) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> done(null, null) }
            .setOnCancelListener { done(null, null) }.show()
    }

    override fun choose(items: List<ChoiceItem>, multiple: Boolean, done: (List<ChoiceItem>?) -> Unit) {
        val usable = items.filter { !it.disabled }
        val labels = usable.map { it.label }.toTypedArray()
        val builder = MaterialAlertDialogBuilder(this)
        if (multiple) {
            val checked = BooleanArray(usable.size) { usable[it].selected }
            builder.setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
                .setPositiveButton(android.R.string.ok) { _, _ -> done(usable.filterIndexed { i, _ -> checked[i] }) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> done(null) }
        } else {
            builder.setItems(labels) { _, which -> done(listOf(usable[which])) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> done(null) }
        }
        builder.setOnCancelListener { done(null) }.show()
    }

    override fun sitePermission(host: String, whatRes: Int, done: (Boolean) -> Unit) {
        MaterialAlertDialogBuilder(this).setTitle(getString(R.string.gk_allow_title, host, getString(whatRes)))
            .setPositiveButton(R.string.gk_allow) { _, _ -> done(true) }
            .setNegativeButton(R.string.gk_deny) { _, _ -> done(false) }
            .setOnCancelListener { done(false) }.show()
    }

    override fun androidPermissions(permissions: Array<String>, done: (Boolean) -> Unit) {
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { done(true); return }
        pendingAndroidPerms = done
        permLauncher.launch(missing.toTypedArray())
    }

    override fun externalApp(uri: String, done: (Boolean) -> Unit) {
        MaterialAlertDialogBuilder(this).setTitle(R.string.gk_external_title)
            .setMessage(getString(R.string.gk_external_msg, uri.take(120)))
            .setPositiveButton(R.string.gk_open) { _, _ -> done(true) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> done(false) }
            .setOnCancelListener { done(false) }.show()
    }

    // ------------------------------------------------------------------------------------------ TabUi: files
    /** GeckoView cannot read content:// Uris, so every picked file is copied into the cache and handed over as file://. */
    override fun pickFiles(multiple: Boolean, mimeTypes: Array<String>, done: (List<Uri>?) -> Unit) {
        pendingFilePick = done
        try { pickFilesLauncher.launch(if (mimeTypes.isEmpty()) arrayOf("*/*") else mimeTypes) }
        catch (_: Exception) { pendingFilePick = null; done(null) }
    }

    private fun onFilesPicked(uris: List<Uri>) {
        val cb = pendingFilePick ?: return
        pendingFilePick = null
        if (uris.isEmpty()) { cb(null); return }
        lifecycleScope.launch {
            val copies = withContext(Dispatchers.IO) { uris.mapNotNull { copyToCache(it) } }
            cb(if (copies.isEmpty()) null else copies)
        }
    }

    private fun copyToCache(uri: Uri): Uri? = try {
        var name = "upload"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val dir = File(cacheDir, "gecko_uploads").also { it.mkdirs() }
        val f = File(dir, System.nanoTime().toString() + "_" + DownloadSafety.sanitizeFileName(name))
        contentResolver.openInputStream(uri)?.use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } }
        Uri.fromFile(f)
    } catch (_: Exception) { null }

    private fun deleteOldUploads() {
        val dir = File(cacheDir, "gecko_uploads")
        val cutoff = System.currentTimeMillis() - 6 * 3600_000L
        dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }

    // ------------------------------------------------------------------------------------------ TabUi: full screen, context menu
    override fun fullScreen(on: Boolean) {
        main.post {
            val c = WindowCompat.getInsetsController(window, b.root)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (on) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
            b.addressRow.visibility = if (on) View.GONE else View.VISIBLE
            b.bottomBar.visibility = if (on) View.GONE else View.VISIBLE
        }
    }

    override fun contextMenu(linkUrl: String?, imageUrl: String?) {
        main.post {
            val entries = ArrayList<Pair<Int, () -> Unit>>()
            fun entry(res: Int, action: () -> Unit) { entries.add(res to action) }
            val tab = tabs.active
            if (!linkUrl.isNullOrEmpty()) {
                entry(R.string.gk_link_new_tab) { tabs.newTab(linkUrl, tab?.isPrivate == true) }
                entry(R.string.gk_link_private_tab) { tabs.newTab(linkUrl, true) }
                entry(R.string.gk_link_copy) { copy(linkUrl) }
                entry(R.string.gk_link_share) { share(linkUrl) }
            }
            if (!imageUrl.isNullOrEmpty()) {
                entry(R.string.gk_image_save) {
                    container.downloads.enqueue(
                        DownloadRequest(imageUrl, null, null, tab?.url?.takeIf { it.startsWith("http") },
                            DownloadSafety.sanitizeFileName(imageUrl.substringAfterLast('/').substringBefore('?')), null, -1L, tab?.isPrivate == true)
                    )
                    maybeAskNotificationPermission()
                }
            }
            if (entries.isEmpty()) return@post
            MaterialAlertDialogBuilder(this)
                .setTitle((linkUrl ?: imageUrl).orEmpty().take(80))
                .setItems(entries.map { getString(it.first) }.toTypedArray()) { _, which -> entries[which].second() }
                .show()
        }
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", text))
        toast(getString(R.string.gk_copied))
    }

    // ------------------------------------------------------------------------------------------ TabUi: downloads
    override fun download(tab: GeckoTab, download: IncomingDownload) {
        main.post {
            val pageHost = DomainUtils.hostOf(tab.url) ?: (DomainUtils.hostOf(download.url) ?: "")
            val name = DownloadSafety.sanitizeFileName(download.fileName)
            fun discard() { try { download.body.close() } catch (_: Exception) { } }
            val site = container.siteSettings.get(pageHost)
            if (site.downloads == Perm.BLOCK) { toast(getString(R.string.download_blocked_site, pageHost)); discard(); return@post }
            val risk = DownloadSafety.assess(name, download.mime, download.url)
            val needAsk = site.downloads == Perm.ASK || container.settings.askBeforeDownload ||
                (container.settings.warnDangerous && risk.level != RiskLevel.LOW)
            fun go() {
                if (streamDownloads.start(download, tab.isPrivate)) {
                    Snackbar.make(b.root, getString(R.string.download_started, name), Snackbar.LENGTH_LONG)
                        .setAction(R.string.view) { startActivity(Intent(this, DownloadsActivity::class.java)) }
                        .setAnchorView(b.bottomBar).show()
                    maybeAskNotificationPermission()
                } else toast(getString(R.string.blob_too_large))
            }
            if (!needAsk) { go(); return@post }
            val msg = StringBuilder()
                .append(getString(R.string.download_file, name)).append('\n')
                .append(getString(R.string.download_source, DomainUtils.hostOf(download.url) ?: pageHost)).append('\n')
                .append(getString(R.string.download_size, formatSize(download.length)))
            if (risk.level != RiskLevel.LOW) msg.append("\n\n\u26A0 ").append(getString(R.string.download_risky))
            MaterialAlertDialogBuilder(this).setTitle(R.string.download_confirm_title).setMessage(msg.toString())
                .setPositiveButton(R.string.download) { _, _ -> go() }
                .setNegativeButton(android.R.string.cancel) { _, _ -> discard() }
                .setOnCancelListener { discard() }.show()
        }
    }

    private fun maybeAskNotificationPermission() {
        val s = container.settings
        if (Build.VERSION.SDK_INT < 33 || !s.downloadNotifications || s.notifPermissionAsked) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        s.notifPermissionAsked = true
        try { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------------------------------ sealed / tamper
    private fun goSealed() {
        startActivity(Intent(this, SealedActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    private fun scanEnvironment() {
        if (sealing) return
        val pay = tabs.active?.isPaymentContext == true
        TamperMonitor.scanAsync(this, pay) { onSignals(it) }
    }

    private fun onSignals(signals: Set<TamperSignal>) {
        lastSignals = signals
        val critical = TamperMonitor.critical(signals)
        if (critical.isEmpty() || sealing) return
        val policy = container.security.tamperPolicy
        when (policy) {
            TamperPolicy.SEAL_LOCK, TamperPolicy.SEAL_WIPE -> {
                sealing = true
                SealedMode.trigger(this, critical, policy, GeckoBrowserActivity::class.java.name)
            }
            TamperPolicy.WARN -> {
                tabs.closeSecureTabs()
                if (!warnedCritical) { warnedCritical = true; toast(getString(R.string.sig_critical_warning)) }
            }
            TamperPolicy.OFF -> Unit
        }
    }

    // ------------------------------------------------------------------------------------------ app lock
    private fun maybeLock() {
        val lock = container.appLock
        lock.onForeground()
        if (!lock.needsUnlock()) { hideLockCover(); return }
        if (!AppLock.available(this)) { lock.markUnlocked(); hideLockCover(); return }     // nothing to unlock with
        showLockCover()
        promptUnlock()
    }

    private fun showLockCover() {
        if (lockCover != null) return
        val cover = FrameLayout(this).apply {
            setBackgroundColor(MaterialColors.getColor(b.root, com.google.android.material.R.attr.colorSurface))
            isClickable = true; isFocusable = true
            addView(
                MaterialButton(context).apply { text = getString(R.string.lock_unlock); setOnClickListener { promptUnlock() } },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
            )
        }
        (b.root as ViewGroup).addView(cover, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        lockCover = cover
    }

    private fun hideLockCover() {
        lockCover?.let { (b.root as ViewGroup).removeView(it) }
        lockCover = null
    }

    private fun promptUnlock() {
        if (unlockPromptOpen) return
        unlockPromptOpen = true
        AppLock.authenticate(this, getString(R.string.lock_auth_title)) { ok ->
            unlockPromptOpen = false
            if (ok) { container.appLock.markUnlocked(); hideLockCover() }
        }
    }

    // ------------------------------------------------------------------------------------------ payments
    private fun updateBanner(tab: GeckoTab) {
        val v = tab.verdict
        val domain = PaymentGuard.displayDomain(tab.url)
        val text: String? = when {
            tab.securePay -> getString(R.string.pay_banner_secure, domain.ifEmpty { "\u2014" })
            tab.isPaymentContext && v != null && !v.clean -> getString(R.string.pay_banner_warn, domain)
            tab.isPaymentContext -> getString(R.string.pay_banner_detected, domain)
            tab.isPrivate -> getString(R.string.gk_private_mode)
            else -> null
        }
        b.privateBanner.visibility = if (text != null) View.VISIBLE else View.GONE
        if (text != null) b.privateBanner.text = text
    }

    /** Menu / Security Center entry: device check, then (optionally) biometric, then the isolated payment tab. */
    private fun openSecurePayment(url: String?) {
        TamperMonitor.scanAsync(this, true) { signals ->
            lastSignals = signals
            if (TamperMonitor.critical(signals).isNotEmpty()) { onSignals(signals); return@scanAsync }
            val warnings = signals.filter { it.severity == Severity.WARN }
            val proceed = { authThen { tabs.newSecureTab(url) } }
            if (warnings.isEmpty()) proceed()
            else MaterialAlertDialogBuilder(this).setTitle(R.string.pay_env_title)
                .setMessage(warnings.joinToString("\n") { "\u2022 " + SecurityText.signal(this, it) })
                .setPositiveButton(R.string.pay_env_continue) { _, _ -> proceed() }
                .setNegativeButton(android.R.string.cancel, null).show()
        }
    }

    private fun authThen(block: () -> Unit) {
        if (container.security.payRequireAuth && AppLock.available(this)) AppLock.authenticate(this, getString(R.string.pay_auth_title)) { if (it) block() }
        else block()
    }

    private fun checkPaymentIdle() {
        if (!::tabs.isInitialized || tabs.tabs.none { it.securePay }) return
        if (SystemClock.elapsedRealtime() - lastInteraction >= container.security.payTimeoutSec * 1000L) {
            tabs.closeSecureTabs()
            toast(getString(R.string.pay_idle_closed))
        }
    }

    override fun paymentChanged(tab: GeckoTab) {
        main.post {
            if (tab !== tabs.active) return@post
            val v = tab.verdict
            val url = tab.url
            if (v != null && v.isPaymentContext) {
                if (!v.clean && tab.unsafeShownFor != url) { tab.unsafeShownFor = url; showUnsafePayment(tab, v) }
                else if (v.clean && !tab.securePay && tab.payPromptedFor != url) {
                    tab.payPromptedFor = url
                    Snackbar.make(b.root, R.string.pay_detected_msg, Snackbar.LENGTH_LONG)
                        .setAction(R.string.pay_open_secure) { openSecurePayment(url) }
                        .setAnchorView(b.bottomBar).show()
                }
            }
            if (attached === tab) updateChrome(tab)
        }
    }

    private fun showUnsafePayment(tab: GeckoTab, v: PaymentGuard.Verdict) {
        val force = tab.securePay && v.blocked                      // a Secure Payment tab never stays on a blocked page
        if (force) tab.load("about:blank")
        val dlg = MaterialAlertDialogBuilder(this).setTitle(R.string.pay_unsafe_title)
            .setMessage(v.issues.joinToString("\n") { "\u2022 " + SecurityText.issue(this, it, v) })
            .setPositiveButton(R.string.pay_unsafe_leave) { _, _ -> tab.load("about:blank") }
        if (!force) dlg.setNegativeButton(R.string.pay_unsafe_stay, null)
        dlg.show()
    }

    override fun confirmRepost(done: (Boolean) -> Unit) {
        main.post {
            MaterialAlertDialogBuilder(this).setMessage(R.string.gk_repost_msg)
                .setPositiveButton(R.string.gk_repost_send) { _, _ -> done(true) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> done(false) }
                .setOnCancelListener { done(false) }.show()
        }
    }

    // ------------------------------------------------------------------------------------------ small helpers
    private fun toast(msg: String) { Snackbar.make(b.root, msg, Snackbar.LENGTH_SHORT).setAnchorView(b.bottomBar).show() }

    private fun showKeyboard(v: View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard(v: View) {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }
}
