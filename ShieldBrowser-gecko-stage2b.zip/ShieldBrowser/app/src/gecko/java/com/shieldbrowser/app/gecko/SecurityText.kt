package com.shieldbrowser.app.gecko

import android.content.Context
import com.shieldbrowser.app.R
import com.shieldbrowser.app.security.PaymentGuard
import com.shieldbrowser.app.security.TamperSignal

/** Human-readable (localised) text for payment issues and tamper signals. Never shown on the sealed screen. */
object SecurityText {
    fun issue(c: Context, i: PaymentGuard.Issue, v: PaymentGuard.Verdict?): String = when (i) {
        PaymentGuard.Issue.NOT_HTTPS -> c.getString(R.string.issue_not_https)
        PaymentGuard.Issue.CREDENTIALS_IN_URL -> c.getString(R.string.issue_credentials)
        PaymentGuard.Issue.IP_HOST -> c.getString(R.string.issue_ip)
        PaymentGuard.Issue.PUNYCODE -> c.getString(R.string.issue_punycode)
        PaymentGuard.Issue.MIXED_SCRIPTS -> c.getString(R.string.issue_mixed)
        PaymentGuard.Issue.NON_STANDARD_PORT -> c.getString(R.string.issue_port)
        PaymentGuard.Issue.LOOKALIKE -> c.getString(R.string.issue_lookalike, v?.lookalikeOf ?: "?")
        PaymentGuard.Issue.CERT_EXCEPTION -> c.getString(R.string.issue_cert_exception)
        PaymentGuard.Issue.CONNECTION_NOT_SECURE -> c.getString(R.string.issue_not_secure)
    }

    fun signal(c: Context, s: TamperSignal): String = c.getString(
        when (s) {
            TamperSignal.DEBUGGER, TamperSignal.TRACER -> R.string.sig_debugger
            TamperSignal.DEBUGGABLE_BUILD -> R.string.sig_debuggable
            TamperSignal.SIGNATURE_MISMATCH -> R.string.sig_signature
            TamperSignal.HOOK_FRAMEWORK -> R.string.sig_hook
            TamperSignal.INSTRUMENTATION_SERVER -> R.string.sig_instrumentation
            TamperSignal.ROOT -> R.string.sig_root
            TamperSignal.EMULATOR -> R.string.sig_emulator
            TamperSignal.SCREEN_READER_APP -> R.string.sig_screen_reader
            TamperSignal.THIRD_PARTY_KEYBOARD -> R.string.sig_keyboard
        }
    )
}
