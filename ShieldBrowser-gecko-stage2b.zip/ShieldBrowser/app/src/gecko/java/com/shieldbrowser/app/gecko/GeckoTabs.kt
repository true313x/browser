package com.shieldbrowser.app.gecko

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.URLUtil
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.privacy.ClipboardGuard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.WebResponse

/**
 * The open tabs of the Gecko browser. Process-wide (see [get]) so tabs survive the activity being recreated
 * (rotation, theme change). Only the screen currently attached ([ui]) is asked for dialogs.
 */
class GeckoTabs private constructor(val appContext: Context, val container: AppContainer, val engine: GeckoEngine) {
    companion object {
        private const val KEY_SESSION = "gecko_session"
        @Volatile private var instance: GeckoTabs? = null

        fun get(context: Context, container: AppContainer): GeckoTabs {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: GeckoTabs(
                    context.applicationContext, container, GeckoEngine(context.applicationContext, container.settings)
                ).also { instance = it }
            }
        }
    }

    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var nextId = 1L
    private val list = ArrayList<GeckoTab>()
    var activeIndex = -1
        private set

    /** The screen currently showing the tabs, or null while the app is in the background. */
    @Volatile var ui: TabUi? = null

    val tabs: List<GeckoTab> get() = list
    val active: GeckoTab? get() = list.getOrNull(activeIndex)
    val count: Int get() = list.size
    fun privateCount(): Int = list.count { it.isPrivate }

    // ------------------------------------------------------------------------------------------ tab operations
    fun newTab(url: String?, isPrivate: Boolean, select: Boolean = true): GeckoTab {
        val tab = GeckoTab(nextId++, isPrivate, this)
        list.add(tab)
        if (!url.isNullOrEmpty()) tab.load(url)
        if (select) select(list.size - 1) else changed(tab)
        return tab
    }

    /**
     * Secure Payment tab: private, its own isolated storage context (deleted as a whole on close), https only,
     * never persisted, never in history, no downloads/permissions/external apps (see GeckoTab, PaymentGuard).
     */
    fun newSecureTab(url: String?): GeckoTab {
        val ctx = "pay" + java.util.UUID.randomUUID().toString().replace("-", "").take(16)
        val tab = GeckoTab(nextId++, true, this, securePay = true, contextId = ctx)
        list.add(tab)
        if (!url.isNullOrEmpty()) tab.load(url)
        select(list.size - 1)
        return tab
    }

    fun closeSecureTabs() {
        for (t in list.filter { it.securePay }) close(t)
    }

    /** window.open() / target=_blank: the new session is opened by GeckoView, we only wrap and show it. */
    fun newPopupTab(opener: GeckoTab): GeckoTab {
        val session = GeckoSession(sessionSettings(opener.isPrivate, opener.contextId))
        val tab = GeckoTab(nextId++, opener.isPrivate, this, popupSession = session, securePay = opener.securePay, contextId = opener.contextId)
        list.add(tab)
        select(list.size - 1)
        return tab
    }

    fun select(index: Int) {
        if (index !in list.indices) return
        active?.setActive(false)
        activeIndex = index
        active?.setActive(true)
        ui?.tabChanged(list[index])
    }

    fun close(tab: GeckoTab) {
        val i = list.indexOf(tab)
        if (i < 0) return
        val wasActive = i == activeIndex
        list.removeAt(i)
        tab.close()
        val ctx = tab.contextId
        if (tab.securePay && ctx != null && list.none { it.contextId == ctx }) {
            // last tab of this payment context: wipe its cookies/storage and anything copied to the clipboard
            engine.clearContext(ctx)
            ClipboardGuard.clear(appContext)
        }
        if (list.isEmpty()) {
            activeIndex = -1
            newTab(null, false)
            return
        }
        activeIndex = when {
            wasActive -> minOf(i, list.size - 1)
            i < activeIndex -> activeIndex - 1
            else -> activeIndex
        }
        active?.setActive(true)
        ui?.tabChanged(list[activeIndex])
    }

    fun closePrivateTabs() {
        for (t in list.filter { it.isPrivate }) close(t)
    }

    fun changed(tab: GeckoTab) { ui?.tabChanged(tab) }

    // ------------------------------------------------------------------------------------------ engine callbacks
    fun recordVisit(tab: GeckoTab) {
        val url = tab.url
        if (tab.isPrivate || tab.isPaymentContext || !container.settings.historyEnabled) return   // payment URLs carry tokens
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        val title = tab.title
        io.launch { container.history.add(url, title) }
    }

    fun handleDownload(tab: GeckoTab, response: WebResponse) {
        val body = response.body ?: return
        if (tab.securePay) { try { body.close() } catch (_: Exception) { }; return }     // no downloads from a payment tab
        val ui = ui
        if (ui == null) { try { body.close() } catch (_: Exception) { }; return }
        fun header(name: String): String? = response.headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value
        val mime = header("content-type")?.substringBefore(';')?.trim()
        val length = header("content-length")?.toLongOrNull() ?: -1L
        val name = URLUtil.guessFileName(response.uri, header("content-disposition"), mime)
        ui.download(tab, IncomingDownload(response.uri, name, mime, length, body))
    }

    /** A tab's content process died: reload it instead of leaving a blank page. */
    fun recover(tab: GeckoTab) {
        val url = tab.url
        tab.close()
        val i = list.indexOf(tab)
        if (i < 0) return
        val fresh = GeckoTab(nextId++, tab.isPrivate, this, securePay = tab.securePay, contextId = tab.contextId)
        list[i] = fresh
        if (url.isNotEmpty()) fresh.load(url)
        if (i == activeIndex) { fresh.setActive(true); ui?.tabChanged(fresh) }
    }

    fun openExternal(uri: String) {
        try {
            appContext.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------------------------------ persistence (URLs only)
    fun persist() {
        val arr = JSONArray()
        for (t in list) if (!t.isPrivate && !t.isPaymentContext && t.url.startsWith("http")) arr.put(t.url)
        container.settings.prefs.edit().putString(KEY_SESSION, arr.toString()).apply()
    }

    fun restore(): Boolean {
        if (list.isNotEmpty()) return true
        val raw = container.settings.prefs.getString(KEY_SESSION, null) ?: return false
        val urls = try { JSONArray(raw) } catch (_: Exception) { return false }
        for (i in 0 until urls.length()) {
            val u = urls.optString(i)
            if (u.startsWith("http")) newTab(u, false, select = false)
        }
        if (list.isEmpty()) return false
        select(0)
        return true
    }
}
