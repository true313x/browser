package com.shieldbrowser.app.gecko

import android.content.Context
import android.util.Log
import com.shieldbrowser.app.BuildConfig
import com.shieldbrowser.app.privacy.GeckoPrefs
import com.shieldbrowser.app.privacy.ProtectionLevel
import com.shieldbrowser.app.security.SecuritySettings
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.DnsMode
import org.json.JSONObject
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoPreferenceController
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.WebExtension

/**
 * Owns the process-wide [GeckoRuntime] and all engine-level privacy configuration.
 *
 * Three layers, all documented in GECKO.md:
 *  1. Runtime settings (constructor-time): Enhanced Tracking Protection STRICT, Total Cookie Protection (dFPI),
 *     cookie purging, query-parameter stripping, HTTPS-only, DNS-over-HTTPS, Global Privacy Control, no about:config,
 *     no remote debugging.
 *  2. Gecko preferences ([GeckoPrefs], by [ProtectionLevel]) written through GeckoPreferenceController.
 *  3. The built-in "Shield Blocker" WebExtension (bundled lists, runs offline).
 */
class GeckoEngine(private val app: Context, private val settings: BrowserSettings) {
    companion object {
        private const val TAG = "ShieldGecko"
        const val KEY_LEVEL = "gecko_protection_level"
        private const val EXT_URI = "resource://android/assets/shield-ext/"
        private const val EXT_ID = "shield@shieldbrowser.app"
        private const val PAGE_APP = "shieldpage"

        fun dohUrl(mode: DnsMode, providerId: String, custom: String): String? = when (mode) {
            DnsMode.SYSTEM -> null
            DnsMode.CUSTOM -> custom.takeIf { it.startsWith("https://") }
            DnsMode.SECURE -> when (providerId) {
                "quad9" -> "https://dns.quad9.net/dns-query"
                "mullvad" -> "https://dns.mullvad.net/dns-query"
                else -> "https://cloudflare-dns.com/dns-query"
            }
        }
    }

    /** Called (on a Gecko thread) with the number of requests the built-in blocker has cancelled so far. */
    @Volatile var onBlockedRequests: (Int) -> Unit = {}

    @Volatile private var rt: GeckoRuntime? = null
    private val security = SecuritySettings(settings.prefs)

    /** The built-in extension once Gecko has installed it (null before). Tabs attach their page bridge through [withExtension]. */
    @Volatile private var shieldExt: WebExtension? = null
    private val pendingExt = ArrayList<(WebExtension) -> Unit>()

    /** Runs [block] now if the built-in extension is ready, otherwise as soon as it is. */
    fun withExtension(block: (WebExtension) -> Unit) {
        val ready = synchronized(pendingExt) { val e = shieldExt; if (e == null) pendingExt.add(block); e }
        if (ready != null) block(ready)
    }

    /**
     * Receives {t:"pay"} messages from the extension's content script (card fields seen on the page: no field content,
     * ever) for ONE session. Content-script messages are delivered to the session's delegate, not the extension's.
     */
    fun attachPageBridge(session: org.mozilla.geckoview.GeckoSession, onPageMessage: (JSONObject) -> Unit) {
        withExtension { ext ->
            val d = object : WebExtension.MessageDelegate {
                override fun onMessage(nativeApp: String, message: Any, sender: WebExtension.MessageSender): GeckoResult<Any>? {
                    (message as? JSONObject)?.let(onPageMessage)
                    return null
                }
            }
            try { session.webExtensionController.setMessageDelegate(ext, d, PAGE_APP) } catch (e: Exception) { Log.w(TAG, "page bridge", e) }
        }
    }

    /** Deletes cookies/storage of one isolated session context (Secure Payment tabs). Close the sessions first. */
    fun clearContext(contextId: String) {
        try { runtime.storageController.clearDataForSessionContext(contextId) } catch (e: Exception) { Log.w(TAG, "clearContext", e) }
    }

    val runtime: GeckoRuntime
        get() = rt ?: synchronized(this) { rt ?: create().also { rt = it } }

    var level: ProtectionLevel
        get() = ProtectionLevel.of(settings.prefs.getString(KEY_LEVEL, null))
        set(v) {
            settings.prefs.edit().putString(KEY_LEVEL, v.id).apply()
            applyPrefs()
        }

    private fun create(): GeckoRuntime {
        val protection = ContentBlocking.Settings.Builder()
            .antiTracking(ContentBlocking.AntiTracking.STRICT)
            .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
            .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS)
            .cookieBehaviorPrivateMode(ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS)
            .strictSocialTrackingProtection(true)
            .cookiePurging(true)
            .queryParameterStrippingEnabled(true)
            .queryParameterStrippingPrivateBrowsingEnabled(true)
            .emailTrackerBlockingPrivateMode(true)
            .safeBrowsing(ContentBlocking.SafeBrowsing.DEFAULT)
            .build()

        val b = GeckoRuntimeSettings.Builder()
            .contentBlocking(protection)
            .javaScriptEnabled(true)
            .globalPrivacyControlEnabled(true)
            .allowInsecureConnections(GeckoRuntimeSettings.HTTPS_ONLY)
            .aboutConfigEnabled(false)
            .remoteDebuggingEnabled(false)
            .consoleOutput(false)
            .debugLogging(BuildConfig.DEBUG)
            .loginAutofillEnabled(false)
            .translationsOfferPopup(false)
            .extensionsProcessEnabled(true)
            .fissionEnabled(true)
            .preferredColorScheme(GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM)

        val doh = dohUrl(settings.dnsMode, settings.dnsProvider, settings.dnsCustomUrl)
        if (doh != null) {
            b.trustedRecursiveResolverMode(GeckoRuntimeSettings.TRR_MODE_FIRST)
            b.trustedRecursiveResolverUri(doh)
        }

        val runtime = GeckoRuntime.create(app, b.build())
        applyPrefs()
        installShieldBlocker(runtime)
        return runtime
    }

    /** Writes the Gecko preferences of the current [level] (and switches stronger ones back off when it was lowered). */
    fun applyPrefs() {
        val batch = ArrayList<GeckoPreferenceController.SetGeckoPreference<*>>()
        for ((name, value) in GeckoPrefs.plan(level)) {
            when (value) {
                is Boolean -> batch.add(GeckoPreferenceController.SetGeckoPreference.setBoolPref(name, value, GeckoPreferenceController.PREF_BRANCH_USER))
                is Int -> batch.add(GeckoPreferenceController.SetGeckoPreference.setIntPref(name, value, GeckoPreferenceController.PREF_BRANCH_USER))
                is String -> batch.add(GeckoPreferenceController.SetGeckoPreference.setStringPref(name, value, GeckoPreferenceController.PREF_BRANCH_USER))
            }
        }
        // GeckoResult.accept takes GeckoResult.Consumer (a plain void callback), not OnValueListener.
        GeckoPreferenceController.setGeckoPrefs(batch).accept(
            { result ->
                val failed = result?.filterValues { ok -> !ok }?.keys
                if (!failed.isNullOrEmpty()) Log.w(TAG, "Gecko refused these prefs: $failed")
            },
            { t -> Log.w(TAG, "setGeckoPrefs failed", t) }
        )
    }

    private fun installShieldBlocker(runtime: GeckoRuntime) {
        val delegate = object : WebExtension.MessageDelegate {
            override fun onMessage(nativeApp: String, message: Any, sender: WebExtension.MessageSender): GeckoResult<Any>? {
                val o = message as? JSONObject ?: return null
                return when (o.optString("t")) {
                    "stats" -> { onBlockedRequests(o.optInt("blocked", 0)); null }
                    // the extension polls this: paranoid-checkout switch lives in the encrypted settings
                    "config" -> GeckoResult.fromValue<Any>(JSONObject().put("payParanoid", security.payParanoid))
                    else -> null
                }
            }
        }
        val controller = runtime.webExtensionController
        controller.ensureBuiltIn(EXT_URI, EXT_ID).accept(
            { ext ->
                if (ext != null) {
                    ext.setMessageDelegate(delegate, "shield")
                    // Extensions do NOT run in private tabs unless allowed: without this the blocker (and the payment
                    // detector) were silently inactive in every private tab and Secure Payment tab.
                    controller.setAllowedInPrivateBrowsing(ext, true).accept(
                        { e2 -> publishExtension(e2 ?: ext) },
                        { t -> Log.w(TAG, "could not enable the extension in private tabs", t); publishExtension(ext) }
                    )
                }
            },
            { t -> Log.w(TAG, "Shield Blocker could not be installed", t) }
        )
    }

    private fun publishExtension(ext: WebExtension) {
        val todo = synchronized(pendingExt) { shieldExt = ext; ArrayList(pendingExt).also { pendingExt.clear() } }
        for (b in todo) b(ext)
    }

    /** Deletes cookies, caches and site data of every site (private tabs keep nothing anyway). */
    fun clearAllSiteData() {
        runtime.storageController.clearData(StorageController.ClearFlags.ALL)
    }
}
