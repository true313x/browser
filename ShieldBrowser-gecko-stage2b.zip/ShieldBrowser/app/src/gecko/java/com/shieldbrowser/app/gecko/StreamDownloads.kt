package com.shieldbrowser.app.gecko

import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.downloads.DownloadEngine
import com.shieldbrowser.app.downloads.DownloadSafety
import java.util.concurrent.Executors

/**
 * Saves downloads whose bytes GeckoView hands over as a stream (http(s), blob:, data:). Cookies/auth are already
 * applied by the engine, so no cookie copying is needed. They go through the same DownloadEngine (list, notifications,
 * dangerous-file warnings) as classic downloads but cannot be paused/resumed (the stream is gone once interrupted).
 */
class StreamDownloads(private val container: AppContainer) {
    private val io = Executors.newCachedThreadPool { r -> Thread(r, "gecko-download").also { it.isDaemon = true } }

    /** Returns false if the file could not even be created (e.g. not enough space); the stream is closed then. */
    fun start(d: IncomingDownload, isPrivate: Boolean): Boolean {
        val name = DownloadSafety.sanitizeFileName(d.fileName)
        val handle = container.downloads.beginPush(
            // "stream:" marks the item as non-resumable (DownloadItem.isStreamUrl) and keeps the real URL after it
            DownloadEngine.PushRequest("stream:" + d.url, name, d.mime, d.length, isPrivate)
        )
        if (handle == null) {
            try { d.body.close() } catch (_: Exception) { }
            return false
        }
        io.execute {
            try {
                d.body.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n == 0) continue
                        if (!container.downloads.push(handle, buf.copyOf(n))) return@execute   // cancelled / failed (engine already updated)
                    }
                }
                container.downloads.finishPush(handle)
            } catch (e: Exception) {
                container.downloads.failPush(handle, e.message ?: "I/O error")
            }
        }
        return true
    }
}
