package com.shieldbrowser.app.gecko

import android.content.Context
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.shieldbrowser.app.R

/**
 * Native start page (new tab): customizable background, a search field that hands focus to the address bar,
 * up to eight shortcut tiles and a one-line privacy summary. Pure views, no WebView/Gecko, no network.
 */
class StartPageView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {
    private val bg = ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val scrim = View(context)
    private val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
    private val title = TextView(context)
    private val searchHint = TextView(context)
    private val summary = TextView(context)
    private val tileHost = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private var hasBackground = false

    var onSearchClick: () -> Unit = {}
    var onTileClick: (String) -> Unit = {}

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics)
    private fun dpi(v: Int) = dp(v).toInt()

    init {
        addView(bg, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(scrim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val scroll = ScrollView(context).apply { isFillViewport = true; isVerticalScrollBarEnabled = false }
        addView(scroll, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        scroll.addView(column, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        column.setPadding(dpi(24), dpi(72), dpi(24), dpi(24))

        title.text = context.getString(R.string.app_name)
        title.textSize = 34f
        title.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        title.gravity = Gravity.CENTER
        column.addView(title, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        val card = MaterialCardView(context).apply {
            radius = dp(30)
            cardElevation = dp(2)
            isClickable = true
            isFocusable = true
            setOnClickListener { onSearchClick() }
            contentDescription = context.getString(R.string.gk_search_or_type)
        }
        searchHint.text = context.getString(R.string.gk_search_or_type)
        searchHint.textSize = 16f
        searchHint.gravity = Gravity.CENTER_VERTICAL
        searchHint.setPadding(dpi(22), 0, dpi(22), 0)
        searchHint.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        searchHint.compoundDrawablePadding = dpi(12)
        card.addView(searchHint, LayoutParams(LayoutParams.MATCH_PARENT, dpi(60)))
        column.addView(card, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(28) })

        column.addView(tileHost, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(28) })

        summary.textSize = 13f
        summary.gravity = Gravity.CENTER
        column.addView(summary, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(24) })
        applyColors()
    }

    /** Keeps the content column readable (max 560dp) on tablets. */
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val max = dpi(560) + dpi(48)
        val pad = if (w > max) (w - max) / 2 + dpi(24) else dpi(24)
        column.setPadding(pad, dpi(72), pad, dpi(24))
    }

    fun setBackgroundConfig(drawable: Drawable?, blur: Int, dim: Int) {
        hasBackground = drawable != null
        bg.setImageDrawable(drawable)
        bg.visibility = if (drawable != null) View.VISIBLE else View.GONE
        scrim.setBackgroundColor(if (drawable != null) Color.argb(dim * 255 / 100, 0, 0, 0) else Color.TRANSPARENT)
        if (Build.VERSION.SDK_INT >= 31) {
            bg.setRenderEffect(if (blur > 0) RenderEffect.createBlurEffect(blur.toFloat(), blur.toFloat(), Shader.TileMode.CLAMP) else null)
        }
        applyColors()
    }

    private fun applyColors() {
        val onBg = if (hasBackground) Color.WHITE else MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface)
        title.setTextColor(onBg)
        summary.setTextColor(if (hasBackground) 0xCCFFFFFF.toInt() else MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant))
        searchHint.setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant))
        searchHint.compoundDrawablesRelative.forEach { it?.setTint(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant)) }
    }

    fun setSummary(text: String) { summary.text = text }

    /** [items] = (title, url); at most 8, shown 4 per row. */
    fun setTiles(items: List<Pair<String, String>>) {
        tileHost.removeAllViews()
        for (chunk in items.take(8).chunked(4)) {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until 4) {
                val item = chunk.getOrNull(i)
                row.addView(tile(item), LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            }
            tileHost.addView(row, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { bottomMargin = dpi(12) })
        }
    }

    private fun tile(item: Pair<String, String>?): View {
        val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        if (item == null) return box
        val letter = TextView(context).apply {
            text = item.first.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "•"
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.HSVToColor(floatArrayOf(Math.floorMod(item.second.hashCode(), 360).toFloat(), 0.55f, 0.62f)))
            }
        }
        box.addView(letter, LinearLayout.LayoutParams(dpi(52), dpi(52)))
        val label = TextView(context).apply {
            text = item.first
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setTextColor(if (hasBackground) Color.WHITE else MaterialColors.getColor(this@StartPageView, com.google.android.material.R.attr.colorOnSurface))
        }
        box.addView(label, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(6) })
        box.isClickable = true
        box.isFocusable = true
        box.setOnClickListener { onTileClick(item.second) }
        return box
    }
}
