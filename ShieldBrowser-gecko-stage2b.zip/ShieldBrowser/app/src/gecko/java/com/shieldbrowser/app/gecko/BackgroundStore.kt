package com.shieldbrowser.app.gecko

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import com.shieldbrowser.app.R
import java.io.File
import java.io.FileOutputStream

class BgPreset(val id: String, val nameRes: Int, val colors: IntArray)

object BackgroundPresets {
    val all: List<BgPreset> = listOf(
        BgPreset("aurora", R.string.gk_bg_aurora, intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())),
        BgPreset("sunset", R.string.gk_bg_sunset, intArrayOf(0xFFFF512F.toInt(), 0xFFDD2476.toInt())),
        BgPreset("ocean", R.string.gk_bg_ocean, intArrayOf(0xFF2193B0.toInt(), 0xFF6DD5ED.toInt())),
        BgPreset("forest", R.string.gk_bg_forest, intArrayOf(0xFF134E5E.toInt(), 0xFF71B280.toInt())),
        BgPreset("midnight", R.string.gk_bg_midnight, intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 0xFF24243E.toInt())),
        BgPreset("rose", R.string.gk_bg_rose, intArrayOf(0xFFEECDA3.toInt(), 0xFFEF629F.toInt())),
        BgPreset("mint", R.string.gk_bg_mint, intArrayOf(0xFF00B09B.toInt(), 0xFF96C93D.toInt())),
        BgPreset("graphite", R.string.gk_bg_graphite, intArrayOf(0xFF232526.toInt(), 0xFF414345.toInt()))
    )

    fun gradient(p: BgPreset): Drawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, p.colors)
}

/**
 * The customizable start-page background: a gradient preset, a solid colour, or the user's own photo (copied into
 * app-private storage, downscaled; never leaves the device), plus blur and dimming.
 */
class BackgroundStore(private val ctx: Context, private val prefs: SharedPreferences) {
    enum class Kind { NONE, PRESET, COLOR, IMAGE }

    companion object {
        private const val K_KIND = "gecko_bg_kind"
        private const val K_PRESET = "gecko_bg_preset"
        private const val K_COLOR = "gecko_bg_color"
        private const val K_BLUR = "gecko_bg_blur"
        private const val K_DIM = "gecko_bg_dim"
        private const val MAX_SIDE = 1600
    }

    private val imageFile: File get() = File(ctx.filesDir, "backgrounds/start.jpg")

    var kind: Kind
        get() = try { Kind.valueOf(prefs.getString(K_KIND, null) ?: Kind.PRESET.name) } catch (_: Exception) { Kind.PRESET }
        set(v) { prefs.edit().putString(K_KIND, v.name).apply() }

    var presetId: String
        get() = prefs.getString(K_PRESET, null) ?: BackgroundPresets.all[0].id
        set(v) { prefs.edit().putString(K_PRESET, v).apply() }

    var color: Int
        get() = prefs.getInt(K_COLOR, 0xFF1B2A41.toInt())
        set(v) { prefs.edit().putInt(K_COLOR, v).apply() }

    /** 0..25 (pixels of blur radius; only effective on Android 12+). */
    var blur: Int
        get() = prefs.getInt(K_BLUR, 0).coerceIn(0, 25)
        set(v) { prefs.edit().putInt(K_BLUR, v.coerceIn(0, 25)).apply() }

    /** 0..80 (% of black laid over the background so text stays readable). */
    var dim: Int
        get() = prefs.getInt(K_DIM, 25).coerceIn(0, 80)
        set(v) { prefs.edit().putInt(K_DIM, v.coerceIn(0, 80)).apply() }

    fun drawable(): Drawable? = when (kind) {
        Kind.NONE -> null
        Kind.PRESET -> BackgroundPresets.gradient(BackgroundPresets.all.firstOrNull { it.id == presetId } ?: BackgroundPresets.all[0])
        Kind.COLOR -> ColorDrawable(color)
        Kind.IMAGE -> BitmapFactory.decodeFile(imageFile.path)?.let { BitmapDrawable(ctx.resources, it) }
            ?: BackgroundPresets.gradient(BackgroundPresets.all[0])
    }

    /** Reads [uri] (photo picker / SAF), downsamples to at most 1600 px and stores it privately. Call off the main thread. */
    fun saveImage(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var sample = 1
            while (bounds.outWidth / sample > MAX_SIDE * 2 || bounds.outHeight / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val scale = MAX_SIDE.toFloat() / maxOf(bmp.width, bmp.height)
            val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            imageFile.parentFile?.mkdirs()
            FileOutputStream(imageFile).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            kind = Kind.IMAGE
            true
        } catch (_: Exception) { false }
    }
}
