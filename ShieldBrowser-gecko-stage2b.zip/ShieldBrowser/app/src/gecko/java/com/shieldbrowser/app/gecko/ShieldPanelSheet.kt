package com.shieldbrowser.app.gecko

import android.app.Activity
import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.shieldbrowser.app.R
import com.shieldbrowser.app.privacy.ProtectionLevel
import com.shieldbrowser.app.ui.fitScreen

/** What was blocked on this page, the protection level, wipe-everything and links to public fingerprint tests. */
class ShieldPanelSheet(
    private val activity: Activity,
    private val tab: GeckoTab?,
    private val engine: GeckoEngine,
    private val shieldBlockerTotal: Int,
    private val openInNewTab: (String) -> Unit,
    private val clearAllData: () -> Unit
) {
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), activity.resources.displayMetrics).toInt()

    private fun title(text: String) = TextView(activity).apply {
        this.text = text
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun body(text: String) = TextView(activity).apply {
        this.text = text
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium)
    }

    fun show() {
        val dlg = BottomSheetDialog(activity)
        val col = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(28)) }
        dlg.setContentView(ScrollView(activity).apply { addView(col) })
        dlg.fitScreen()

        col.addView(TextView(activity).apply {
            text = activity.getString(R.string.gk_panel_title)
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_HeadlineSmall)
        })

        // ---- this page -------------------------------------------------------------------------------------
        col.addView(title(activity.getString(R.string.gk_this_page)))
        if (tab == null || tab.isStartPage) col.addView(body(activity.getString(R.string.gk_no_page)))
        else {
            col.addView(body(activity.getString(R.string.gk_blocked_ads, tab.adsBlocked)))
            col.addView(body(activity.getString(R.string.gk_blocked_trackers, tab.trackersBlocked)))
            col.addView(body(activity.getString(R.string.gk_blocked_fingerprinters, tab.fingerprintersBlocked)))
            col.addView(body(activity.getString(R.string.gk_blocked_miners, tab.minersBlocked)))
        }
        col.addView(body(activity.getString(R.string.gk_blocked_by_blocker, shieldBlockerTotal)))

        // ---- protection level ------------------------------------------------------------------------------
        col.addView(title(activity.getString(R.string.gk_level)))
        val group = ChipGroup(activity).apply { isSingleSelection = true; isSelectionRequired = true }
        val note = body("")
        fun describe(l: ProtectionLevel) = activity.getString(
            when (l) {
                ProtectionLevel.STANDARD -> R.string.gk_level_standard_desc
                ProtectionLevel.STRICT -> R.string.gk_level_strict_desc
                ProtectionLevel.MAXIMUM -> R.string.gk_level_maximum_desc
            }
        )
        for (l in ProtectionLevel.values()) {
            val chip = Chip(activity).apply {
                text = activity.getString(
                    when (l) {
                        ProtectionLevel.STANDARD -> R.string.gk_level_standard
                        ProtectionLevel.STRICT -> R.string.gk_level_strict
                        ProtectionLevel.MAXIMUM -> R.string.gk_level_maximum
                    }
                )
                isCheckable = true
                isChecked = l == engine.level
                setOnClickListener { engine.level = l; note.text = describe(l) }
            }
            group.addView(chip)
        }
        note.text = describe(engine.level)
        col.addView(group)
        col.addView(note)

        // ---- tools -----------------------------------------------------------------------------------------
        col.addView(title(activity.getString(R.string.gk_clear_title)))
        col.addView(MaterialButton(activity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = activity.getString(R.string.gk_clear_data)
            setOnClickListener { dlg.dismiss(); clearAllData() }
        })

        col.addView(title(activity.getString(R.string.gk_lab_title)))
        col.addView(body(activity.getString(R.string.gk_lab_desc)))
        val labs = listOf(
            R.string.gk_lab_eff to "https://coveryourtracks.eff.org/",
            R.string.gk_lab_creep to "https://abrahamjuliot.github.io/creepjs/",
            R.string.gk_lab_browserleaks to "https://browserleaks.com/",
            R.string.gk_lab_ipleak to "https://ipleak.net/"
        )
        for ((label, url) in labs) {
            col.addView(MaterialButton(activity, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = activity.getString(label)
                setOnClickListener { dlg.dismiss(); openInNewTab(url) }
            })
        }
        dlg.show()
    }
}
