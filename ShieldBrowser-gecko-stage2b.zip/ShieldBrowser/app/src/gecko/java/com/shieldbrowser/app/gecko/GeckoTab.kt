package com.shieldbrowser.app.gecko

import android.net.Uri
import com.shieldbrowser.app.R
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.security.PaymentGuard
import org.json.JSONObject
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebResponse
import java.io.InputStream

private typealias PromptResponse = GeckoSession.PromptDelegate.PromptResponse

/** Session settings shared by normal, popup and Secure Payment sessions. */
internal fun sessionSettings(isPrivate: Boolean, contextId: String?): GeckoSessionSettings {
    val b = GeckoSessionSettings.Builder().usePrivateMode(isPrivate).suspendMediaWhenInactive(true)
    if (contextId != null) b.contextId(contextId)
    return b.build()
}

/** One entry of a <select>/menu prompt, flattened (groups become disabled header rows). */
class ChoiceItem(val label: String, val disabled: Boolean, val selected: Boolean, val raw: GeckoSession.PromptDelegate.ChoicePrompt.Choice)

/** A download whose bytes the ENGINE hands over (http(s), blob:, data:). Read [body] on a background thread. */
class IncomingDownload(val url: String, val fileName: String, val mime: String?, val length: Long, val body: InputStream)

/** Everything a tab needs from the screen that shows it. Implemented by GeckoBrowserActivity; may be null while detached. */
interface TabUi {
    fun tabChanged(tab: GeckoTab)
    fun alert(message: String, done: () -> Unit)
    fun confirm(message: String, done: (Boolean) -> Unit)
    fun prompt(message: String, default: String, done: (String?) -> Unit)
    fun auth(host: String, passwordOnly: Boolean, done: (user: String?, password: String?) -> Unit)
    fun choose(items: List<ChoiceItem>, multiple: Boolean, done: (List<ChoiceItem>?) -> Unit)
    /** Must return file:// Uris (GeckoView cannot read content:// Uris). */
    fun pickFiles(multiple: Boolean, mimeTypes: Array<String>, done: (List<Uri>?) -> Unit)
    fun sitePermission(host: String, whatRes: Int, done: (Boolean) -> Unit)
    fun androidPermissions(permissions: Array<String>, done: (Boolean) -> Unit)
    fun fullScreen(on: Boolean)
    fun contextMenu(linkUrl: String?, imageUrl: String?)
    fun download(tab: GeckoTab, download: IncomingDownload)
    fun externalApp(uri: String, done: (Boolean) -> Unit)
    /** A form is about to be re-sent (POST repeat). For payments this can mean being charged twice. */
    fun confirmRepost(done: (Boolean) -> Unit)
    /** The payment verdict of [tab] changed (issues found, or card fields detected). */
    fun paymentChanged(tab: GeckoTab)
}

/**
 * One browser tab = one GeckoSession plus its delegates. All delegate callbacks arrive on the UI thread.
 * The engine (not this class) enforces tracking protection, HTTPS-only, cookie isolation and fingerprinting protection.
 */
class GeckoTab(
    val id: Long,
    val isPrivate: Boolean,
    private val owner: GeckoTabs,
    popupSession: GeckoSession? = null,
    /** Secure Payment tab: private + its own isolated storage context, https only, no downloads/permissions/external apps. */
    val securePay: Boolean = false,
    /** Gecko session context id; storage of one context is deleted as a whole when the secure tab closes. */
    val contextId: String? = null
) {
    val session: GeckoSession = popupSession ?: GeckoSession(sessionSettings(isPrivate, contextId))

    var url: String = ""
        private set
    var title: String = ""
        private set
    var progress: Int = 0
        private set
    var loading: Boolean = false
        private set
    var canGoBack: Boolean = false
        private set
    var canGoForward: Boolean = false
        private set
    var secure: Boolean = false
        private set

    // ---- payment context (see security/PaymentGuard.kt) -------------------------------------------------------------
    /** The page itself exposed card fields (reported by the built-in extension; never any field content). */
    var payFieldSeen = false
        private set
    var certException = false
        private set
    /** False until onSecurityChange arrived for the current origin (it comes AFTER onLocationChange). */
    private var securityKnown = false
    /** Opened by GeckoView for window.open(): GeckoView itself opens the session, the UI must not. */
    val isPopup: Boolean = popupSession != null
    var verdict: PaymentGuard.Verdict? = null
        private set
    /** Dialogs/prompts already shown for this tab and URL, so they do not repeat on every callback. */
    var unsafeShownFor: String? = null
    var payPromptedFor: String? = null

    /** True for Secure Payment tabs and for any tab whose page looks like a payment page. */
    val isPaymentContext: Boolean get() = securePay || verdict?.isPaymentContext == true

    private fun reassess() {
        val u = url
        verdict = if (u.startsWith("http")) PaymentGuard.assess(u, if (securityKnown) secure else null, certException, payFieldSeen) else null
        owner.ui?.paymentChanged(this)
    }

    // blocked-content counters of the current page (from the engine's ContentBlocking delegate)
    var adsBlocked = 0
        private set
    var trackersBlocked = 0
        private set
    var fingerprintersBlocked = 0
        private set
    var minersBlocked = 0
        private set

    /** True while the tab shows our native start page instead of a web page. */
    val isStartPage: Boolean get() = url.isEmpty() || url == "about:blank"

    init {
        session.navigationDelegate = navigationDelegate()
        session.progressDelegate = progressDelegate()
        session.contentDelegate = contentDelegate()
        session.permissionDelegate = permissionDelegate()
        session.promptDelegate = promptDelegate()
        session.contentBlockingDelegate = blockingDelegate()
        // A popup session is opened by GeckoView itself (it must still be closed when returned from onNewSession).
        if (popupSession == null) session.open(owner.engine.runtime)
        owner.engine.attachPageBridge(session) { msg -> onPageMessage(msg) }
    }

    private fun onPageMessage(m: JSONObject) {
        if (m.optString("t") == "pay" && !payFieldSeen) { payFieldSeen = true; reassess(); changed() }
    }

    fun load(target: String) { session.loadUri(target) }
    fun goBack() = session.goBack()
    fun goForward() = session.goForward()
    fun reload() = session.reload()
    fun stop() = session.stop()
    fun setActive(active: Boolean) = session.setActive(active)
    fun close() { try { session.close() } catch (_: Exception) { } }

    private fun changed() { owner.changed(this) }

    // ------------------------------------------------------------------------------------------ navigation
    private fun navigationDelegate() = object : GeckoSession.NavigationDelegate {
        override fun onLocationChange(
            session: GeckoSession, url: String?,
            perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>, hasUserGesture: Boolean
        ) {
            val newUrl = url.orEmpty()
            val sameOrigin = DomainUtils.schemeOf(newUrl) == DomainUtils.schemeOf(this@GeckoTab.url) &&
                DomainUtils.hostOf(newUrl) == DomainUtils.hostOf(this@GeckoTab.url)
            if (!sameOrigin) { payFieldSeen = false; certException = false; securityKnown = false }
            this@GeckoTab.url = newUrl
            reassess()
            changed()
        }

        override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) { this@GeckoTab.canGoBack = canGoBack; changed() }
        override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) { this@GeckoTab.canGoForward = canGoForward; changed() }

        override fun onLoadRequest(session: GeckoSession, request: GeckoSession.NavigationDelegate.LoadRequest): GeckoResult<AllowOrDeny>? {
            val uri = request.uri
            val scheme = DomainUtils.schemeOf(uri)
            if (securePay) {
                // Secure Payment tab: https only (plus about:blank). No blob:/data:/view-source:/external apps.
                val ok = scheme == "https" || uri == "about:blank"
                return GeckoResult.fromValue(if (ok) AllowOrDeny.ALLOW else AllowOrDeny.DENY)
            }
            return when (scheme) {
                "http", "https", "about", "blob", "view-source" -> GeckoResult.fromValue(AllowOrDeny.ALLOW)
                // never meaningful from a web page and never to be handed to another app
                "file", "content", "javascript", "data", "ftp" -> GeckoResult.fromValue(AllowOrDeny.DENY)
                else -> {
                    // tel:, mailto:, intent:, market: … are never opened silently
                    owner.ui?.externalApp(uri) { ok -> if (ok) owner.openExternal(uri) }
                    GeckoResult.fromValue(AllowOrDeny.DENY)
                }
            }
        }

        override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
            val popup = owner.newPopupTab(this@GeckoTab)
            return GeckoResult.fromValue(popup.session)
        }
    }

    // ------------------------------------------------------------------------------------------ progress
    private fun progressDelegate() = object : GeckoSession.ProgressDelegate {
        override fun onPageStart(session: GeckoSession, url: String) {
            loading = true; progress = 5
            adsBlocked = 0; trackersBlocked = 0; fingerprintersBlocked = 0; minersBlocked = 0
            changed()
        }

        override fun onPageStop(session: GeckoSession, success: Boolean) {
            loading = false; progress = 100
            changed()
            if (success) owner.recordVisit(this@GeckoTab)
        }

        override fun onProgressChange(session: GeckoSession, progress: Int) {
            this@GeckoTab.progress = progress
            changed()
        }

        override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {
            secure = securityInfo.isSecure
            certException = securityInfo.isException
            securityKnown = true
            reassess()
            changed()
        }
    }

    // ------------------------------------------------------------------------------------------ content
    private fun contentDelegate() = object : GeckoSession.ContentDelegate {
        override fun onTitleChange(session: GeckoSession, title: String?) { this@GeckoTab.title = title.orEmpty(); changed() }

        override fun onContextMenu(session: GeckoSession, screenX: Int, screenY: Int, element: GeckoSession.ContentDelegate.ContextElement) {
            val image = if (element.type == GeckoSession.ContentDelegate.ContextElement.TYPE_IMAGE) element.srcUri else null
            owner.ui?.contextMenu(element.linkUri, image)
        }

        override fun onExternalResponse(session: GeckoSession, response: WebResponse) { owner.handleDownload(this@GeckoTab, response) }
        override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) { owner.ui?.fullScreen(fullScreen) }
        override fun onCrash(session: GeckoSession) { owner.recover(this@GeckoTab) }
        override fun onKill(session: GeckoSession) { owner.recover(this@GeckoTab) }
        override fun onCloseRequest(session: GeckoSession) { owner.close(this@GeckoTab) }
    }

    // ------------------------------------------------------------------------------------------ blocking stats
    private fun blockingDelegate() = object : ContentBlocking.Delegate {
        override fun onContentBlocked(session: GeckoSession, event: ContentBlocking.BlockEvent) {
            if (!event.isBlocking) return
            val c = event.antiTrackingCategory
            when {
                c and ContentBlocking.AntiTracking.AD != 0 -> adsBlocked++
                c and ContentBlocking.AntiTracking.FINGERPRINTING != 0 -> fingerprintersBlocked++
                c and ContentBlocking.AntiTracking.CRYPTOMINING != 0 -> minersBlocked++
                else -> trackersBlocked++
            }
            changed()
        }
    }

    // ------------------------------------------------------------------------------------------ permissions
    private fun permissionDelegate() = object : GeckoSession.PermissionDelegate {
        override fun onContentPermissionRequest(
            session: GeckoSession, perm: GeckoSession.PermissionDelegate.ContentPermission
        ): GeckoResult<Int>? {
            val deny = GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
            if (securePay) return deny
            val ui = owner.ui ?: return deny
            // Only location is ever offered. Notifications, autoplay, persistent storage, DRM and XR are denied.
            if (perm.permission != GeckoSession.PermissionDelegate.PERMISSION_GEOLOCATION) return deny
            val result = GeckoResult<Int>()
            ui.sitePermission(DomainUtils.hostOf(perm.uri) ?: "", R.string.gk_perm_location) { ok ->
                result.complete(
                    if (ok) GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                    else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                )
            }
            return result
        }

        override fun onMediaPermissionRequest(
            session: GeckoSession, uri: String,
            video: Array<GeckoSession.PermissionDelegate.MediaSource>?,
            audio: Array<GeckoSession.PermissionDelegate.MediaSource>?,
            callback: GeckoSession.PermissionDelegate.MediaCallback
        ) {
            val ui = owner.ui
            if (ui == null || securePay) { callback.reject(); return }
            val what = when {
                video != null && audio != null -> R.string.gk_perm_camera_mic
                video != null -> R.string.gk_perm_camera
                else -> R.string.gk_perm_mic
            }
            ui.sitePermission(DomainUtils.hostOf(uri) ?: "", what) { ok ->
                if (ok) callback.grant(video?.firstOrNull(), audio?.firstOrNull()) else callback.reject()
            }
        }

        override fun onAndroidPermissionsRequest(
            session: GeckoSession, permissions: Array<String>?, callback: GeckoSession.PermissionDelegate.Callback
        ) {
            val ui = owner.ui
            if (ui == null || securePay) { callback.reject(); return }
            ui.androidPermissions(permissions ?: emptyArray()) { ok -> if (ok) callback.grant() else callback.reject() }
        }
    }

    // ------------------------------------------------------------------------------------------ prompts
    private fun promptDelegate() = object : GeckoSession.PromptDelegate {
        override fun onAlertPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AlertPrompt): GeckoResult<PromptResponse>? {
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.dismiss())
            val r = GeckoResult<PromptResponse>()
            ui.alert(prompt.message.orEmpty()) { r.complete(prompt.dismiss()) }
            return r
        }

        override fun onButtonPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ButtonPrompt): GeckoResult<PromptResponse>? {
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.dismiss())
            val r = GeckoResult<PromptResponse>()
            ui.confirm(prompt.message.orEmpty()) { ok ->
                r.complete(
                    prompt.confirm(
                        if (ok) GeckoSession.PromptDelegate.ButtonPrompt.Type.POSITIVE
                        else GeckoSession.PromptDelegate.ButtonPrompt.Type.NEGATIVE
                    )
                )
            }
            return r
        }

        override fun onTextPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.TextPrompt): GeckoResult<PromptResponse>? {
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.dismiss())
            val r = GeckoResult<PromptResponse>()
            ui.prompt(prompt.message.orEmpty(), prompt.defaultValue.orEmpty()) { text ->
                r.complete(if (text == null) prompt.dismiss() else prompt.confirm(text))
            }
            return r
        }

        override fun onAuthPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AuthPrompt): GeckoResult<PromptResponse>? {
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.dismiss())
            val opts = prompt.authOptions
            val passwordOnly = (opts.flags and GeckoSession.PromptDelegate.AuthPrompt.AuthOptions.Flags.ONLY_PASSWORD) != 0
            val r = GeckoResult<PromptResponse>()
            ui.auth(DomainUtils.hostOf(opts.uri ?: "") ?: "", passwordOnly) { user, password ->
                r.complete(
                    when {
                        password == null -> prompt.dismiss()
                        passwordOnly -> prompt.confirm(password)
                        else -> prompt.confirm(user.orEmpty(), password)
                    }
                )
            }
            return r
        }

        override fun onChoicePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ChoicePrompt): GeckoResult<PromptResponse>? {
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.dismiss())
            val items = ArrayList<ChoiceItem>()
            fun add(choices: Array<GeckoSession.PromptDelegate.ChoicePrompt.Choice>?, indent: String) {
                if (choices == null) return
                for (c in choices) {
                    val children = c.items
                    if (c.separator) continue
                    if (children != null && children.isNotEmpty()) {
                        items.add(ChoiceItem(indent + c.label.orEmpty(), true, false, c))      // group header
                        add(children, "$indent  ")
                    } else items.add(ChoiceItem(indent + c.label.orEmpty(), c.disabled, c.selected, c))
                }
            }
            add(prompt.choices, "")
            val multiple = prompt.type == GeckoSession.PromptDelegate.ChoicePrompt.Type.MULTIPLE
            val r = GeckoResult<PromptResponse>()
            ui.choose(items, multiple) { picked ->
                r.complete(
                    when {
                        picked.isNullOrEmpty() -> prompt.dismiss()
                        multiple -> prompt.confirm(picked.map { it.raw }.toTypedArray())
                        else -> prompt.confirm(picked[0].raw)
                    }
                )
            }
            return r
        }

        override fun onFilePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.FilePrompt): GeckoResult<PromptResponse>? {
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.dismiss())
            if (prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.FOLDER) return GeckoResult.fromValue(prompt.dismiss())
            val multiple = prompt.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE
            val r = GeckoResult<PromptResponse>()
            ui.pickFiles(multiple, prompt.mimeTypes ?: emptyArray()) { uris ->
                r.complete(
                    when {
                        uris.isNullOrEmpty() -> prompt.dismiss()
                        multiple -> prompt.confirm(owner.appContext, uris.toTypedArray())
                        else -> prompt.confirm(owner.appContext, uris[0])
                    }
                )
            }
            return r
        }

        override fun onPopupPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.PopupPrompt): GeckoResult<PromptResponse>? =
            GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY))          // script-opened popups without a user gesture

        override fun onBeforeUnloadPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.BeforeUnloadPrompt): GeckoResult<PromptResponse>? =
            GeckoResult.fromValue(prompt.confirm(AllowOrDeny.ALLOW))

        override fun onRepostConfirmPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.RepostConfirmPrompt): GeckoResult<PromptResponse>? {
            // Was auto-allowed: re-sending a POST (a payment!) without asking can charge twice. Always ask.
            val ui = owner.ui ?: return GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY))
            val r = GeckoResult<PromptResponse>()
            ui.confirmRepost { ok -> r.complete(prompt.confirm(if (ok) AllowOrDeny.ALLOW else AllowOrDeny.DENY)) }
            return r
        }
    }
}
