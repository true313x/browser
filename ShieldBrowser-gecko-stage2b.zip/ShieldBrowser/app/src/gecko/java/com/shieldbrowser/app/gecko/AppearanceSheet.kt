package com.shieldbrowser.app.gecko

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.shieldbrowser.app.R
import com.shieldbrowser.app.ui.fitScreen

/** Colour palette, wallpaper-based colours, start-page background (preset / photo / none), blur and dimming. */
class AppearanceSheet(
    private val activity: Activity,
    private val prefs: SharedPreferences,
    private val backgrounds: BackgroundStore,
    private val pickPhoto: () -> Unit,
    private val onBackgroundChanged: () -> Unit
) {
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), activity.resources.displayMetrics).toInt()

    private fun header(text: String) = TextView(activity).apply {
        this.text = text
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
        setPadding(0, dp(18), 0, dp(8))
    }

    private fun circle(color: Int, selected: Boolean, description: String, onClick: () -> Unit) = View(activity).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(if (selected) 3 else 1), if (selected) Color.WHITE else 0x55888888)
        }
        contentDescription = description
        isClickable = true
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) }
    }

    fun show() {
        val dlg = BottomSheetDialog(activity)
        val col = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(28)) }
        dlg.setContentView(ScrollView(activity).apply { addView(col) })
        dlg.fitScreen()

        // --- accent colour -------------------------------------------------------------------------------------
        col.addView(header(activity.getString(R.string.gk_accent)))
        val accentRow = LinearLayout(activity)
        col.addView(HorizontalScrollView(activity).apply { isHorizontalScrollBarEnabled = false; addView(accentRow) })
        val current = ThemeManager.accent(prefs)
        for (a in ThemeManager.accents) {
            accentRow.addView(circle(a.swatch, a.id == current.id, activity.getString(a.nameRes)) {
                prefs.edit().putString(ThemeManager.KEY_ACCENT, a.id).apply()
                dlg.dismiss(); activity.recreate()
            })
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val sw = MaterialSwitch(activity).apply {
                text = activity.getString(R.string.gk_dynamic_colors)
                isChecked = prefs.getBoolean(ThemeManager.KEY_DYNAMIC, false)
                setOnCheckedChangeListener { _, on ->
                    prefs.edit().putBoolean(ThemeManager.KEY_DYNAMIC, on).apply()
                    dlg.dismiss(); activity.recreate()
                }
            }
            col.addView(sw, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }

        // --- background ----------------------------------------------------------------------------------------
        col.addView(header(activity.getString(R.string.gk_background)))
        val bgRow = LinearLayout(activity)
        col.addView(HorizontalScrollView(activity).apply { isHorizontalScrollBarEnabled = false; addView(bgRow) })
        for (p in BackgroundPresets.all) {
            val selected = backgrounds.kind == BackgroundStore.Kind.PRESET && backgrounds.presetId == p.id
            bgRow.addView(circle(p.colors[p.colors.size / 2], selected, activity.getString(p.nameRes)) {
                backgrounds.presetId = p.id; backgrounds.kind = BackgroundStore.Kind.PRESET
                onBackgroundChanged(); dlg.dismiss()
            })
        }
        val buttons = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(MaterialButton(activity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = activity.getString(R.string.gk_choose_photo)
            setOnClickListener { dlg.dismiss(); pickPhoto() }
        })
        buttons.addView(MaterialButton(activity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = activity.getString(R.string.gk_no_background)
            setOnClickListener { backgrounds.kind = BackgroundStore.Kind.NONE; onBackgroundChanged(); dlg.dismiss() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(10) })
        col.addView(buttons, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        // --- blur / dim ----------------------------------------------------------------------------------------
        if (Build.VERSION.SDK_INT >= 31) {
            col.addView(header(activity.getString(R.string.gk_blur)))
            col.addView(Slider(activity).apply {
                valueFrom = 0f; valueTo = 25f; stepSize = 1f; value = backgrounds.blur.toFloat()
                addOnChangeListener { _, v, fromUser -> if (fromUser) { backgrounds.blur = v.toInt(); onBackgroundChanged() } }
            })
        }
        col.addView(header(activity.getString(R.string.gk_dim)))
        col.addView(Slider(activity).apply {
            valueFrom = 0f; valueTo = 80f; stepSize = 5f; value = (backgrounds.dim / 5 * 5).toFloat()
            addOnChangeListener { _, v, fromUser -> if (fromUser) { backgrounds.dim = v.toInt(); onBackgroundChanged() } }
        })
        dlg.show()
    }
}
