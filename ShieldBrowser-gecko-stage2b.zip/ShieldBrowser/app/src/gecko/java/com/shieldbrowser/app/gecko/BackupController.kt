package com.shieldbrowser.app.gecko

import android.net.Uri
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.crypto.HybridPrivateKey
import com.shieldbrowser.app.crypto.PassphraseWrap
import com.shieldbrowser.app.security.AppLock
import com.shieldbrowser.app.security.VaultBackup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.GeneralSecurityException

/**
 * Encrypted backup / restore flows (Storage Access Framework, so no storage permission):
 *  - backup file  (.shieldvault)  sealed to the device's X25519+ML-KEM-768 key;
 *  - recovery key (.shieldkey)    the private key under an Argon2id passphrase: keep it OFF the device, it is the only
 *    way to restore on another phone. Each sensitive step asks for the device lock first when one is set.
 * Must be created while the activity is being constructed (it registers activity-result launchers).
 */
class BackupController(
    private val activity: AppCompatActivity,
    private val container: () -> AppContainer,
    private val say: (String) -> Unit
) {
    private var pendingPassphrase: CharArray? = null
    private var restoreBlob: ByteArray? = null

    private val createBackup = activity.registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { if (it != null) writeBackup(it) }
    private val pickBackup = activity.registerForActivityResult(ActivityResultContracts.OpenDocument()) { if (it != null) readBackup(it) }
    private val createKey = activity.registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { if (it != null) writeRecovery(it) else wipePass() }
    private val pickKey = activity.registerForActivityResult(ActivityResultContracts.OpenDocument()) { if (it != null) readRecovery(it) else restoreBlob = null }

    private fun str(id: Int) = activity.getString(id)

    private fun gate(then: () -> Unit) {
        if (AppLock.available(activity)) AppLock.authenticate(activity, str(R.string.pay_auth_title)) { if (it) then() } else then()
    }

    fun exportBackup() = gate { createBackup.launch("shieldbrowser.shieldvault") }
    fun restoreBackup() = gate { pickBackup.launch(arrayOf("*/*")) }
    fun exportRecoveryKey() = gate { askNewPassphrase { pass -> pendingPassphrase = pass; createKey.launch("shieldbrowser-recovery.shieldkey") } }

    // ------------------------------------------------------------------------------------------ export
    private fun writeBackup(uri: Uri) {
        activity.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val bytes = VaultBackup.export(container())
                    activity.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(bytes) }
                    true
                } catch (_: Throwable) { false }
            }
            say(str(if (ok) R.string.bk_export_done else R.string.bk_export_failed))
        }
    }

    private fun writeRecovery(uri: Uri) {
        val pass = pendingPassphrase ?: return
        pendingPassphrase = null
        activity.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val bytes = container().keyVault.exportRecoveryKey(pass)
                    activity.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(bytes) }
                    true
                } catch (_: Throwable) { false } finally { pass.fill('\u0000') }
            }
            say(str(if (ok) R.string.bk_key_saved else R.string.bk_export_failed))
        }
    }

    private fun wipePass() { pendingPassphrase?.fill('\u0000'); pendingPassphrase = null }

    // ------------------------------------------------------------------------------------------ restore
    private fun readBytes(uri: Uri): ByteArray? = try {
        activity.contentResolver.openInputStream(uri)?.use { s -> s.readBytes().takeIf { it.size <= 32 shl 20 } }
    } catch (_: Throwable) { null }

    private fun readBackup(uri: Uri) {
        activity.lifecycleScope.launch {
            val blob = withContext(Dispatchers.IO) { readBytes(uri) }
            if (blob == null) { say(str(R.string.bk_restore_failed)); return@launch }
            restoreBlob = blob
            tryRestore(null)
        }
    }

    private suspend fun tryRestore(priv: HybridPrivateKey?) {
        val blob = restoreBlob ?: return
        try {
            val r = withContext(Dispatchers.IO) { VaultBackup.restore(container(), blob, priv) }
            restoreBlob = null
            say(activity.getString(R.string.bk_restore_done, r.bookmarks, r.settings))
        } catch (_: GeneralSecurityException) {
            if (priv == null) askUseRecoveryKey() else { restoreBlob = null; say(str(R.string.bk_restore_failed)) }
        } catch (_: Throwable) { restoreBlob = null; say(str(R.string.bk_restore_failed)) }
    }

    private fun askUseRecoveryKey() {
        MaterialAlertDialogBuilder(activity).setTitle(R.string.bk_need_recovery_title).setMessage(R.string.bk_need_recovery_msg)
            .setPositiveButton(R.string.bk_pick_key) { _, _ -> pickKey.launch(arrayOf("*/*")) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> restoreBlob = null }
            .setOnCancelListener { restoreBlob = null }.show()
    }

    private fun readRecovery(uri: Uri) {
        activity.lifecycleScope.launch {
            val wrapped = withContext(Dispatchers.IO) { readBytes(uri) }
            if (wrapped == null) { restoreBlob = null; say(str(R.string.bk_restore_failed)); return@launch }
            askPassphrase { pass ->
                activity.lifecycleScope.launch {
                    val priv = withContext(Dispatchers.IO) {
                        try { HybridPrivateKey.decode(PassphraseWrap.unwrap(wrapped, pass)) } catch (_: Throwable) { null } finally { pass.fill('\u0000') }
                    }
                    if (priv == null) { restoreBlob = null; say(str(R.string.bk_restore_failed)) }
                    else try { tryRestore(priv) } finally { priv.wipe() }
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------ passphrase dialogs
    private fun field(hint: Int) = EditText(activity).apply {
        this.hint = str(hint)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun column(vararg v: EditText) = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(48, 16, 48, 0)
        v.forEach { addView(it) }
    }

    private fun askPassphrase(done: (CharArray) -> Unit) {
        val p = field(R.string.bk_pass_hint)
        MaterialAlertDialogBuilder(activity).setTitle(R.string.bk_pass_title).setView(column(p))
            .setPositiveButton(android.R.string.ok) { _, _ -> done(p.text.toString().toCharArray()) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> restoreBlob = null }.show()
    }

    private fun askNewPassphrase(done: (CharArray) -> Unit) {
        val p1 = field(R.string.bk_pass_hint); val p2 = field(R.string.bk_pass_confirm_hint)
        MaterialAlertDialogBuilder(activity).setTitle(R.string.bk_pass_title).setView(column(p1, p2))
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val a = p1.text.toString(); val b = p2.text.toString()
                when {
                    a.length < 10 -> say(str(R.string.bk_pass_short))
                    a != b -> say(str(R.string.bk_pass_mismatch))
                    else -> done(a.toCharArray())
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }
}
