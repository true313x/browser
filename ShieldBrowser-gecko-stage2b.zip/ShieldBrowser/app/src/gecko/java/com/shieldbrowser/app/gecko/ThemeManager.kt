package com.shieldbrowser.app.gecko

import android.app.Activity
import android.content.SharedPreferences
import com.google.android.material.color.DynamicColors
import com.shieldbrowser.app.R

/** Material 3 theming: one of six accent palettes, or the system (wallpaper) colours on Android 12+. */
object ThemeManager {
    class Accent(val id: String, val nameRes: Int, val styleRes: Int, val swatch: Int)

    const val KEY_ACCENT = "gecko_accent"
    const val KEY_DYNAMIC = "gecko_dynamic"

    val accents: List<Accent> = listOf(
        Accent("ocean", R.string.gk_accent_ocean, R.style.ThemeOverlay_Shield_Ocean, 0xFF0B6B9A.toInt()),
        Accent("emerald", R.string.gk_accent_emerald, R.style.ThemeOverlay_Shield_Emerald, 0xFF1B6C3B.toInt()),
        Accent("sunset", R.string.gk_accent_sunset, R.style.ThemeOverlay_Shield_Sunset, 0xFF9A4521.toInt()),
        Accent("violet", R.string.gk_accent_violet, R.style.ThemeOverlay_Shield_Violet, 0xFF6750A4.toInt()),
        Accent("rose", R.string.gk_accent_rose, R.style.ThemeOverlay_Shield_Rose, 0xFFA03C62.toInt()),
        Accent("graphite", R.string.gk_accent_graphite, R.style.ThemeOverlay_Shield_Graphite, 0xFF4A5F6D.toInt())
    )

    fun accent(prefs: SharedPreferences): Accent = accents.firstOrNull { it.id == prefs.getString(KEY_ACCENT, null) } ?: accents[0]

    /** Call in onCreate() BEFORE setContentView(). */
    fun apply(activity: Activity, prefs: SharedPreferences) {
        activity.theme.applyStyle(accent(prefs).styleRes, true)
        if (prefs.getBoolean(KEY_DYNAMIC, false)) DynamicColors.applyToActivityIfAvailable(activity)
    }
}
