package com.shieldbrowser.app.gecko

import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.security.AppLock
import com.shieldbrowser.app.security.TamperMonitor
import com.shieldbrowser.app.security.TamperPolicy
import com.shieldbrowser.app.ui.fitScreen

/** App lock, tamper response, payment protection, encrypted backup and a device check, in one sheet. */
class SecurityCenterSheet(
    private val activity: AppCompatActivity,
    private val container: AppContainer,
    private val backup: BackupController,
    private val onClosed: () -> Unit,
    private val openSecurePayment: () -> Unit
) {
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), activity.resources.displayMetrics).toInt()
    private fun s(id: Int) = activity.getString(id)

    private fun title(text: String) = TextView(activity).apply {
        this.text = text
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun body(text: String) = TextView(activity).apply {
        this.text = text
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyMedium)
    }

    /** Click listener (not OnCheckedChange): fires for touch, keyboard and TalkBack, and not for programmatic changes. */
    private fun switchRow(label: String, checked: Boolean, onChange: (MaterialSwitch, Boolean) -> Unit) = MaterialSwitch(activity).apply {
        text = label
        isChecked = checked
        setOnClickListener { onChange(this, isChecked) }
    }

    private fun button(label: Int, outlined: Boolean = true, onClick: () -> Unit) =
        MaterialButton(activity, null, if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle else com.google.android.material.R.attr.borderlessButtonStyle).apply {
            text = s(label); setOnClickListener { onClick() }
        }

    fun show() {
        val sec = container.security
        val dlg = BottomSheetDialog(activity)
        val col = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(28)) }
        dlg.setContentView(ScrollView(activity).apply { addView(col) })
        dlg.fitScreen()
        dlg.setOnDismissListener { onClosed() }
        col.addView(TextView(activity).apply { text = s(R.string.sc_title); setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_HeadlineSmall) })

        // ---- status ---------------------------------------------------------------------------------------------
        col.addView(title(s(R.string.sc_status)))
        col.addView(body(s(if (container.db.isEncrypted) R.string.sc_db_enc else R.string.sc_db_plain)))
        if (container.db.recoveredFromKeyLoss) col.addView(body(s(R.string.sc_db_recovered)))
        try { col.addView(body(activity.getString(R.string.sc_fingerprint, container.keyVault.hybridPublicKey().fingerprint()))) } catch (_: Throwable) { }
        col.addView(body(s(R.string.sc_tls_note)))

        // ---- app lock ---------------------------------------------------------------------------------------------
        col.addView(title(s(R.string.sc_app_lock)))
        col.addView(switchRow(s(R.string.sc_app_lock_switch), sec.appLock) { sw, on ->
            if (on && !AppLock.available(activity)) { sw.isChecked = false; android.widget.Toast.makeText(activity, R.string.sc_lock_unavailable, android.widget.Toast.LENGTH_LONG).show(); return@switchRow }
            AppLock.authenticate(activity, s(R.string.lock_auth_title)) { ok ->
                if (ok) { sec.appLock = on; if (on) container.appLock.markUnlocked() } else sw.isChecked = !on
            }
        })
        val timeouts = listOf(0 to R.string.sc_t_now, 60 to R.string.sc_t_1m, 300 to R.string.sc_t_5m, 900 to R.string.sc_t_15m)
        val tg = ChipGroup(activity).apply { isSingleSelection = true; isSelectionRequired = true }
        for ((seconds, label) in timeouts) tg.addView(Chip(activity).apply {
            text = s(label); isCheckable = true; isChecked = sec.appLockTimeoutSec == seconds
            setOnClickListener { sec.appLockTimeoutSec = seconds }
        })
        col.addView(tg)

        // ---- tamper response ----------------------------------------------------------------------------------------
        col.addView(title(s(R.string.sc_tamper)))
        val note = body("")
        fun describe(p: TamperPolicy) = s(when (p) {
            TamperPolicy.OFF -> R.string.sc_tamper_off_desc
            TamperPolicy.WARN -> R.string.sc_tamper_warn_desc
            TamperPolicy.SEAL_LOCK -> R.string.sc_tamper_seal_desc
            TamperPolicy.SEAL_WIPE -> R.string.sc_tamper_wipe_desc
        })
        val pg = ChipGroup(activity).apply { isSingleSelection = true; isSelectionRequired = true }
        val policies = listOf(TamperPolicy.OFF to R.string.sc_tamper_off, TamperPolicy.WARN to R.string.sc_tamper_warn,
            TamperPolicy.SEAL_LOCK to R.string.sc_tamper_seal, TamperPolicy.SEAL_WIPE to R.string.sc_tamper_wipe)
        val chips = HashMap<TamperPolicy, Chip>()
        for ((p, label) in policies) {
            val chip = Chip(activity).apply { text = s(label); isCheckable = true; isChecked = sec.tamperPolicy == p }
            chip.setOnClickListener {
                if (p == TamperPolicy.SEAL_WIPE) {
                    MaterialAlertDialogBuilder(activity).setTitle(R.string.sc_tamper_wipe).setMessage(R.string.sc_tamper_wipe_confirm)
                        .setPositiveButton(android.R.string.ok) { _, _ -> sec.tamperPolicy = p; note.text = describe(p) }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> chips[sec.tamperPolicy]?.isChecked = true }.show()
                } else { sec.tamperPolicy = p; note.text = describe(p) }
            }
            chips[p] = chip; pg.addView(chip)
        }
        note.text = describe(sec.tamperPolicy)
        col.addView(pg); col.addView(note)
        col.addView(button(R.string.sc_scan_now) { dlg.dismiss(); scanNow() })

        // ---- payments -----------------------------------------------------------------------------------------------
        col.addView(title(s(R.string.sc_pay)))
        col.addView(body(s(R.string.sc_pay_desc)))
        col.addView(button(R.string.pay_menu_secure_tab, outlined = false) { dlg.dismiss(); openSecurePayment() })
        col.addView(switchRow(s(R.string.sc_pay_auth), sec.payRequireAuth) { _, on -> sec.payRequireAuth = on })
        col.addView(switchRow(s(R.string.sc_pay_paranoid), sec.payParanoid) { _, on -> sec.payParanoid = on })
        col.addView(body(s(R.string.sc_pay_paranoid_desc)))

        // ---- backup -------------------------------------------------------------------------------------------------
        col.addView(title(s(R.string.sc_backup)))
        col.addView(body(s(R.string.sc_backup_desc)))
        col.addView(button(R.string.sc_backup_export) { dlg.dismiss(); backup.exportBackup() })
        col.addView(button(R.string.sc_backup_restore) { dlg.dismiss(); backup.restoreBackup() })
        col.addView(button(R.string.sc_recovery_export) { dlg.dismiss(); backup.exportRecoveryKey() })
        if (com.shieldbrowser.app.BuildConfig.DEBUG) {
            // The real checks only run in release builds; this lets you test Sealed Mode on a debug build.
            col.addView(MaterialButton(activity, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = "Simulate tamper (debug build only)"
                setOnClickListener {
                    dlg.dismiss()
                    com.shieldbrowser.app.security.SealedMode.trigger(
                        activity, setOf(com.shieldbrowser.app.security.TamperSignal.DEBUGGER), container.security.tamperPolicy,
                        GeckoBrowserActivity::class.java.name
                    )
                }
            })
        }
        dlg.show()
    }

    private fun scanNow() {
        TamperMonitor.scanAsync(activity, forPayment = true) { found ->
            val msg = if (found.isEmpty()) s(R.string.sc_env_ok)
            else found.joinToString("\n") { "• " + SecurityText.signal(activity, it) + (if (it.severity == com.shieldbrowser.app.security.Severity.CRITICAL) "  (!)" else "") }
            MaterialAlertDialogBuilder(activity).setTitle(R.string.sc_env_title).setMessage(msg).setPositiveButton(android.R.string.ok, null).show()
        }
    }
}
