package com.shieldbrowser.app.gecko

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowManager

/**
 * Window/view hardening while a payment page is showing (or the app lock is on):
 *  - FLAG_SECURE: no screenshots, no screen recording / casting of this window, blank recents thumbnail;
 *  - filterTouchesWhenObscured + hide-overlay-windows: other apps' overlays cannot sit on top of the page or swallow taps;
 *  - autofill off and accessibility-data-sensitive: third-party autofill / accessibility tools do not get the card fields.
 * Nothing here can stop a keylogging keyboard or an attacker with root; those are reported by TamperMonitor instead.
 */
class PaymentShield(private val activity: Activity, private val geckoView: View) {
    private var secureWindow = false
    private var paymentActive = false

    fun apply(payment: Boolean, appLockOn: Boolean) {
        val wantSecure = payment || appLockOn
        if (wantSecure != secureWindow) {
            secureWindow = wantSecure
            if (wantSecure) activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        if (payment == paymentActive) return
        paymentActive = payment
        geckoView.filterTouchesWhenObscured = payment
        geckoView.importantForAutofill =
            if (payment) View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS else View.IMPORTANT_FOR_AUTOFILL_AUTO
        if (Build.VERSION.SDK_INT >= 34) {
            geckoView.accessibilityDataSensitive =
                if (payment) View.ACCESSIBILITY_DATA_SENSITIVE_YES else View.ACCESSIBILITY_DATA_SENSITIVE_AUTO
        }
        if (Build.VERSION.SDK_INT >= 31) {
            try { activity.window.setHideOverlayWindows(payment) } catch (_: Exception) { /* permission missing on this ROM */ }
        }
    }
}
