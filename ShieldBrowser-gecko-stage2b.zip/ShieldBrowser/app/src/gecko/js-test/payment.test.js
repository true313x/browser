// Run: node app/src/gecko/js-test/payment.test.js   (no dependencies)
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const ext = path.join(__dirname, '..', 'assets', 'shield-ext');

// ---- stubs for the WebExtension API used at load time
const listeners = { before: null, msg: null };
global.browser = {
  runtime: {
    getURL: (p) => path.join(ext, p),
    onMessage: { addListener: (f) => { listeners.msg = f; } },
    sendNativeMessage: async () => ({ payParanoid: true })
  },
  webRequest: { onBeforeRequest: { addListener: (f) => { listeners.before = f; } } },
  tabs: { onRemoved: { addListener: () => {} } }
};
global.fetch = async (p) => ({ text: async () => fs.readFileSync(p, 'utf8') });
global.setInterval = () => 0;                      // no timers in the test

const pay = require(path.join(ext, 'payment.js'));
const bg = require(path.join(ext, 'background.js'));

(async () => {
  await bg.ready;
  const { regDomain, looksLikePayUrl, paranoidBlock } = pay;

  // regDomain mirrors DomainUtils
  assert.strictEqual(regDomain('pay.shop.example.co.uk'), 'example.co.uk');
  assert.strictEqual(regDomain('js.stripe.com'), 'stripe.com');
  assert.strictEqual(regDomain('203.0.113.9'), '203.0.113.9');

  // payment URL detection
  assert(looksLikePayUrl('https://shop.example.com/checkout/step2', bg.PSP));
  assert(looksLikePayUrl('https://js.stripe.com/v3/', bg.PSP));
  assert(!looksLikePayUrl('https://example.com/blog/how-to-pay-less', bg.PSP));
  assert(bg.PSP.has('stripe.com') && bg.PSP.has('paytabs.com'));

  // paranoid decisions on a checkout page https://shop.example.com/checkout
  const d = (type, url, doc) => ({
    type, url, documentUrl: doc || 'https://shop.example.com/checkout', frameAncestors: []
  });
  const block = (x) => paranoidBlock(x, bg.PSP, bg.ESSENTIAL, bg.inSet);
  assert.strictEqual(block(d('script', 'https://shop.example.com/app.js')), false, 'first party');
  assert.strictEqual(block(d('script', 'https://cdn.shop.example.com/app.js')), false, 'same site');
  assert.strictEqual(block(d('script', 'https://js.stripe.com/v3/')), false, 'payment provider');
  assert.strictEqual(block(d('xmlhttprequest', 'https://api.stripe.com/v1/tokens')), false, 'provider subdomain');
  assert.strictEqual(block(d('script', 'https://evil-skimmer.xyz/m.js')), true, 'unknown third-party script');
  assert.strictEqual(block(d('xmlhttprequest', 'https://collect.evil.net/p')), true, 'exfiltration XHR');
  assert.strictEqual(block(d('beacon', 'https://collect.evil.net/p')), true, 'beacon');
  assert.strictEqual(block(d('websocket', 'wss://collect.evil.net/ws')), true, 'websocket');
  assert.strictEqual(block(d('image', 'https://img.evil.net/a.png')), false, 'images are not touched');
  assert.strictEqual(block(d('stylesheet', 'https://fonts.evil.net/a.css')), false);
  // 3-D Secure frame of a bank loading its own script: allowed because it is the frame's own site
  const bank = { type: 'script', url: 'https://acs.bank.com/3ds.js', documentUrl: 'https://acs.bank.com/challenge',
    frameAncestors: [{ url: 'https://shop.example.com/checkout' }] };
  assert.strictEqual(block(bank), false, 'iframe own scripts');

  // end to end through the registered listener
  bg.cfg.payParanoid = false;
  let r = await listeners.before({ type: 'script', url: 'https://evil-skimmer.xyz/m.js', documentUrl: 'https://shop.example.com/checkout', tabId: 1, frameAncestors: [] });
  assert.deepStrictEqual(r, {}, 'off by default');
  bg.cfg.payParanoid = true;
  r = await listeners.before({ type: 'script', url: 'https://evil-skimmer.xyz/m.js', documentUrl: 'https://shop.example.com/checkout', tabId: 1, frameAncestors: [] });
  assert.deepStrictEqual(r, { cancel: true }, 'blocked on a checkout URL');
  r = await listeners.before({ type: 'script', url: 'https://evil-skimmer.xyz/m.js', documentUrl: 'https://news.example.com/article', tabId: 2, frameAncestors: [] });
  assert.deepStrictEqual(r, {}, 'ordinary page is not affected');
  listeners.msg({ t: 'pay' }, { tab: { id: 2 } });                     // card field detected on tab 2
  r = await listeners.before({ type: 'script', url: 'https://evil-skimmer.xyz/m.js', documentUrl: 'https://news.example.com/article', tabId: 2, frameAncestors: [] });
  assert.deepStrictEqual(r, { cancel: true }, 'blocked after card field detection');
  console.log('payment.test.js: all assertions passed');
})().catch((e) => { console.error(e); process.exit(1); });
