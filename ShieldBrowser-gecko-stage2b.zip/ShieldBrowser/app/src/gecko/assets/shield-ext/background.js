/* Shield Blocker — built-in WebExtension of ShieldBrowser (GeckoView build).
 * Complements Gecko's own Enhanced Tracking Protection (STRICT) with the app's bundled domain list.
 * Everything is local: no network access, no telemetry. (The bundled list is small on purpose: the heavy lifting is
 * done by Gecko's engine-level lists; for filter-list/cosmetic blocking install uBlock Origin from Settings.)
 *   - sub-resources (never the top-level page) whose host or any parent domain is listed are cancelled;
 *   - hosts in lists/essential.txt are never blocked (CDNs, captchas, sign-in);
 *   - the number of blocked requests is reported to the app (at most once per 1.5 s). */
'use strict';

if (typeof module !== 'undefined') { var { paranoidBlock, looksLikePayUrl } = require('./payment.js'); }   // Node (tests); in the browser payment.js is loaded first

const BLOCK = new Set();
const ESSENTIAL = new Set();
const PSP = new Set();
const cfg = { payParanoid: false };            // pulled from the app (encrypted settings) every 30 s
const payTabs = new Map();                      // tabId -> expiry: card fields were seen on that tab
let blocked = 0;
let reported = 0;

function parseList(text, into) {
  for (const line of text.split('\n')) {
    const t = line.trim();
    if (!t || t[0] === '#') continue;
    const d = t.split(/\s+/)[0].toLowerCase();
    if (/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d)) into.add(d);
  }
}

async function load(path, into) {
  try {
    const r = await fetch(browser.runtime.getURL(path));
    parseList(await r.text(), into);
  } catch (e) { /* a missing list must never break browsing */ }
}

const ready = Promise.all([load('lists/domains.txt', BLOCK), load('lists/essential.txt', ESSENTIAL), load('lists/psp.txt', PSP)]);

function inSet(set, host) {
  let h = host;
  while (h.indexOf('.') !== -1) {
    if (set.has(h)) return true;
    h = h.slice(h.indexOf('.') + 1);
  }
  return false;
}

function shouldBlock(host) {
  if (!host) return false;
  const h = host.toLowerCase();
  if (inSet(ESSENTIAL, h)) return false;
  return inSet(BLOCK, h);
}

browser.webRequest.onBeforeRequest.addListener(async (details) => {
  if (details.type === 'main_frame') return {};          // top-level navigations are the app's decision
  await ready;                                           // never let a request through just because lists are still loading
  let host = '';
  try { host = new URL(details.url).hostname; } catch (e) { return {}; }
  if (shouldBlock(host)) { blocked++; return { cancel: true }; }
  // Paranoid checkout (opt-in): on payment pages nothing but first-party / payment-provider / essential code may run or
  // send data. This is what stops "Magecart" card skimmers that load a script from, or POST to, an unknown third party.
  if (cfg.payParanoid && isPayTab(details) && paranoidBlock(details, PSP, ESSENTIAL, inSet)) { blocked++; return { cancel: true }; }
  return {};
}, { urls: ['<all_urls>'] }, ['blocking']);

function isPayTab(details) {
  const exp = payTabs.get(details.tabId);
  if (exp && exp > Date.now()) return true;
  const anc = details.frameAncestors;
  const topUrl = (anc && anc.length ? anc[anc.length - 1].url : (details.documentUrl || details.originUrl)) || '';
  return looksLikePayUrl(topUrl, PSP);           // path/provider heuristics catch the scripts that load BEFORE any card field exists
}

browser.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.t === 'pay' && sender && sender.tab && typeof sender.tab.id === 'number') {
    payTabs.set(sender.tab.id, Date.now() + 30 * 60 * 1000);
  }
});
if (browser.tabs && browser.tabs.onRemoved) browser.tabs.onRemoved.addListener((id) => payTabs.delete(id));   // not available in every GeckoView version

async function refreshConfig() {
  try {
    const r = await browser.runtime.sendNativeMessage('shield', { t: 'config' });
    if (r && typeof r === 'object') cfg.payParanoid = !!r.payParanoid;
  } catch (e) { /* keep the last value */ }
}
refreshConfig();
setInterval(refreshConfig, 30000);

setInterval(() => {
  if (blocked !== reported) {
    reported = blocked;
    try { browser.runtime.sendNativeMessage('shield', { t: 'stats', blocked }); } catch (e) {}
  }
}, 1500);

if (typeof module !== 'undefined') module.exports = { parseList, inSet, shouldBlock, BLOCK, ESSENTIAL, PSP, ready, cfg, payTabs, isPayTab };
