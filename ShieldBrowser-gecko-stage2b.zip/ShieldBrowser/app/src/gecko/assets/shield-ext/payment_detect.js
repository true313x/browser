/* Shield Blocker - card-field detector (content script, all frames).
 * Reports ONLY that a card form exists on this page. It never reads, copies or sends any field VALUE, label text or
 * page content. The app uses the signal to switch on payment protections (screenshot block, overlay block, no history).
 */
(function () {
  'use strict';
  if (window.__shieldPayDetect) return;
  window.__shieldPayDetect = true;

  const NAME = /(card.?(num|no)|cc.?(num|no)|cardnumber|cvv|cvc|csc|security.?code|card.?holder|exp(iry|iration)?.?(date|month|year))/i;

  function isCardField(el) {
    const ac = (el.getAttribute('autocomplete') || '').toLowerCase();
    if (ac.indexOf('cc-') === 0) return true;
    const hay = [el.name, el.id, el.getAttribute('aria-label'), el.placeholder].filter(Boolean).join(' ');
    return hay.length < 200 && NAME.test(hay);
  }

  function scan() {
    const inputs = document.querySelectorAll('input');
    for (let i = 0; i < inputs.length && i < 400; i++) if (isCardField(inputs[i])) return true;
    return false;
  }

  let reported = false;
  // The app attaches its per-tab receiver asynchronously after the extension is installed; a page that finished loading
  // earlier would lose the signal, so a rejected delivery is retried a few times.
  function sendToApp(attempt) {
    let p;
    try { p = browser.runtime.sendNativeMessage('shieldpage', { t: 'pay', top: window === window.top }); } catch (e) { return; }
    if (p && p.catch) p.catch(function () { if (attempt < 6) setTimeout(function () { sendToApp(attempt + 1); }, 1000 * (attempt + 1)); });
  }
  function report() {
    if (reported) return;
    reported = true;
    sendToApp(0);                                                                                       // to the app (this tab)
    try { browser.runtime.sendMessage({ t: 'pay' }).catch(function () {}); } catch (e) {}              // to the background script
  }

  if (scan()) { report(); return; }
  let timer = null;
  const mo = new MutationObserver(function () {
    if (timer) return;
    timer = setTimeout(function () { timer = null; if (scan()) { mo.disconnect(); report(); } }, 400);
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(function () { mo.disconnect(); }, 90000);       // stop watching long-lived pages
})();
