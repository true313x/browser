/* Shield Blocker - payment helpers shared by the background script (and unit-tested in Node).
 * Mirrors the Kotlin side (DomainUtils.registrableDomain, PaymentGuard.looksLikePaymentUrl). Pure functions, no browser API. */
'use strict';

const MULTI_SUFFIX = new Set([
  'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'me.uk', 'ltd.uk', 'plc.uk',
  'com.au', 'net.au', 'org.au', 'edu.au', 'gov.au',
  'co.nz', 'org.nz', 'net.nz', 'govt.nz',
  'co.jp', 'ne.jp', 'or.jp', 'ac.jp', 'go.jp',
  'co.kr', 'or.kr', 'go.kr', 'co.in', 'net.in', 'org.in', 'gov.in', 'ac.in',
  'com.br', 'net.br', 'org.br', 'gov.br', 'com.mx', 'com.ar', 'com.co', 'com.pe', 'com.ve',
  'com.tr', 'org.tr', 'gov.tr', 'com.sa', 'gov.sa', 'com.eg', 'gov.eg', 'com.ae', 'co.il',
  'com.cn', 'net.cn', 'org.cn', 'gov.cn', 'com.hk', 'com.tw', 'com.sg', 'com.my', 'com.ph', 'co.id', 'co.th',
  'co.za', 'org.za', 'com.ng', 'com.pk', 'com.bd', 'com.vn', 'com.ua', 'com.pl', 'com.ru'
]);

const PATH_WORDS = new Set([
  'checkout', 'payment', 'payments', 'pay', 'billing', '3ds', '3dsecure', '3d-secure', 'secure-payment',
  'payment-method', 'paymentmethod', 'cashier'
]);

/** Request types a card skimmer uses to load code or send data out. Images/styles/fonts/frames are left alone. */
const PARANOID_TYPES = new Set(['script', 'xmlhttprequest', 'ping', 'beacon', 'websocket', 'object']);

function regDomain(host) {
  if (!host) return '';
  if (/^[0-9.]+$/.test(host) || host.indexOf(':') !== -1) return host;       // IPv4 / IPv6 literal
  const labels = host.toLowerCase().split('.');
  if (labels.length <= 2) return labels.join('.');
  const last2 = labels.slice(-2).join('.');
  return MULTI_SUFFIX.has(last2) ? labels.slice(-3).join('.') : last2;
}

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (e) { return ''; }
}

function looksLikePayUrl(url, psp) {
  let u;
  try { u = new URL(url); } catch (e) { return false; }
  if (psp && psp.has(regDomain(u.hostname))) return true;
  return u.pathname.toLowerCase().split('/').some((seg) => PATH_WORDS.has(seg));
}

/**
 * Paranoid checkout decision for one request on a payment page.
 * Returns true when it must be cancelled: a script/XHR/beacon/WebSocket to a site that is neither the requesting
 * document's site, the top page's site, a payment provider, nor a never-block (CDN/captcha/sign-in) host.
 */
function paranoidBlock(details, psp, essential, inSet) {
  if (!PARANOID_TYPES.has(details.type)) return false;
  const host = hostOf(details.url);
  if (!host) return false;
  const reg = regDomain(host);
  const doc = regDomain(hostOf(details.documentUrl || details.originUrl || ''));
  const anc = details.frameAncestors;
  const top = regDomain(hostOf((anc && anc.length ? anc[anc.length - 1].url : (details.documentUrl || details.originUrl)) || ''));
  if (reg === doc || reg === top) return false;
  if (psp.has(reg) || inSet(psp, host)) return false;
  if (inSet(essential, host)) return false;
  return true;
}

if (typeof module !== 'undefined') module.exports = { regDomain, hostOf, looksLikePayUrl, paranoidBlock, PARANOID_TYPES, MULTI_SUFFIX };
