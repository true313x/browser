package com.shieldbrowser.app.security

import android.content.Context
import android.os.Process
import com.shieldbrowser.app.privacy.ClipboardGuard
import com.shieldbrowser.app.storage.KeystoreKey
import java.io.File
import java.security.SecureRandom

/** File-level cleanup used by Sealed Mode. Runs while no engine process is alive, so nothing re-creates the data. */
object SealedWiper {
    /** Same alias as SecurePrefs.KEY_ALIAS (private there). */
    private const val SETTINGS_KEY_ALIAS = "shield_settings_key_v1"
    private val rng = SecureRandom()

    /** Idempotent: safe to call from the sealed process and again from the next start. */
    @Synchronized
    fun wipeIfPending(context: Context) {
        if (!SealedMode.isSealed(context) || SealedMode.wiped(context)) return
        killOtherProcesses(context)
        wipeSessionData(context)
        if (SealedMode.wipeAllRequested(context)) wipeEverything(context)
        SealedMode.markWiped(context)
    }

    /** Kills every process of this app except the sealed one (and this one), then waits briefly for them to disappear. */
    fun killOtherProcesses(context: Context) {
        val me = Process.myPid()
        fun others() = ProcessUtil.appProcesses(context).filter { (pid, name) -> pid != me && !name.endsWith(":sealed") }
        others().keys.forEach { try { Process.killProcess(it) } catch (_: Exception) { } }
        var waited = 0
        while (others().isNotEmpty() && waited < 2000) { Thread.sleep(100); waited += 100 }
    }

    /** Everything a stolen session could use: logins, cookies, storage, caches, uploads, clipboard. */
    fun wipeSessionData(context: Context) {
        context.filesDir.listFiles()?.forEach {
            val n = it.name.lowercase()
            if (it.isDirectory && (n == "mozilla" || n.startsWith("gecko") || n.startsWith("xulstore"))) it.deleteRecursively()
        }
        File(context.dataDir, "app_webview").deleteRecursively()
        context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        context.getExternalFilesDir(null)?.let { dir -> File(dir, "tmp").deleteRecursively() }
        ClipboardGuard.clear(context)
    }

    /** Panic wipe: databases, settings, vault keys and the Keystore keys that protect them. */
    fun wipeEverything(context: Context) {
        wipeSessionData(context)
        for (name in context.databaseList()) context.deleteDatabase(name)
        context.filesDir.listFiles()?.forEach { shredRecursively(it) }
        KeystoreKey.delete(KeyVault.KEY_ALIAS)
        KeystoreKey.delete(SETTINGS_KEY_ALIAS)
    }

    fun shredRecursively(f: File) {
        if (f.isDirectory) { f.listFiles()?.forEach { shredRecursively(it) }; f.delete(); return }
        try {
            val len = f.length()
            if (len in 1..(8L shl 20)) f.outputStream().use { o ->
                val buf = ByteArray(8192); var left = len
                while (left > 0) { rng.nextBytes(buf); val n = minOf(left, buf.size.toLong()).toInt(); o.write(buf, 0, n); left -= n }
                o.flush()
            }
        } catch (_: Exception) { }
        f.delete()
    }
}
