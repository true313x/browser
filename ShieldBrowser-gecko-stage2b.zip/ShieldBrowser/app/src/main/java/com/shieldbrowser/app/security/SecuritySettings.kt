package com.shieldbrowser.app.security

import android.content.SharedPreferences

/** What happens when the tamper monitor sees a CRITICAL signal (debugger, hooking framework, repackaged APK ...). */
enum class TamperPolicy(val id: String) {
    /** No automatic reaction (findings are still shown in Security Center). */
    OFF("off"),
    /** Warn and refuse the Secure Payment tab; never seals. */
    WARN("warn"),
    /** Seal: kill every process, delete web sessions, restart in an empty secrets-free process (default). */
    SEAL_LOCK("seal"),
    /** Seal and also destroy the local database, settings and keys (panic wipe). Cannot be undone. */
    SEAL_WIPE("wipe");

    companion object { fun of(id: String?): TamperPolicy = values().firstOrNull { it.id == id } ?: SEAL_LOCK }
}

/** Security Center options, stored in the encrypted settings file. */
class SecuritySettings(private val prefs: SharedPreferences) {
    companion object {
        const val APP_LOCK = "sec_app_lock"
        const val APP_LOCK_TIMEOUT = "sec_app_lock_timeout_s"
        const val TAMPER_POLICY = "sec_tamper_policy"
        const val PAY_PARANOID = "sec_pay_paranoid"
        const val PAY_REQUIRE_AUTH = "sec_pay_require_auth"
        const val PAY_TIMEOUT = "sec_pay_timeout_s"

        /** Added to K.INTERNAL_KEYS: changing these must not rebuild the blocker or refresh WebView tabs. */
        val KEYS: Set<String> = setOf(APP_LOCK, APP_LOCK_TIMEOUT, TAMPER_POLICY, PAY_PARANOID, PAY_REQUIRE_AUTH, PAY_TIMEOUT)
    }

    var appLock: Boolean
        get() = prefs.getBoolean(APP_LOCK, false)
        set(v) { prefs.edit().putBoolean(APP_LOCK, v).apply() }

    /** Seconds in the background before the lock asks again (0 = every time). */
    var appLockTimeoutSec: Int
        get() = prefs.getInt(APP_LOCK_TIMEOUT, 60)
        set(v) { prefs.edit().putInt(APP_LOCK_TIMEOUT, v).apply() }

    var tamperPolicy: TamperPolicy
        get() = TamperPolicy.of(prefs.getString(TAMPER_POLICY, null))
        set(v) { prefs.edit().putString(TAMPER_POLICY, v.id).apply() }

    /** Paranoid checkout: on payment pages third-party scripts/XHR/beacons outside the PSP allow-list are blocked. */
    var payParanoid: Boolean
        get() = prefs.getBoolean(PAY_PARANOID, false)
        set(v) { prefs.edit().putBoolean(PAY_PARANOID, v).apply() }

    var payRequireAuth: Boolean
        get() = prefs.getBoolean(PAY_REQUIRE_AUTH, true)
        set(v) { prefs.edit().putBoolean(PAY_REQUIRE_AUTH, v).apply() }

    /** Idle seconds after which a Secure Payment tab is closed and wiped. */
    var payTimeoutSec: Int
        get() = prefs.getInt(PAY_TIMEOUT, 300)
        set(v) { prefs.edit().putInt(PAY_TIMEOUT, v).apply() }
}
