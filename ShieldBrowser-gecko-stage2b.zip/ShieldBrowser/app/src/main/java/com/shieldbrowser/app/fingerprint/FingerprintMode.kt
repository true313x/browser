package com.shieldbrowser.app.fingerprint

/**
 * OFF      no JS-level fingerprint mitigation.
 * STANDARD per-site randomised canvas/audio/WebGL read-back noise, generic WebGL renderer string,
 *          reduced hardwareConcurrency/deviceMemory, no Battery API.
 * STRICT   + coarse screen size, English language list, 0.1 ms timer resolution, no Network Information API.
 * MAXIMUM  + UTC timezone reports, font-probe & speech-voice limiting, fewer WebGL extensions.
 * None of these makes the browser "unique-free": they REDUCE the fingerprinting surface.
 */
enum class FingerprintMode(val level: Int) {
    OFF(0), STANDARD(1), STRICT(2), MAXIMUM(3);

    companion object {
        fun fromLevel(level: Int): FingerprintMode = values().firstOrNull { it.level == level } ?: STANDARD
    }
}
