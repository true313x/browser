package com.shieldbrowser.app.settings

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import com.shieldbrowser.app.R
import com.shieldbrowser.app.ui.centerContent
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.ActivityListBinding
import com.shieldbrowser.app.ui.Entry
import com.shieldbrowser.app.ui.EntryAdapter
import com.shieldbrowser.app.ui.SiteSettingsSheet

/** Lists every site that has custom rules; tap to edit, ⋮ to reset. */
class SiteSettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivityListBinding
    private lateinit var adapter: EntryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.tabs, b.search, b.recycler.parent as? View)
        b.toolbar.title = getString(R.string.site_settings)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.menu_site_settings)
        b.toolbar.setOnMenuItemClickListener { container.siteSettings.clearAll(); load(); true }
        adapter = EntryAdapter(
            onClick = { e -> SiteSettingsSheet(this, e.key) { load() }.show() },
            onMore = { e, anchor ->
                android.widget.PopupMenu(this, anchor).apply {
                    menu.add(R.string.reset)
                    setOnMenuItemClickListener { container.siteSettings.reset(e.key); load(); true }
                }.show()
            }
        )
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.search.addTextChangedListener { load() }
        load()
    }

    private fun load() {
        val q = b.search.text.toString().trim().lowercase()
        val items = container.siteSettings.all().filter { q.isEmpty() || it.key.contains(q) }.map { s ->
            val flags = ArrayList<String>()
            if (!s.shield) flags.add(getString(R.string.shield_off))
            if (s.js != Perm.INHERIT) flags.add("JS")
            if (s.cookies != SiteCookies.INHERIT) flags.add(getString(R.string.perm_cookies))
            if (s.popups != Perm.INHERIT) flags.add(getString(R.string.perm_popups))
            if (listOf(s.camera, s.mic, s.location, s.notifications, s.clipboard, s.downloads, s.autoplay).any { it != Perm.INHERIT }) flags.add(getString(R.string.permissions))
            if (s.fingerprint >= 0) flags.add(getString(R.string.perm_fingerprint))
            Entry(0, s.key, flags.joinToString(" · "), s.key)
        }
        adapter.submit(items)
        b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
