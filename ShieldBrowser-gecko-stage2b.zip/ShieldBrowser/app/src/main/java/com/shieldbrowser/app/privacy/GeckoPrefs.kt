package com.shieldbrowser.app.privacy

/** How aggressively the Gecko engine is hardened. Each level includes everything of the levels below it. */
enum class ProtectionLevel(val id: String) {
    /** Strong defaults that almost never break a site. */
    STANDARD("standard"),
    /** Recommended: removes most fingerprinting surfaces; a few sites may need a different level. */
    STRICT("strict"),
    /** Tor-style resistance (resistFingerprinting, no WebGL, no WebRTC, no disk cache). Expect broken sites. */
    MAXIMUM("maximum");

    companion object {
        fun of(id: String?): ProtectionLevel = values().firstOrNull { it.id == id } ?: STRICT
    }
}

/**
 * One Gecko preference. [value] (Boolean, Int or String) is applied when the chosen level is >= [minLevel];
 * below that, [offValue] is written so that LOWERING the level really undoes it (Gecko keeps user-branch values).
 * Pure Kotlin so the table can be unit-tested on the JVM.
 */
data class GeckoPref(
    val name: String,
    val value: Any,
    val offValue: Any?,
    val minLevel: ProtectionLevel,
    val why: String
)

object GeckoPrefs {
    private val S = ProtectionLevel.STANDARD
    private val T = ProtectionLevel.STRICT
    private val M = ProtectionLevel.MAXIMUM

    val all: List<GeckoPref> = listOf(
        // ---- STANDARD: tracking, referrers, leaks, post-quantum TLS ------------------------------------------
        GeckoPref("privacy.trackingprotection.fingerprinting.enabled", true, null, S, "block known fingerprinting scripts"),
        GeckoPref("privacy.trackingprotection.cryptomining.enabled", true, null, S, "block cryptominers"),
        GeckoPref("privacy.trackingprotection.emailtracking.enabled", true, null, S, "block email tracking pixels"),
        GeckoPref("privacy.query_stripping.enabled", true, null, S, "strip tracking parameters from URLs"),
        GeckoPref("privacy.query_stripping.enabled.pbmode", true, null, S, "same, in private tabs"),
        GeckoPref("privacy.bounceTrackingProtection.mode", 1, null, S, "purge state of bounce trackers"),
        GeckoPref("privacy.globalprivacycontrol.enabled", true, null, S, "send Global Privacy Control"),
        GeckoPref("privacy.globalprivacycontrol.pbmode.enabled", true, null, S, "GPC in private tabs"),
        GeckoPref("privacy.globalprivacycontrol.functionality.enabled", true, null, S, "expose navigator.globalPrivacyControl"),
        GeckoPref("privacy.fingerprintingProtection", true, null, S, "baseline fingerprinting protection"),
        GeckoPref("privacy.fingerprintingProtection.pbmode", true, null, S, "baseline fingerprinting protection, private tabs"),
        GeckoPref("network.http.referer.XOriginTrimmingPolicy", 2, null, S, "cross-origin referrers carry the origin only"),
        GeckoPref("network.dns.disablePrefetch", true, null, S, "no speculative DNS lookups"),
        GeckoPref("network.prefetch-next", false, null, S, "no link prefetching"),
        GeckoPref("network.predictor.enabled", false, null, S, "no speculative connections"),
        GeckoPref("network.http.speculative-parallel-limit", 0, null, S, "no speculative connections"),
        GeckoPref("media.peerconnection.ice.default_address_only", true, null, S, "WebRTC does not reveal local IP addresses"),
        GeckoPref("security.tls.enable_kyber", true, null, S, "hybrid post-quantum key exchange (X25519+ML-KEM) in TLS"),
        GeckoPref("network.http.http3.enable_kyber", true, null, S, "hybrid post-quantum key exchange in HTTP/3"),

        // payment safety: nothing about cards, addresses or logins is ever stored or auto-filled by the engine
        GeckoPref("extensions.formautofill.creditCards.enabled", false, null, S, "never store or auto-fill payment cards"),
        GeckoPref("extensions.formautofill.addresses.enabled", false, null, S, "never store or auto-fill addresses"),
        GeckoPref("signon.rememberSignons", false, null, S, "never offer to save passwords"),
        GeckoPref("signon.autofillForms", false, null, S, "never auto-fill login forms"),
        GeckoPref("browser.formfill.enable", false, null, S, "never remember form entries"),
        GeckoPref("security.pki.crlite_mode", 2, null, S, "enforce CRLite certificate revocation checks (no stale revoked certificates)"),
        GeckoPref("security.mixed_content.block_active_content", true, null, S, "block scripts/frames loaded over http on https pages"),
        GeckoPref("dom.security.https_only_mode_send_http_background_request", false, null, S, "no plain-http probe request when upgrading to https"),
        GeckoPref("browser.send_pings", false, null, S, "no <a ping> tracking beacons"),

        // ---- STRICT: fewer fingerprinting surfaces -----------------------------------------------------------
        GeckoPref("privacy.fingerprintingProtection.overrides", "+AllTargets", "", T, "enable every fingerprinting-protection target"),
        GeckoPref("device.sensors.enabled", false, true, T, "no motion/orientation sensors for web pages"),
        GeckoPref("dom.gamepad.enabled", false, true, T, "no gamepad enumeration"),
        GeckoPref("dom.vr.enabled", false, true, T, "no WebVR/XR device enumeration"),
        GeckoPref("security.ssl.require_safe_negotiation", true, false, T, "refuse TLS servers without secure renegotiation (RFC 5746)"),

        // ---- MAXIMUM: Tor-style ------------------------------------------------------------------------------
        GeckoPref("privacy.resistFingerprinting", true, false, M, "resist fingerprinting (UTC time zone, spoofed screen/CPU, rounded timers)"),
        GeckoPref("webgl.disabled", true, false, M, "no WebGL (GPU/driver fingerprint)"),
        GeckoPref("media.peerconnection.enabled", false, true, M, "no WebRTC at all (also stops IP leaks)"),
        GeckoPref("browser.cache.disk.enable", false, true, M, "no on-disk HTTP cache")
    )

    /** Name/value pairs to write for [level]: active prefs get [GeckoPref.value], higher-level ones are switched back off. */
    fun plan(level: ProtectionLevel): List<Pair<String, Any>> {
        val out = ArrayList<Pair<String, Any>>()
        for (p in all) {
            if (level.ordinal >= p.minLevel.ordinal) out.add(p.name to p.value)
            else p.offValue?.let { out.add(p.name to it) }
        }
        return out
    }
}
