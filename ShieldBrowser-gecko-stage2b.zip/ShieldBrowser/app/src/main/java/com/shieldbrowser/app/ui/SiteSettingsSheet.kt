package com.shieldbrowser.app.ui

import android.content.Context
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.ScrollView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.ItemStatRowBinding
import com.shieldbrowser.app.settings.Perm
import com.shieldbrowser.app.settings.SiteCookies
import com.shieldbrowser.app.settings.SiteSettings

/** Per-site rules: shield, JavaScript, cookies, popups, permissions, downloads, autoplay, fingerprint mode. */
class SiteSettingsSheet(private val ctx: Context, private val host: String, private val onDismiss: (() -> Unit)? = null) {
    private class Row(
        val label: Int,
        val options: List<Pair<Int, Int>>,           // value → string res
        val get: (SiteSettings) -> Int,
        val set: (SiteSettings, Int) -> SiteSettings,
        val note: Int? = null
    )

    private val d = Perm.INHERIT to R.string.opt_default
    private val ask = Perm.ASK to R.string.opt_ask
    private val allow = Perm.ALLOW to R.string.opt_allow
    private val block = Perm.BLOCK to R.string.opt_block

    private val rows = listOf(
        Row(R.string.perm_shield, listOf(1 to R.string.on, 0 to R.string.off), { if (it.shield) 1 else 0 }, { s, v -> s.copy(shield = v == 1) }),
        Row(R.string.perm_js, listOf(d, allow, ask, block), { it.js }, { s, v -> s.copy(js = v) }),
        Row(R.string.perm_cookies, listOf(
            SiteCookies.INHERIT to R.string.opt_default, SiteCookies.ALLOW_ALL to R.string.opt_cookies_all,
            SiteCookies.BLOCK_THIRD_PARTY to R.string.opt_cookies_third, SiteCookies.BLOCK_ALL to R.string.opt_cookies_block_all,
            SiteCookies.SESSION_ONLY to R.string.opt_cookies_session
        ), { it.cookies }, { s, v -> s.copy(cookies = v) }, R.string.note_cookies),
        Row(R.string.perm_popups, listOf(d, allow, block), { it.popups }, { s, v -> s.copy(popups = v) }),
        Row(R.string.perm_camera, listOf(d, ask, allow, block), { it.camera }, { s, v -> s.copy(camera = v) }),
        Row(R.string.perm_microphone, listOf(d, ask, allow, block), { it.mic }, { s, v -> s.copy(mic = v) }),
        Row(R.string.perm_location, listOf(d, ask, allow, block), { it.location }, { s, v -> s.copy(location = v) }),
        Row(R.string.perm_notifications, listOf(d, ask, allow, block), { it.notifications }, { s, v -> s.copy(notifications = v) }, R.string.note_notifications),
        Row(R.string.perm_clipboard, listOf(d, allow, block), { it.clipboard }, { s, v -> s.copy(clipboard = v) }),
        Row(R.string.perm_downloads, listOf(d, ask, allow, block), { it.downloads }, { s, v -> s.copy(downloads = v) }),
        Row(R.string.perm_autoplay, listOf(d, allow, block), { it.autoplay }, { s, v -> s.copy(autoplay = v) }),
        Row(R.string.perm_fingerprint, listOf(
            -1 to R.string.opt_default, 0 to R.string.fp_off, 1 to R.string.fp_standard, 2 to R.string.fp_strict, 3 to R.string.fp_maximum
        ), { it.fingerprint }, { s, v -> s.copy(fingerprint = v) })
    )

    fun show() {
        val c = ctx.container
        val dlg = BottomSheetDialog(ctx)
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 40, 48, 40) }
        val title = android.widget.TextView(ctx).apply {
            text = ctx.getString(R.string.site_settings_for, host)
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleLarge)
        }
        col.addView(title)
        val bindings = rows.map { r ->
            val rb = ItemStatRowBinding.inflate(LayoutInflater.from(ctx), col, false)
            rb.rowIcon.visibility = android.view.View.GONE
            rb.rowLabel.text = ctx.getString(r.label)
            col.addView(rb.root)
            if (r.note != null) {
                col.addView(android.widget.TextView(ctx).apply {
                    setText(r.note)
                    textSize = 12f
                    setTextColor(ctx.getColor(R.color.status_off))
                    setPadding(0, 0, 0, 12)
                })
            }
            r to rb
        }
        fun refresh() {
            val s = c.siteSettings.get(host)
            bindings.forEach { (r, rb) ->
                val v = r.get(s)
                rb.rowValue.text = ctx.getString(r.options.firstOrNull { it.first == v }?.second ?: R.string.opt_default)
            }
        }
        bindings.forEach { (r, rb) ->
            rb.root.setOnClickListener {
                val names = r.options.map { ctx.getString(it.second) }.toTypedArray()
                val cur = r.options.indexOfFirst { it.first == r.get(c.siteSettings.get(host)) }.coerceAtLeast(0)
                MaterialAlertDialogBuilder(ctx).setTitle(r.label)
                    .setSingleChoiceItems(names, cur) { dialog, which ->
                        c.siteSettings.update(host) { s -> r.set(s, r.options[which].first) }
                        refresh(); dialog.dismiss()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        }
        refresh()
        dlg.setContentView(ScrollView(ctx).apply { addView(col) })
        dlg.fitScreen()
        dlg.setOnDismissListener { onDismiss?.invoke() }
        dlg.show()
    }
}
