package com.shieldbrowser.app.browser

import com.shieldbrowser.app.R
import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.privacy.EventType
import org.json.JSONObject

/**
 * Receives batched, de-duplicated reports from shield_core.js ("type:kind" → count).
 * The page can only INFLATE counters (it cannot read anything back or trigger actions), so a hostile page gains nothing.
 */
class ScriptBridge(private val tabs: TabManager) {
    fun handle(tab: BrowserTab, data: String?) {
        if (data.isNullOrEmpty() || data.length > 4096) return
        val obj = try { JSONObject(data) } catch (_: Exception) { return }
        val host = tab.pageHost.orEmpty()
        val url = tab.data.url
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val n = obj.optInt(key, 1).coerceIn(1, 50)
            val type = key.substringBefore(':')
            val kind = key.substringAfter(':', "").take(40)
            when (type) {
                "fp" -> tabs.record(tab, BlockEvent(EventType.FINGERPRINT, host, url, detail = kind), 1)
                "cookie" -> tabs.record(tab, BlockEvent(EventType.COOKIE, host, url, detail = "document.cookie write blocked"), n)
                "clip" -> tabs.record(tab, BlockEvent(EventType.CLIPBOARD, host, url, detail = kind), n)
                "webrtc" -> tabs.record(tab, BlockEvent(EventType.WEBRTC, host, url, detail = kind), 1)
                "track" -> tabs.record(tab, BlockEvent(EventType.BLOCKED_REQUEST, host, url, BlockCategory.TRACKING, "hyperlink-auditing ping removed", true), n)
                "miner" -> {
                    tabs.record(tab, BlockEvent(EventType.MINING, host, url, BlockCategory.CRYPTOMINING, kind), 1)
                    tabs.host?.toast(tabs.uiContext().getString(R.string.mining_blocked))
                }
            }
        }
    }
}
