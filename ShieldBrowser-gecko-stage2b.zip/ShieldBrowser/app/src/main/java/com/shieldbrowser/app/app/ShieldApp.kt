package com.shieldbrowser.app.app

import android.app.Application
import android.content.Context
import com.shieldbrowser.app.security.ProcessUtil
import com.shieldbrowser.app.security.SealedMode

class ShieldApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        // GeckoView runs its content / GPU / socket / extension processes INSIDE this package (":tab", ":gpu", ...) and Android
        // creates the Application object in EVERY process of the app. Only the main process may open the encrypted
        // settings file, the database and the tabs: several writers on settings.enc corrupt it, and each child process
        // would re-run the start-up cleanup (cookie wipe, clipboard clear) and restore tabs.
        if (ProcessUtil.processName(this) != packageName) return
        // Sealed (see SealedMode): no container, no engine, no keys in this process until the owner unlocks.
        if (SealedMode.isSealed(this)) return
        container = AppContainer(this)
        container.onAppStart()
    }

    /** False in child processes and while sealed. */
    val hasContainer: Boolean get() = ::container.isInitialized
}

val Context.container: AppContainer get() = (applicationContext as ShieldApp).container
