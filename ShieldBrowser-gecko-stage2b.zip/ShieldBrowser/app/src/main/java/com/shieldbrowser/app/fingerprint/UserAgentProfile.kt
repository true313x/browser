package com.shieldbrowser.app.fingerprint

/**
 * A browsing identity. IMPORTANT (also shown in the UI): changing the User-Agent string and a few
 * navigator.* values does NOT change your real device identity; servers can still see your IP, TLS
 * fingerprint, HTTP/2 settings, Client-Hint headers, screen/GPU behaviour, etc.
 *
 * [userAgent] == null means "keep the system WebView default".
 */
data class UserAgentProfile(
    val id: String,
    val name: String,
    val userAgent: String?,
    val platform: String,
    val vendor: String,
    val mobile: Boolean,
    val maxTouchPoints: Int,
    /** Whether navigator.userAgentData (UA Client Hints JS API) should remain exposed. */
    val exposesUserAgentData: Boolean,
    val builtIn: Boolean = true
) {
    val isDefault: Boolean get() = userAgent == null
    val appVersion: String? get() = userAgent?.removePrefix("Mozilla/")
}

object UserAgentProfiles {
    const val DEFAULT_ID = "default"
    const val CUSTOM_ID = "custom"

    val builtIns: List<UserAgentProfile> = listOf(
        UserAgentProfile(DEFAULT_ID, "Android (system WebView default)", null, "Linux armv8l", "Google Inc.", true, 5, true),
        UserAgentProfile("android", "Android (Chrome)",
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
            "Linux armv8l", "Google Inc.", true, 5, true),
        UserAgentProfile("iphone", "iPhone (Safari)",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            "iPhone", "Apple Computer, Inc.", true, 5, false),
        UserAgentProfile("ipad", "iPad (Safari)",
            "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            "iPad", "Apple Computer, Inc.", true, 5, false),
        UserAgentProfile("windows", "Windows PC (Chrome)",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Win32", "Google Inc.", false, 0, true),
        UserAgentProfile("mac", "Mac (Safari)",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
            "MacIntel", "Apple Computer, Inc.", false, 0, false),
        UserAgentProfile("linux", "Linux (Firefox)",
            "Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
            "Linux x86_64", "", false, 0, false),
        UserAgentProfile("huawei", "Huawei",
            "Mozilla/5.0 (Linux; Android 12; HarmonyOS; ELS-NX9; HMSCore 6.13.0.302) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.196 HuaweiBrowser/15.0.4.312 Mobile Safari/537.36",
            "Linux armv8l", "Google Inc.", true, 5, false),
        UserAgentProfile("xiaomi", "Xiaomi",
            "Mozilla/5.0 (Linux; U; Android 13; en-us; 2201116SG Build/TKQ1.221114.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.5615.136 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.4.1",
            "Linux armv8l", "Google Inc.", true, 5, false),
        UserAgentProfile("samsung", "Samsung",
            "Mozilla/5.0 (Linux; Android 14; SAMSUNG SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.0.0 Mobile Safari/537.36",
            "Linux armv8l", "Google Inc.", true, 5, false),
        UserAgentProfile("realme", "Realme",
            "Mozilla/5.0 (Linux; Android 13; RMX3511) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "Linux armv8l", "Google Inc.", true, 5, true),
        UserAgentProfile("vivo", "Vivo",
            "Mozilla/5.0 (Linux; Android 13; V2250) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 VivoBrowser/15.1.2.0",
            "Linux armv8l", "Google Inc.", true, 5, false),
        UserAgentProfile("generic_mobile", "Generic mobile",
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
            "Linux armv8l", "Google Inc.", true, 5, true),
        UserAgentProfile("generic_desktop", "Generic desktop",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Linux x86_64", "Google Inc.", false, 0, true)
    )

    fun find(id: String): UserAgentProfile? = builtIns.firstOrNull { it.id == id }

    /** Custom profile from user-entered strings; blank UA → null (invalid). Control chars are stripped. */
    fun custom(name: String, userAgent: String, platform: String, mobile: Boolean): UserAgentProfile? {
        val ua = userAgent.filter { it.code in 32..126 }.trim()
        if (ua.length < 8) return null
        val plat = platform.filter { it.code in 32..126 }.trim().ifEmpty { if (mobile) "Linux armv8l" else "Win32" }
        return UserAgentProfile(
            CUSTOM_ID, name.trim().ifEmpty { "Custom" }, ua, plat,
            if (ua.contains("Firefox")) "" else "Google Inc.", mobile, if (mobile) 5 else 0,
            exposesUserAgentData = false, builtIn = false
        )
    }
}
