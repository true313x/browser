package com.shieldbrowser.app.crypto

import java.io.IOException
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Public-key encryption ("seal") to a [HybridPublicKey]: fresh hybrid KEM per message, then AES-256-GCM.
 * Anyone can seal; only the holder of the matching [HybridPrivateKey] can open. Used for backups / exports so
 * they stay confidential even against a future quantum attacker who recorded them today.
 *
 * Layout (Wire fields): header("SHVL"+version) | ephX25519 | mlkemCt | nonce(12) | AES-GCM(ciphertext+tag)
 */
object SealedBox {
    private val HEADER = byteArrayOf('S'.code.toByte(), 'H'.code.toByte(), 'V'.code.toByte(), 'L'.code.toByte(), 1)
    private const val NONCE_LEN = 12

    fun seal(
        to: HybridPublicKey, plaintext: ByteArray, context: ByteArray = ByteArray(0), random: SecureRandom = SecureRandom()
    ): ByteArray {
        val (enc, key) = HybridKem.encapsulate(to, random)
        try {
            val nonce = ByteArray(NONCE_LEN).also { random.nextBytes(it) }
            val ct = aes(Cipher.ENCRYPT_MODE, key, nonce, HEADER + context, plaintext)
            return Wire.pack(HEADER, enc.ephX25519, enc.mlkemCt, nonce, ct)
        } finally {
            key.fill(0)
        }
    }

    /** @throws GeneralSecurityException for a wrong key, a modified blob or a different [context]. */
    fun open(priv: HybridPrivateKey, blob: ByteArray, context: ByteArray = ByteArray(0)): ByteArray {
        val f = try { Wire.unpack(blob, 5) } catch (e: IOException) { throw GeneralSecurityException("malformed", e) }
        if (!f[0].contentEquals(HEADER)) throw GeneralSecurityException("not a sealed box / unsupported version")
        if (f[3].size != NONCE_LEN) throw GeneralSecurityException("bad nonce")
        // BC reports a malformed or hostile encapsulation (e.g. an all-zero X25519 result) with unchecked exceptions
        val key = try { HybridKem.decapsulate(priv, HybridKem.Encapsulation(f[1], f[2])) }
        catch (e: GeneralSecurityException) { throw e }
        catch (e: RuntimeException) { throw GeneralSecurityException("invalid encapsulation", e) }
        try {
            return aes(Cipher.DECRYPT_MODE, key, f[3], HEADER + context, f[4])
        } finally {
            key.fill(0)
        }
    }

    private fun aes(mode: Int, key: ByteArray, nonce: ByteArray, aad: ByteArray, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(aad)
        return c.doFinal(data)
    }
}
