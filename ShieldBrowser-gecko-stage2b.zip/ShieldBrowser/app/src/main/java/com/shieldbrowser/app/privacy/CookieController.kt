package com.shieldbrowser.app.privacy

import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.browser.BrowserTab
import com.shieldbrowser.app.browser.ProfileManager
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.settings.CookieMode
import com.shieldbrowser.app.settings.SiteCookies
import com.shieldbrowser.app.settings.SiteSettingsRepository

/**
 * Cookie policy on top of android.webkit.CookieManager.
 *
 * WHAT IS REAL: third-party cookie blocking (per WebView, per site), clear-all, clear-site-data, delete on exit,
 *               session-only sites (cleared on exit).
 * BEST EFFORT:  per-site "block ALL cookies" — WebView has no per-site cookie switch, so cookies set by such a
 *               site are expired right after each page load (and document.cookie is made inert by the injected
 *               script). Requests during that page load may still carry cookies.
 */
class CookieController(
    private val settings: BrowserSettings,
    private val sites: SiteSettingsRepository,
    private val profiles: ProfileManager
) {
    /** Effective cookie policy for a host. */
    fun effective(host: String?): Int {
        val s = sites.get(host).cookies
        if (s != SiteCookies.INHERIT) return s
        return when (settings.cookieMode) {
            CookieMode.ALLOW_ALL -> SiteCookies.ALLOW_ALL
            CookieMode.BLOCK_THIRD_PARTY -> SiteCookies.BLOCK_THIRD_PARTY
            CookieMode.BLOCK_ALL -> SiteCookies.BLOCK_ALL
        }
    }

    fun configure(tab: BrowserTab, wv: WebView) {
        val cm = profiles.cookieManagerFor(tab.profileName)
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(wv, false)
    }

    fun applyForHost(tab: BrowserTab, wv: WebView, host: String?) {
        val cm = profiles.cookieManagerFor(tab.profileName)
        val mode = effective(host)
        cm.setAcceptThirdPartyCookies(wv, mode == SiteCookies.ALLOW_ALL || mode == SiteCookies.SESSION_ONLY)
    }

    /** Called after each page load: expires cookies of sites whose policy is "block all". Returns removed count. */
    fun afterPageFinished(tab: BrowserTab, url: String): Int {
        val host = DomainUtils.hostOf(url) ?: return 0
        val cm = profiles.cookieManagerFor(tab.profileName)
        var removed = 0
        if (effective(host) == SiteCookies.BLOCK_ALL) {
            removed = expire(cm, url, host)
            if (removed > 0) tab.stats.record(BlockEvent(EventType.COOKIE, host, url, detail = "removed $removed cookie(s)"), removed)
        }
        cm.flush()
        return removed
    }

    fun expire(cm: CookieManager, url: String, host: String): Int {
        val raw = cm.getCookie(url) ?: return 0
        val names = raw.split(';').map { it.trim().substringBefore('=') }.filter { it.isNotEmpty() }
        val reg = DomainUtils.registrableDomain(host)
        for (n in names) for (d in listOf(null, host, ".$host", reg, ".$reg")) {
            val dom = if (d == null) "" else "; Domain=$d"
            cm.setCookie(url, "$n=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/$dom")
        }
        cm.flush()
        return names.size
    }

    fun clearAll() {
        profiles.allCookieManagers().forEach { cm -> cm.removeAllCookies(null); cm.flush() }
        try { WebStorage.getInstance().deleteAllData() } catch (_: Throwable) {}
    }

    fun clearSiteData(host: String) {
        val reg = DomainUtils.registrableDomain(host)
        profiles.allCookieManagers().forEach { cm ->
            for (h in listOf(host, reg, "www.$reg")) for (scheme in listOf("https", "http")) expire(cm, "$scheme://$h/", h)
        }
        try {
            val ws = WebStorage.getInstance()
            for (h in listOf(host, reg, "www.$reg")) { ws.deleteOrigin("https://$h"); ws.deleteOrigin("http://$h") }
        } catch (_: Throwable) {}
    }

    /** Called on exit: wipes "session only" sites, or everything if "delete cookies on exit" is on. */
    fun exitCleanup() {
        if (settings.clearCookiesOnExit) { clearAll(); return }
        sites.all().filter { it.cookies == SiteCookies.SESSION_ONLY }.forEach { clearSiteData(it.key) }
    }

    fun flush() { try { CookieManager.getInstance().flush() } catch (_: Throwable) {} }
}
