package com.shieldbrowser.app.security

import android.content.Context
import android.os.Build
import android.os.SystemClock
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Biometric / device-credential gate. UI-level lock (it does not wrap encryption keys); see SECURITY.md.
 * State is process-wide so rotating or recreating an activity does not lock again.
 */
class AppLock(private val settings: SecuritySettings) {
    companion object {
        @Volatile private var locked = true
        @Volatile private var backgroundAt = 0L

        /** API 28-29 cannot combine BIOMETRIC_STRONG with DEVICE_CREDENTIAL; API 30+ can. */
        fun authenticators(): Int =
            if (Build.VERSION.SDK_INT >= 30) BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
            else BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

        fun available(context: Context): Boolean =
            BiometricManager.from(context).canAuthenticate(authenticators()) == BiometricManager.BIOMETRIC_SUCCESS

        /** Shows the system prompt; [onResult] true only on success. Can be used for any sensitive action. */
        fun authenticate(activity: FragmentActivity, title: String, onResult: (Boolean) -> Unit) {
            if (!available(activity)) { onResult(false); return }
            val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onResult(true) }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onResult(false) }
            })
            prompt.authenticate(
                BiometricPrompt.PromptInfo.Builder().setTitle(title).setAllowedAuthenticators(authenticators()).build()
            )
        }
    }

    val enabled: Boolean get() = settings.appLock

    fun needsUnlock(): Boolean = enabled && locked

    fun onBackground() { backgroundAt = SystemClock.elapsedRealtime() }

    /** Call from onStart: decides whether the time away was long enough to lock again. */
    fun onForeground() {
        if (!enabled) { locked = false; return }
        if (backgroundAt != 0L && SystemClock.elapsedRealtime() - backgroundAt >= settings.appLockTimeoutSec * 1000L) locked = true
    }

    fun markUnlocked() { locked = false }
}
