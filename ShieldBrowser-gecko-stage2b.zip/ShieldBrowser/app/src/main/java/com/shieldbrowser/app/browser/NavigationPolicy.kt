package com.shieldbrowser.app.browser

import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.privacy.EventType
import com.shieldbrowser.app.privacy.UrlCleaner
import com.shieldbrowser.app.settings.BrowserSettings

/** Applies URL hygiene (redirect-wrapper unwrapping, tracking-parameter cleaning, HTTPS upgrade) to top-level navigations. */
class NavigationPolicy(private val settings: BrowserSettings) {
    data class Outcome(val url: String, val events: List<BlockEvent>)

    fun apply(tab: BrowserTab, url: String): Outcome {
        val scheme = DomainUtils.schemeOf(url)
        if (scheme != "http" && scheme != "https") return Outcome(url, emptyList())
        var target = url
        val ev = ArrayList<BlockEvent>()
        if (settings.unwrapRedirects) {
            UrlCleaner.unwrapRedirect(target)?.let { inner ->
                ev.add(BlockEvent(EventType.TRACKING_PARAM, DomainUtils.hostOf(target).orEmpty(), target, detail = "redirect wrapper removed"))
                target = inner
            }
        }
        if (settings.urlCleaning) {
            val r = UrlCleaner.cleanDetailed(target)
            if (r.removed.isNotEmpty()) {
                ev.add(BlockEvent(EventType.TRACKING_PARAM, DomainUtils.hostOf(target).orEmpty(), target, detail = r.removed.joinToString(",")))
                target = r.url
            }
        }
        if (settings.httpsOnly && target.startsWith("http://", ignoreCase = true)) {
            val host = DomainUtils.hostOf(target).orEmpty()
            if (host.isNotEmpty() && !DomainUtils.isLocalHost(host) && host !in tab.httpAllowed) {
                target = "https://" + target.substring(7)
                tab.upgradedHost = host
            }
        }
        return Outcome(target, ev)
    }
}
