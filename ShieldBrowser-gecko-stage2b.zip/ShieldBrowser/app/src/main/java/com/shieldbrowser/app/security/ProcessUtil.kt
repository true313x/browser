package com.shieldbrowser.app.security

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File

object ProcessUtil {
    fun processName(context: Context): String {
        if (Build.VERSION.SDK_INT >= 28) return Application.getProcessName()
        return try { File("/proc/self/cmdline").readText().trim { it == '\u0000' || it.isWhitespace() } }
        catch (_: Exception) { context.packageName }
    }

    /** Live processes of this app: pid -> process name. */
    fun appProcesses(context: Context): Map<Int, String> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return emptyMap()
        val out = HashMap<Int, String>()
        am.runningAppProcesses?.forEach { if (it.processName.startsWith(context.packageName)) out[it.pid] = it.processName }
        return out
    }
}
