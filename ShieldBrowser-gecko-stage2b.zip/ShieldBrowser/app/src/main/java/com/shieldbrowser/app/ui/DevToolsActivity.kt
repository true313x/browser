package com.shieldbrowser.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewCompat
import com.google.android.material.chip.Chip
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.browser.BrowserTab
import com.shieldbrowser.app.databinding.ActivityDevtoolsBinding
import com.shieldbrowser.app.privacy.EventType

/** Hidden-by-default developer privacy tools (enable in Settings > Advanced). Read-only views of the active tab. */
class DevToolsActivity : AppCompatActivity() {
    private lateinit var b: ActivityDevtoolsBinding
    private val sections = listOf(
        R.string.dev_requests, R.string.dev_blocked, R.string.dev_cookies, R.string.dev_storage, R.string.dev_permissions,
        R.string.dev_ua, R.string.dev_headers, R.string.dev_console, R.string.dev_page
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDevtoolsBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.devChips.parent as? View, b.devText.parent as? View)
        b.toolbar.setNavigationOnClickListener { finish() }
        sections.forEachIndexed { i, res ->
            val chip = Chip(this).apply { text = getString(res); isCheckable = true; id = 1000 + i }
            b.devChips.addView(chip)
        }
        b.devChips.setOnCheckedStateChangeListener { _, ids -> ids.firstOrNull()?.let { render(it - 1000) } }
        b.devChips.check(1000)
        render(0)
    }

    private fun render(i: Int) {
        val tab = container.tabs.active()
        b.devText.text = if (tab == null) getString(R.string.nothing_here) else build(i, tab)
    }

    private fun build(i: Int, tab: BrowserTab): String {
        val c = container
        val wv = tab.webView
        return when (i) {
            0 -> if (!c.settings.developerMode) "-" else tab.requestLog.joinToString("\n").ifEmpty { "(none yet — reload the page)" }
            1 -> tab.stats.events { it.type == EventType.BLOCKED_REQUEST }.joinToString("\n") {
                "${it.category?.key ?: "?"}  ${it.url.take(140)}\n    rule=${it.detail ?: "-"} thirdParty=${it.thirdParty}"
            }.ifEmpty { "(none)" }
            2 -> {
                val cm = c.profiles.cookieManagerFor(tab.profileName)
                val raw = cm.getCookie(tab.data.url).orEmpty()
                raw.split(';').map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n") { kv ->
                    val n = kv.substringBefore('='); val v = kv.substringAfter('=', "")
                    "$n = ${v.take(40)}${if (v.length > 40) "…" else ""}"
                }.ifEmpty { "(no cookies for this URL)" }
            }
            3 -> buildString {
                appendLine("profile: ${tab.profileName ?: "Default"}")
                appendLine("private: ${tab.isPrivate}  isolated profile support: ${c.profiles.supported}")
                appendLine("domStorage: ${wv?.settings?.domStorageEnabled}")
                appendLine("cacheMode: ${wv?.settings?.cacheMode}")
                append("NOTE: Android WebView cannot enumerate localStorage/IndexedDB from Java.")
            }
            4 -> buildString {
                appendLine(c.siteSettings.get(tab.pageHost).toString())
                listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION).forEach {
                    appendLine("${it.substringAfterLast('.')}: " + if (checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED) "granted" else "not granted")
                }
            }
            5 -> "profile: ${c.settings.userAgentProfile().id}\nUA: ${wv?.settings?.userAgentString}"
            6 -> tab.lastHeaders.entries.joinToString("\n") { "${it.key}: ${it.value}" }.ifEmpty { "(none)" }
            7 -> tab.console.joinToString("\n").ifEmpty { "(empty)" }
            else -> buildString {
                appendLine("url: ${tab.data.url}")
                appendLine("title: ${tab.data.title}")
                appendLine("host: ${tab.pageHost}")
                appendLine("security: ${tab.security}  internal: ${tab.internalPage}")
                val pk = try { WebViewCompat.getCurrentWebViewPackage(this@DevToolsActivity) } catch (_: Throwable) { null }
                appendLine("webview: ${pk?.packageName} ${pk?.versionName}")
                appendLine("doc-start script: ${container.tabs.configurator.docStartSupported}")
                appendLine("rules: ${c.ruleEngine.domainRuleCount()} domains, ${c.ruleEngine.patternRuleCount()} patterns")
            }
        }
    }
}
