package com.shieldbrowser.app.crypto

import org.bouncycastle.crypto.generators.Argon2BytesGenerator
import org.bouncycastle.crypto.params.Argon2Parameters
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Protects a secret (the exported hybrid private key = "recovery key") with a passphrase:
 * Argon2id (memory-hard) -> AES-256-GCM. Cost parameters are stored in the blob so they can be raised later.
 * Layout: "SHPW" | ver(1) | memKiB(4) | iterations(4) | parallelism(1) | salt(16) | nonce(12) | ciphertext+tag
 */
object PassphraseWrap {
    private val MAGIC = byteArrayOf('S'.code.toByte(), 'H'.code.toByte(), 'P'.code.toByte(), 'W'.code.toByte())
    private const val VERSION = 1
    private const val MAX_MEM_KIB = 256 * 1024     // refuse blobs that would make us allocate more than 256 MiB

    data class Cost(val memoryKiB: Int = 65536, val iterations: Int = 3, val parallelism: Int = 2)

    fun wrap(secret: ByteArray, passphrase: CharArray, cost: Cost = Cost(), random: SecureRandom = SecureRandom()): ByteArray {
        val salt = ByteArray(16).also { random.nextBytes(it) }
        val nonce = ByteArray(12).also { random.nextBytes(it) }
        val header = ByteArrayOutputStream().also { b ->
            DataOutputStream(b).apply {
                write(MAGIC); writeByte(VERSION); writeInt(cost.memoryKiB); writeInt(cost.iterations)
                writeByte(cost.parallelism); write(salt); write(nonce); flush()
            }
        }.toByteArray()
        val key = derive(passphrase, salt, cost)
        try {
            return header + aes(Cipher.ENCRYPT_MODE, key, nonce, header, secret)
        } finally { key.fill(0) }
    }

    fun unwrap(blob: ByteArray, passphrase: CharArray): ByteArray {
        val headerLen = 4 + 1 + 4 + 4 + 1 + 16 + 12
        if (blob.size <= headerLen) throw GeneralSecurityException("too short")
        val header = blob.copyOfRange(0, headerLen)
        val inp = DataInputStream(ByteArrayInputStream(header))
        try {
            val magic = ByteArray(4); inp.readFully(magic)
            if (!magic.contentEquals(MAGIC) || inp.readUnsignedByte() != VERSION) throw GeneralSecurityException("not a wrapped key")
            val mem = inp.readInt(); val iter = inp.readInt(); val par = inp.readUnsignedByte()
            if (mem !in 8..MAX_MEM_KIB || iter !in 1..16 || par !in 1..8) throw GeneralSecurityException("unreasonable cost parameters")
            val salt = ByteArray(16); inp.readFully(salt)
            val nonce = ByteArray(12); inp.readFully(nonce)
            val key = derive(passphrase, salt, Cost(mem, iter, par))
            try {
                return aes(Cipher.DECRYPT_MODE, key, nonce, header, blob.copyOfRange(headerLen, blob.size))
            } finally { key.fill(0) }
        } catch (e: IOException) { throw GeneralSecurityException("malformed", e) }
    }

    private fun derive(passphrase: CharArray, salt: ByteArray, cost: Cost): ByteArray {
        val pw = String(passphrase).toByteArray(Charsets.UTF_8)
        try {
            val p = Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
                .withVersion(Argon2Parameters.ARGON2_VERSION_13)
                .withIterations(cost.iterations).withMemoryAsKB(cost.memoryKiB).withParallelism(cost.parallelism)
                .withSalt(salt).build()
            val g = Argon2BytesGenerator()
            g.init(p)
            val out = ByteArray(32)
            g.generateBytes(pw, out)
            return out
        } finally { pw.fill(0) }
    }

    private fun aes(mode: Int, key: ByteArray, nonce: ByteArray, aad: ByteArray, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(aad)
        return c.doFinal(data)
    }
}
