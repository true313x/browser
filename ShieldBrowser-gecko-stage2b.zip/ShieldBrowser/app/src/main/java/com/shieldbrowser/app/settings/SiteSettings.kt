package com.shieldbrowser.app.settings

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/** Tri-state used by per-site permissions. INHERIT = use the global default. */
object Perm {
    const val INHERIT = -1
    const val ASK = 0
    const val ALLOW = 1
    const val BLOCK = 2
}

/** Per-site cookie policy values (INHERIT = global). */
object SiteCookies {
    const val INHERIT = -1
    const val ALLOW_ALL = 1
    const val BLOCK_THIRD_PARTY = 2
    const val BLOCK_ALL = 3
    const val SESSION_ONLY = 4
}

/** Settings are keyed by *registrable domain* (example.com covers www.example.com, m.example.com …). */
data class SiteSettings(
    val key: String,
    val shield: Boolean = true,
    val js: Int = Perm.INHERIT,
    val cookies: Int = SiteCookies.INHERIT,
    val popups: Int = Perm.INHERIT,
    val camera: Int = Perm.INHERIT,
    val mic: Int = Perm.INHERIT,
    val location: Int = Perm.INHERIT,
    val notifications: Int = Perm.INHERIT,
    val clipboard: Int = Perm.INHERIT,
    val downloads: Int = Perm.INHERIT,
    val autoplay: Int = Perm.INHERIT,
    val fingerprint: Int = -1
) {
    fun isDefault(): Boolean = copy(key = "") == SiteSettings("")
}

class SiteSettingsRepository(private val db: AppDatabase, private val scope: CoroutineScope) {
    private val cache = ConcurrentHashMap<String, SiteSettings>()
    @Volatile var onChanged: (() -> Unit)? = null

    init { load() }

    fun key(host: String): String = DomainUtils.registrableDomain(host.lowercase())

    fun get(host: String?): SiteSettings {
        if (host.isNullOrEmpty()) return SiteSettings("")
        val k = key(host)
        return cache[k] ?: SiteSettings(k)
    }

    fun isShieldOn(host: String): Boolean = get(host).shield
    fun all(): List<SiteSettings> = cache.values.sortedBy { it.key }

    fun update(host: String, transform: (SiteSettings) -> SiteSettings) {
        val k = key(host)
        val next = transform(get(host)).copy(key = k)
        if (next.isDefault()) {
            cache.remove(k)
            scope.launch(Dispatchers.IO) { db.writableDatabase.delete("site_settings", "host = ?", arrayOf(k)) }
        } else {
            cache[k] = next
            scope.launch(Dispatchers.IO) {
                db.writableDatabase.insertWithOnConflict("site_settings", null, toValues(next), SQLiteDatabase.CONFLICT_REPLACE)
            }
        }
        onChanged?.invoke()
    }

    fun reset(host: String) = update(host) { SiteSettings(it.key) }

    fun clearAll() {
        cache.clear()
        scope.launch(Dispatchers.IO) { db.writableDatabase.delete("site_settings", null, null) }
        onChanged?.invoke()
    }

    private fun toValues(s: SiteSettings) = ContentValues().apply {
        put("host", s.key); put("shield", if (s.shield) 1 else 0); put("js", s.js); put("cookies", s.cookies)
        put("popups", s.popups); put("camera", s.camera); put("mic", s.mic); put("location", s.location)
        put("notifications", s.notifications); put("clipboard", s.clipboard); put("downloads", s.downloads)
        put("autoplay", s.autoplay); put("fingerprint", s.fingerprint)
    }

    private fun load() {
        db.readableDatabase.rawQuery(
            "SELECT host,shield,js,cookies,popups,camera,mic,location,notifications,clipboard,downloads,autoplay,fingerprint FROM site_settings", null
        ).use { c ->
            while (c.moveToNext()) {
                val s = SiteSettings(c.getString(0), c.getInt(1) == 1, c.getInt(2), c.getInt(3), c.getInt(4), c.getInt(5),
                    c.getInt(6), c.getInt(7), c.getInt(8), c.getInt(9), c.getInt(10), c.getInt(11), c.getInt(12))
                cache[s.key] = s
            }
        }
    }
}
