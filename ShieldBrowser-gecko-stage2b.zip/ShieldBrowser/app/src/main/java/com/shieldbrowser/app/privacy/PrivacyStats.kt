package com.shieldbrowser.app.privacy

import com.shieldbrowser.app.blocking.BlockCategory
import java.util.concurrent.atomic.AtomicInteger

enum class EventType {
    BLOCKED_REQUEST, FINGERPRINT, COOKIE, MINING, POPUP, REDIRECT, DOWNLOAD,
    CLIPBOARD, EXTERNAL_APP, TRACKING_PARAM, INSECURE, WEBRTC, DIALOG, MALWARE
}

data class BlockEvent(
    val type: EventType,
    val host: String,
    val url: String,
    val category: BlockCategory? = null,
    val detail: String? = null,
    val thirdParty: Boolean = false,
    val time: Long = System.currentTimeMillis()
)

/** Thread-safe counters shared by per-tab stats and the session report. */
class StatCounters {
    val trackers = AtomicInteger()
    val ads = AtomicInteger()
    val fingerprint = AtomicInteger()
    val cookies = AtomicInteger()
    val thirdParty = AtomicInteger()
    val mining = AtomicInteger()
    val dangerous = AtomicInteger()
    val popups = AtomicInteger()
    val redirects = AtomicInteger()
    val params = AtomicInteger()

    fun add(e: BlockEvent, n: Int = 1) {
        when (e.type) {
            EventType.BLOCKED_REQUEST -> {
                when (e.category) {
                    BlockCategory.ADVERTISING -> ads.addAndGet(n)
                    BlockCategory.ANALYTICS, BlockCategory.TRACKING, BlockCategory.SOCIAL_TRACKING -> trackers.addAndGet(n)
                    BlockCategory.CRYPTOMINING -> mining.addAndGet(n)
                    BlockCategory.MALWARE -> dangerous.addAndGet(n)
                    else -> {}
                }
                if (e.thirdParty) thirdParty.addAndGet(n)
            }
            EventType.FINGERPRINT -> fingerprint.addAndGet(n)
            EventType.COOKIE -> cookies.addAndGet(n)
            EventType.MINING -> mining.addAndGet(n)
            EventType.POPUP -> popups.addAndGet(n)
            EventType.REDIRECT -> redirects.addAndGet(n)
            EventType.TRACKING_PARAM -> { params.addAndGet(n); trackers.addAndGet(0) }
            EventType.MALWARE, EventType.INSECURE -> dangerous.addAndGet(n)
            EventType.DOWNLOAD -> dangerous.addAndGet(n)
            else -> {}
        }
    }

    fun clear() {
        listOf(trackers, ads, fingerprint, cookies, thirdParty, mining, dangerous, popups, redirects, params)
            .forEach { it.set(0) }
    }
}

/** Per-tab (per page load) statistics + a bounded event log for the details screens. */
class TabStats {
    val counters = StatCounters()
    private val lock = Any()
    private val events = ArrayDeque<BlockEvent>()
    private val maxEvents = 500

    fun record(e: BlockEvent, n: Int = 1) {
        counters.add(e, n)
        synchronized(lock) {
            events.addLast(e)
            while (events.size > maxEvents) events.removeFirst()
        }
    }

    fun events(filter: (BlockEvent) -> Boolean = { true }): List<BlockEvent> =
        synchronized(lock) { events.filter(filter) }

    fun reset() {
        counters.clear()
        synchronized(lock) { events.clear() }
    }
}

/** In-memory, per-session privacy report. NEVER persisted to disk and never sent anywhere. */
class SessionReport {
    val counters = StatCounters()
    val downloads = AtomicInteger()
    private val sites = LinkedHashSet<String>()
    private val lock = Any()

    fun visit(host: String) { if (host.isNotEmpty()) synchronized(lock) { sites.add(host) } }
    fun sitesVisited(): List<String> = synchronized(lock) { sites.toList() }
    fun record(e: BlockEvent, n: Int = 1) = counters.add(e, n)
    fun clear() { counters.clear(); downloads.set(0); synchronized(lock) { sites.clear() } }
}
