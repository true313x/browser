package com.shieldbrowser.app.security

import android.content.Context
import com.shieldbrowser.app.crypto.HybridKem
import com.shieldbrowser.app.crypto.HybridPrivateKey
import com.shieldbrowser.app.crypto.HybridPublicKey
import com.shieldbrowser.app.crypto.Kdf
import com.shieldbrowser.app.crypto.PassphraseWrap
import com.shieldbrowser.app.storage.AesGcmCipher
import com.shieldbrowser.app.storage.KeystoreKey
import java.io.File
import java.security.SecureRandom

/**
 * Local key material, all wrapped by ONE non-exportable Android Keystore AES-256-GCM key (alias [KEY_ALIAS]):
 *  - a random 32-byte master key -> derives the SQLCipher key of the local database;
 *  - the hybrid X25519 + ML-KEM-768 (Kyber) key pair -> backups/exports are sealed to its public key
 *    (`SealedBox`), so they stay confidential against a future quantum attacker who stored them today.
 * Files live in filesDir/vault/. Destroying the Keystore key ([destroy]) makes all of it unreadable at once.
 */
class KeyVault(context: Context) {
    companion object {
        const val KEY_ALIAS = "shield_vault_key_v1"
        private val AAD_MK = "shield.vault.mk.v1".toByteArray()
        private val AAD_KEM = "shield.vault.kem.v1".toByteArray()
    }

    private val dir = File(context.applicationContext.filesDir, "vault")
    private val cipher = AesGcmCipher { KeystoreKey.getOrCreate(KEY_ALIAS) }
    private val lock = Any()

    // ------------------------------------------------------------------------------------------ database key
    /** SQLCipher raw key syntax x'<64 hex>': no PBKDF2 round (the key is already random, 256 bits). */
    fun dbKey(): String {
        val mk = synchronized(lock) { loadOrCreateMasterKey() }
        val k = Kdf.hkdf(mk, "shield".toByteArray(), "db.v1".toByteArray(), 32)
        mk.fill(0)
        val hex = k.joinToString("") { "%02x".format(it) }
        k.fill(0)
        return "x'$hex'"
    }

    private fun loadOrCreateMasterKey(): ByteArray {
        dir.mkdirs()
        val f = File(dir, "mk.bin")
        if (f.exists()) {
            try { return cipher.decrypt(f.readBytes(), AAD_MK) } catch (_: Exception) { /* Keystore key lost / file damaged: start over */ }
        }
        val mk = ByteArray(32).also { SecureRandom().nextBytes(it) }
        atomicWrite(f, cipher.encrypt(mk, AAD_MK))
        return mk
    }

    // ------------------------------------------------------------------------------------------ hybrid (Kyber) key pair
    fun hybridPublicKey(): HybridPublicKey = synchronized(lock) {
        ensureKeyPair()
        HybridPublicKey.decode(File(dir, "kem.pub").readBytes())
    }

    /** Runs [block] with the private key and wipes it afterwards. Never keep a reference to it. */
    fun <T> withPrivateKey(block: (HybridPrivateKey) -> T): T {
        val priv = synchronized(lock) {
            ensureKeyPair()
            HybridPrivateKey.decode(cipher.decrypt(File(dir, "kem.key").readBytes(), AAD_KEM))
        }
        try { return block(priv) } finally { priv.wipe() }
    }

    private fun ensureKeyPair() {
        dir.mkdirs()
        val priv = File(dir, "kem.key"); val pub = File(dir, "kem.pub")
        if (priv.exists() && pub.exists()) {
            try { cipher.decrypt(priv.readBytes(), AAD_KEM).fill(0); return } catch (_: Exception) { /* regenerate below */ }
        }
        val kp = HybridKem.generate()
        atomicWrite(priv, cipher.encrypt(kp.priv.encode(), AAD_KEM))
        atomicWrite(pub, kp.pub.encode())
        kp.priv.wipe()
    }

    /** Recovery key = the hybrid private key protected by a passphrase (Argon2id + AES-GCM). Store it OFF the device. */
    fun exportRecoveryKey(passphrase: CharArray): ByteArray = withPrivateKey { PassphraseWrap.wrap(it.encode(), passphrase) }

    /** Destroys every local key (crypto-shredding): the database and all sealed data become unreadable. */
    fun destroy() {
        synchronized(lock) {
            dir.listFiles()?.forEach { SealedWiper.shredRecursively(it) }
            dir.delete()
            KeystoreKey.delete(KEY_ALIAS)
        }
    }

    private fun atomicWrite(target: File, bytes: ByteArray) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }
}
