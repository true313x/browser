package com.shieldbrowser.app.blocking

/**
 * Small, dependency-free URL/host helpers (pure Kotlin so they are unit-testable on the JVM).
 *
 * LIMITATION: there is no bundled Public Suffix List. [registrableDomain] uses a compact list of
 * common multi-label suffixes (co.uk, com.au ...). Exotic suffixes may be mis-classified, which can
 * only cause a first-party request to be treated as third-party (or vice versa) in rare cases.
 */
object DomainUtils {
    private val multiLabelSuffixes = setOf(
        "co.uk", "org.uk", "ac.uk", "gov.uk", "me.uk", "ltd.uk", "plc.uk",
        "com.au", "net.au", "org.au", "edu.au", "gov.au",
        "co.nz", "org.nz", "net.nz", "govt.nz",
        "co.jp", "ne.jp", "or.jp", "ac.jp", "go.jp",
        "co.kr", "or.kr", "go.kr", "co.in", "net.in", "org.in", "gov.in", "ac.in",
        "com.br", "net.br", "org.br", "gov.br", "com.mx", "com.ar", "com.co", "com.pe", "com.ve",
        "com.tr", "org.tr", "gov.tr", "com.sa", "gov.sa", "com.eg", "gov.eg", "com.ae", "co.il",
        "com.cn", "net.cn", "org.cn", "gov.cn", "com.hk", "com.tw", "com.sg", "com.my", "com.ph", "co.id", "co.th",
        "co.za", "org.za", "com.ng", "com.pk", "com.bd", "com.vn", "com.ua", "com.pl", "com.ru"
    )

    fun schemeOf(url: String): String? {
        val i = url.indexOf(':')
        if (i <= 0) return null
        val s = url.substring(0, i)
        return if (s.all { it.isLetterOrDigit() || it == '+' || it == '-' || it == '.' }) s.lowercase() else null
    }

    /** Extracts the lower-case host of an absolute URL, or null. Handles userinfo, ports and IPv6. */
    fun hostOf(url: String): String? {
        val schemeEnd = url.indexOf("://")
        if (schemeEnd < 0) return null
        var rest = url.substring(schemeEnd + 3)
        val end = rest.indexOfFirst { it == '/' || it == '?' || it == '#' }
        if (end >= 0) rest = rest.substring(0, end)
        val at = rest.lastIndexOf('@')
        if (at >= 0) rest = rest.substring(at + 1)
        if (rest.startsWith("[")) {
            val close = rest.indexOf(']')
            return if (close > 0) rest.substring(0, close + 1).lowercase() else null
        }
        val colon = rest.lastIndexOf(':')
        if (colon >= 0) rest = rest.substring(0, colon)
        val host = rest.lowercase().trimEnd('.')
        return host.ifEmpty { null }
    }

    fun isIpLiteral(host: String): Boolean =
        host.startsWith("[") || (host.isNotEmpty() && host.all { it.isDigit() || it == '.' })

    fun isLocalHost(host: String): Boolean =
        host == "localhost" || host.endsWith(".localhost") || host == "127.0.0.1" || host == "[::1]" ||
            host.startsWith("10.") || host.startsWith("192.168.") ||
            (host.startsWith("172.") && host.split('.').getOrNull(1)?.toIntOrNull() in 16..31)

    fun registrableDomain(host: String): String {
        if (isIpLiteral(host)) return host
        val labels = host.split('.')
        if (labels.size <= 2) return host
        val last2 = labels.takeLast(2).joinToString(".")
        return if (last2 in multiLabelSuffixes) labels.takeLast(3).joinToString(".") else last2
    }

    fun isThirdParty(host: String, pageHost: String?): Boolean {
        if (pageHost.isNullOrEmpty()) return false
        return registrableDomain(host) != registrableDomain(pageHost)
    }

    /** host, then each parent domain that still contains a dot: a.b.c.com -> a.b.c.com, b.c.com, c.com */
    fun parents(host: String): Sequence<String> = sequence {
        var h = host
        while (true) {
            yield(h)
            val i = h.indexOf('.')
            if (i < 0) break
            val next = h.substring(i + 1)
            if (!next.contains('.')) break
            h = next
        }
    }
}
