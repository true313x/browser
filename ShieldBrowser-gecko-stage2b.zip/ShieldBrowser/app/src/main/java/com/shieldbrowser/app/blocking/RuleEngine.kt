package com.shieldbrowser.app.blocking

/** Rule families (see README > Ad blocking). Domain rules live in a hash map; the rest are patterns. */
enum class RuleKind { URL, RESOURCE, SCRIPT }

class PatternRule(
    val kind: RuleKind,
    val category: BlockCategory,
    val thirdPartyOnly: Boolean,
    val source: String
) {
    private val regex: Regex = Regex(source.lowercase().split('*').joinToString(".*") { Regex.escape(it) })
    fun matches(lowerUrl: String): Boolean = regex.containsMatchIn(lowerUrl)
}

object PatternParser {
    /** Line format: `kind category thirdPartyFlag pattern` (flag: 1 = third-party only). */
    fun parse(text: String): List<PatternRule> = text.lineSequence().mapNotNull { raw ->
        val line = raw.trim()
        if (line.isEmpty() || line.startsWith("#")) return@mapNotNull null
        val p = line.split(Regex("\\s+"), limit = 4)
        if (p.size < 4) return@mapNotNull null
        val kind = RuleKind.values().firstOrNull { it.name.equals(p[0], true) } ?: return@mapNotNull null
        PatternRule(kind, BlockCategory.fromKey(p[1]), p[2] == "1", p[3])
    }.toList()
}

data class BlockerConfig(
    val enabled: Boolean = true,
    val categories: Set<BlockCategory> = setOf(
        BlockCategory.ADVERTISING, BlockCategory.ANALYTICS, BlockCategory.TRACKING,
        BlockCategory.SOCIAL_TRACKING, BlockCategory.CRYPTOMINING, BlockCategory.MALWARE
    )
)

/**
 * Local rule engine. Thread-safe for concurrent reads (called from WebView's IO threads).
 *
 * Precedence: global off / per-site shield off  >  user allow-list  >  user block-list  >
 * main-frame handling (only malware/miners are ever blocked as a top-level page)  >
 * essential allow-list  >  domain rules  >  pattern rules.
 *
 * "Essential" infrastructure (CDNs, captchas, payment, sign-in) is allowed so we don't blindly break sites.
 */
class RuleEngine {
    @Volatile var config: BlockerConfig = BlockerConfig()
    @Volatile var userAllow: Set<String> = emptySet()
    @Volatile var userBlock: Set<String> = emptySet()
    @Volatile var siteShieldOff: (String) -> Boolean = { false }

    @Volatile private var domains: Map<String, BlockCategory> = emptyMap()
    @Volatile private var patterns: List<PatternRule> = emptyList()
    @Volatile private var essential: Set<String> = emptySet()

    fun load(domains: Map<String, BlockCategory>, patterns: List<PatternRule>, essential: Set<String>) {
        this.domains = domains
        this.patterns = patterns
        this.essential = essential
    }

    fun domainRuleCount(): Int = domains.size
    fun patternRuleCount(): Int = patterns.size

    fun classifyHost(host: String): BlockCategory? = matchMap(domains, host)?.second

    fun evaluate(url: String, pageHost: String?, isMainFrame: Boolean): Decision {
        val cfg = config
        if (!cfg.enabled) return Decision.ALLOW
        val host = DomainUtils.hostOf(url) ?: return Decision.ALLOW
        if (pageHost != null && siteShieldOff(pageHost)) return Decision.ALLOW
        val thirdParty = !isMainFrame && DomainUtils.isThirdParty(host, pageHost)

        if (matchSet(userAllow, host) != null) return Decision.ALLOW
        matchSet(userBlock, host)?.let { return Decision(true, BlockCategory.TRACKING, "user-block:$it", thirdParty) }

        val dm = matchMap(domains, host)
        if (isMainFrame) {
            // Never silently block ordinary pages; only warn for malware / cryptominers.
            if (dm != null && (dm.second == BlockCategory.MALWARE || dm.second == BlockCategory.CRYPTOMINING) &&
                dm.second in cfg.categories
            ) return Decision(true, dm.second, "domain:${dm.first}", false)
            return Decision.ALLOW
        }

        if (matchSet(essential, host) != null) return Decision.ALLOW

        if (dm != null && dm.second in cfg.categories) {
            val harmful = dm.second == BlockCategory.MALWARE || dm.second == BlockCategory.CRYPTOMINING
            if (harmful || thirdParty) return Decision(true, dm.second, "domain:${dm.first}", thirdParty)
        }

        val lower = url.lowercase()
        for (p in patterns) {
            if (p.category !in cfg.categories) continue
            if (p.thirdPartyOnly && !thirdParty) continue
            if (p.matches(lower)) return Decision(true, p.category, "${p.kind.name.lowercase()}:${p.source}", thirdParty)
        }
        return Decision.ALLOW
    }

    private fun matchSet(set: Set<String>, host: String): String? {
        if (set.isEmpty()) return null
        for (p in DomainUtils.parents(host)) if (p in set) return p
        return null
    }

    private fun matchMap(map: Map<String, BlockCategory>, host: String): Pair<String, BlockCategory>? {
        if (map.isEmpty()) return null
        for (p in DomainUtils.parents(host)) map[p]?.let { return p to it }
        return null
    }
}
