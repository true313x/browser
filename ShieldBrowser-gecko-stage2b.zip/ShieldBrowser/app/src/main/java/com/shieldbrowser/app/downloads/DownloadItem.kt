package com.shieldbrowser.app.downloads

enum class DownloadState(val code: Int) {
    QUEUED(0), RUNNING(1), PAUSED(2), COMPLETED(3), FAILED(4), CANCELED(5);

    companion object { fun of(code: Int) = values().firstOrNull { it.code == code } ?: FAILED }
}

data class DownloadItem(
    val id: Long,
    val url: String,
    val fileName: String,
    val filePath: String,
    val mime: String?,
    val totalBytes: Long,
    val downloadedBytes: Long,
    val state: DownloadState,
    val createdAt: Long,
    val sha256: String? = null,
    val sourceHost: String? = null,
    val risk: RiskLevel = RiskLevel.LOW,
    val riskReasons: List<String> = emptyList(),
    val error: String? = null,
    val isPrivate: Boolean = false,
    // transient (never persisted)
    val speedBps: Long = 0,
    val etaSeconds: Long = -1
) {
    val category: FileCategory get() = DownloadSafety.categoryOf(fileName, mime)
    val isActive: Boolean get() = state == DownloadState.RUNNING || state == DownloadState.QUEUED
    /** Streamed downloads (`blob:` pages, or `stream:` = bytes handed over by the engine) cannot be paused or resumed. */
    val isBlob: Boolean get() = isStreamUrl(url)

    companion object {
        fun isStreamUrl(url: String): Boolean = url.startsWith("blob:") || url.startsWith("stream:")
    }
    val progress: Int get() = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt().coerceIn(0, 100) else -1
}

data class DownloadRequest(
    val url: String,
    val userAgent: String?,
    val cookies: String?,
    val referrer: String?,
    val fileName: String,
    val mime: String?,
    val contentLength: Long,
    val isPrivate: Boolean
)
