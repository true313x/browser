package com.shieldbrowser.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.blocking.BlockCategory
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.browser.BrowserTab
import com.shieldbrowser.app.databinding.ItemStatRowBinding
import com.shieldbrowser.app.databinding.SheetPrivacyBinding
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.privacy.EventType
import com.shieldbrowser.app.security.SecurityState

/** Per-site Privacy Dashboard + Security summary. Every row is tappable and shows the underlying events. */
class PrivacySheet(private val activity: MainActivity, private val tab: BrowserTab) {
    private val c = activity.container

    fun show() {
        val dlg = BottomSheetDialog(activity)
        val v = SheetPrivacyBinding.inflate(LayoutInflater.from(activity))
        dlg.setContentView(v.root)
        dlg.fitScreen()
        val host = tab.pageHost ?: DomainUtils.hostOf(tab.data.url).orEmpty()
        v.sheetHost.text = host.ifEmpty { activity.getString(R.string.internal_page) }
        v.siteShieldSwitch.isEnabled = host.isNotEmpty()
        v.siteShieldSwitch.isChecked = host.isEmpty() || c.siteSettings.isShieldOn(host)
        v.siteShieldSwitch.setOnCheckedChangeListener { _, on ->
            c.siteSettings.update(host) { it.copy(shield = on) }
            tab.webView?.reload()
            dlg.dismiss()
        }

        val k = tab.stats.counters
        fun events(f: (BlockEvent) -> Boolean) = tab.stats.events(f)
        val trackerCats = setOf(BlockCategory.ANALYTICS, BlockCategory.TRACKING, BlockCategory.SOCIAL_TRACKING)
        data class Stat(val icon: String, val label: Int, val count: Int, val filter: (BlockEvent) -> Boolean)
        val rows = listOf(
            Stat("◉", R.string.stat_trackers, k.trackers.get()) { it.type == EventType.BLOCKED_REQUEST && it.category in trackerCats },
            Stat("▤", R.string.stat_ads, k.ads.get()) { it.type == EventType.BLOCKED_REQUEST && it.category == BlockCategory.ADVERTISING },
            Stat("☝", R.string.stat_fingerprint, k.fingerprint.get()) { it.type == EventType.FINGERPRINT },
            Stat("◔", R.string.stat_cookies, k.cookies.get()) { it.type == EventType.COOKIE },
            Stat("⇄", R.string.stat_third_party, k.thirdParty.get()) { it.type == EventType.BLOCKED_REQUEST && it.thirdParty },
            Stat("⛏", R.string.stat_mining, k.mining.get()) { it.type == EventType.MINING || it.category == BlockCategory.CRYPTOMINING },
            Stat("⧉", R.string.stat_popups, k.popups.get()) { it.type == EventType.POPUP },
            Stat("↪", R.string.stat_redirects, k.redirects.get()) { it.type == EventType.REDIRECT },
            Stat("✂", R.string.stat_params, k.params.get()) { it.type == EventType.TRACKING_PARAM }
        )
        rows.forEach { r ->
            addRow(v.statRows, r.icon, activity.getString(r.label), r.count.toString(), if (r.count > 0) true else null) {
                showEvents(activity.getString(r.label), events(r.filter))
            }
        }

        // ---- Security section
        val (connText, connOk) = when (tab.security) {
            SecurityState.SECURE -> R.string.sec_row_https to true
            SecurityState.INSECURE -> R.string.sec_row_http to false
            SecurityState.WARNING -> R.string.sec_row_cert to false
            else -> R.string.sec_row_internal to null
        }
        addRow(v.securityRows, mark(connOk), activity.getString(connText), "", connOk) { activity.showSecurityDialog(tab); dlg.dismiss() }
        val safe = tab.security == SecurityState.SECURE && k.dangerous.get() == 0
        addRow(v.securityRows, mark(if (tab.security == SecurityState.SECURE) safe else null), activity.getString(R.string.sec_row_safe), "", if (tab.security == SecurityState.SECURE) safe else null) {
            showEvents(activity.getString(R.string.sec_row_safe), events { it.type == EventType.INSECURE || it.type == EventType.DOWNLOAD || it.category == BlockCategory.MALWARE })
        }
        val noBadDl = k.dangerous.get() == 0
        addRow(v.securityRows, mark(noBadDl), activity.getString(R.string.sec_row_downloads), if (noBadDl) "" else k.dangerous.get().toString(), noBadDl) {}

        v.btnSiteSettings.isEnabled = host.isNotEmpty()
        v.btnClearSite.isEnabled = host.isNotEmpty()
        v.btnSiteSettings.setOnClickListener { dlg.dismiss(); SiteSettingsSheet(activity, host).show() }
        v.btnClearSite.setOnClickListener {
            c.cookies.clearSiteData(host); dlg.dismiss(); tab.webView?.reload()
        }
        dlg.show()
    }

    private fun mark(ok: Boolean?) = when (ok) { true -> "✓"; false -> "⚠"; null -> "•" }

    private fun addRow(parent: ViewGroup, icon: String, label: String, value: String, ok: Boolean?, onClick: () -> Unit) {
        val rb = ItemStatRowBinding.inflate(LayoutInflater.from(activity), parent, false)
        rb.rowIcon.text = icon
        rb.rowLabel.text = label
        rb.rowValue.text = value
        rb.rowIcon.setStatusColor(ok)
        rb.root.setOnClickListener { onClick() }
        parent.addView(rb.root)
    }

    private fun showEvents(title: String, list: List<BlockEvent>) {
        val msg = if (list.isEmpty()) activity.getString(R.string.no_events)
        else list.groupBy { it.host.ifEmpty { "(page)" } }.entries.sortedByDescending { it.value.size }.take(60).joinToString("\n\n") { (h, evs) ->
            val first = evs.first()
            val why = listOfNotNull(first.category?.key, first.detail).joinToString(" · ")
            "$h  ×${evs.size}" + if (why.isNotEmpty()) "\n   $why" else ""
        }
        MaterialAlertDialogBuilder(activity).setTitle(title).setMessage(msg).setPositiveButton(android.R.string.ok, null).show()
    }
}
