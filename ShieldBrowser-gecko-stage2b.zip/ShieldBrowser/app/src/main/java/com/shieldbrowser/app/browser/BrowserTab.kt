package com.shieldbrowser.app.browser

import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.WebView
import androidx.webkit.ScriptHandler
import com.shieldbrowser.app.privacy.TabStats
import com.shieldbrowser.app.security.SecurityState
import com.shieldbrowser.app.tabs.TabData
import java.util.concurrent.ConcurrentLinkedDeque

/** Runtime state of a tab. Fields touched from WebView's background threads are @Volatile. */
class BrowserTab(val data: TabData) {
    val id: Long get() = data.id
    val isPrivate: Boolean get() = data.isPrivate

    var webView: WebView? = null
    var ctxWrapper: MutableContextWrapper? = null
    var savedState: Bundle? = null
    var scriptHandler: ScriptHandler? = null
    var blobScriptHandler: ScriptHandler? = null
    var needsLoad = true
    var profileName: String? = null
    var profileLocked = false
    var openerId: Long? = null

    val stats = TabStats()
    @Volatile var pageHost: String? = null
    @Volatile var nonce: String? = null
    @Volatile var pendingUrl: String? = null
    @Volatile var internalPage = false
    @Volatile var forcedSecurity: SecurityState? = null
    @Volatile var upgradedHost: String? = null
    @Volatile var sslErrorAt = 0L
    @Volatile var lastTouchAt = 0L
    @Volatile var pageLoaded = false
    /** URL of the last main-frame page that was replaced by a block interstitial (kept out of history). */
    @Volatile var blockedUrl: String? = null
    @Volatile var lastHeaders: Map<String, String> = emptyMap()

    var progress = 0
    var loading = false
    var security = SecurityState.NONE
    var favicon: Bitmap? = null
    var lastActiveAt = System.currentTimeMillis()

    val sslExceptions = HashSet<String>()
    val httpAllowed = HashSet<String>()
    val blockAllowed = HashSet<String>()
    val dialogTimes = ArrayDeque<Long>()
    val windowTimes = ArrayDeque<Long>()

    val console = ConcurrentLinkedDeque<String>()
    val requestLog = ConcurrentLinkedDeque<String>()

    fun pushLog(q: ConcurrentLinkedDeque<String>, line: String, max: Int = 300) {
        q.addLast(line)
        while (q.size > max) q.pollFirst()
    }
}
