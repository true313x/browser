package com.shieldbrowser.app.downloads

enum class RiskLevel { LOW, MEDIUM, HIGH }
enum class FileCategory { VIDEO, IMAGE, DOCUMENT, APK, ARCHIVE, OTHER }

/** Reasons are stable keys; the UI maps them to localised strings (see DownloadsActivity.reasonText). */
data class RiskAssessment(val level: RiskLevel, val reasons: List<String>)

/**
 * Heuristic download validation (pure Kotlin). This is NOT malware scanning — it flags file types and
 * naming tricks that are commonly abused so the user gets a clear warning before opening/installing.
 */
object DownloadSafety {
    private val highExt = setOf(
        "exe", "msi", "bat", "cmd", "scr", "com", "pif", "vbs", "vbe", "js", "jse", "wsf", "wsh", "ps1", "dll",
        "lnk", "hta", "reg", "cpl", "msc", "jar", "sh", "dex", "dmg", "pkg", "deb", "rpm", "apk", "xapk", "apks", "apkm"
    )
    private val mediumExt = setOf("docm", "xlsm", "pptm", "html", "htm", "svg", "iso", "img", "7z", "rar")
    private val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp", "csv", "epub", "md")
    private val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "iso")
    private val videoExt = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "flv", "ts")
    private val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic", "avif", "ico")
    private val installable = setOf("apk", "xapk", "apks", "apkm")

    fun extensionOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    fun isApk(name: String, mime: String?): Boolean =
        extensionOf(name) in installable || mime == "application/vnd.android.package-archive"

    fun categoryOf(name: String, mime: String?): FileCategory {
        val ext = extensionOf(name)
        return when {
            isApk(name, mime) -> FileCategory.APK
            mime?.startsWith("video/") == true || ext in videoExt -> FileCategory.VIDEO
            mime?.startsWith("image/") == true || ext in imageExt -> FileCategory.IMAGE
            ext in archiveExt || mime == "application/zip" -> FileCategory.ARCHIVE
            ext in docExt || mime?.startsWith("text/") == true || mime == "application/pdf" -> FileCategory.DOCUMENT
            else -> FileCategory.OTHER
        }
    }

    fun assess(fileName: String, mime: String?, sourceUrl: String): RiskAssessment {
        val reasons = ArrayList<String>()
        var level = RiskLevel.LOW
        fun raise(l: RiskLevel, why: String) { reasons.add(why); if (l.ordinal > level.ordinal) level = l }
        val ext = extensionOf(fileName)
        if (isApk(fileName, mime)) raise(RiskLevel.HIGH, "apk")
        else if (ext in highExt) raise(RiskLevel.HIGH, "executable")
        else if (ext in mediumExt) raise(RiskLevel.MEDIUM, "active_content")
        // report.pdf.exe / invoice.jpg.scr
        val parts = fileName.lowercase().split('.')
        if (parts.size >= 3 && parts.last() in highExt && (parts[parts.size - 2] in docExt || parts[parts.size - 2] in imageExt))
            raise(RiskLevel.HIGH, "double_extension")
        // declared type does not match the extension
        if (mime != null) {
            val declaredMedia = mime.startsWith("image/") || mime.startsWith("video/") || mime == "application/pdf"
            if (declaredMedia && ext in highExt) raise(RiskLevel.HIGH, "mime_mismatch")
            if (mime == "application/octet-stream" && ext.isEmpty()) raise(RiskLevel.MEDIUM, "unknown_type")
        }
        if (sourceUrl.startsWith("http://")) raise(RiskLevel.MEDIUM, "insecure_source")
        if (fileName.any { it == '\u202E' }) raise(RiskLevel.HIGH, "rtl_override")   // right-to-left override spoofing
        return RiskAssessment(level, reasons)
    }

    /** Strips path separators / control chars / leading dots; never returns an empty name. */
    fun sanitizeFileName(raw: String?): String {
        var n = (raw ?: "").substringAfterLast('/').substringAfterLast('\\')
        n = n.filter { it.code >= 32 && it !in "<>:\"|?*" && !isInvisibleFormat(it) }.trim().trimStart('.').trimEnd('.', ' ')
        if (n.length > 120) {
            val ext = n.substringAfterLast('.', "")
            n = n.take(110) + if (ext.isNotEmpty() && ext.length <= 8) ".$ext" else ""
        }
        return n.ifEmpty { "download" }
    }

    /** Bidi overrides/isolates and zero-width characters can disguise "evil\u202Egpj.exe" as "evilexe.jpg". */
    private fun isInvisibleFormat(c: Char): Boolean =
        c in '\u200B'..'\u200F' || c in '\u202A'..'\u202E' || c in '\u2066'..'\u2069' || c == '\u2060' || c == '\uFEFF'

    /** "name.ext" → "name (1).ext" until [exists] is false. */
    fun uniqueName(name: String, exists: (String) -> Boolean): String {
        if (!exists(name)) return name
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (true) {
            val candidate = "$base ($i)$ext"
            if (!exists(candidate)) return candidate
            i++
        }
    }
}
