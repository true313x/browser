package com.shieldbrowser.app.blocking

/** Classification used by the rule engine and surfaced to the user in the privacy dashboard. */
enum class BlockCategory(val key: String) {
    ESSENTIAL("essential"),
    ANALYTICS("analytics"),
    ADVERTISING("advertising"),
    TRACKING("tracking"),
    SOCIAL_TRACKING("social"),
    CRYPTOMINING("cryptomining"),
    MALWARE("malware"),
    UNKNOWN("unknown");

    companion object {
        fun fromKey(key: String): BlockCategory =
            values().firstOrNull { it.key.equals(key.trim(), ignoreCase = true) } ?: UNKNOWN
    }
}

/** Result of evaluating one request against the rule engine. */
data class Decision(
    val block: Boolean,
    val category: BlockCategory = BlockCategory.UNKNOWN,
    val rule: String? = null,
    val thirdParty: Boolean = false
) {
    companion object {
        val ALLOW = Decision(false)
    }
}
