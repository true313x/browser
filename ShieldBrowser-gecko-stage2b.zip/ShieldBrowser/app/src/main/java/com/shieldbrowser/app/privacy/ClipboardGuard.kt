package com.shieldbrowser.app.privacy

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build

/** App-side clipboard hygiene. (Web-side clipboard-read blocking lives in assets/js/shield_core.js.) */
object ClipboardGuard {
    fun clear(context: Context) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip()
            else cm.setPrimaryClip(ClipData.newPlainText("", ""))
        } catch (_: Exception) { /* some OEMs restrict background clipboard access */ }
    }
}
