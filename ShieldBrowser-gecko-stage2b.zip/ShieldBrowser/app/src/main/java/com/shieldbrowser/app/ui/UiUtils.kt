package com.shieldbrowser.app.ui

import android.app.Activity
import com.shieldbrowser.app.BuildConfig
import android.content.Context
import android.content.Intent
import android.text.format.DateUtils
import android.text.format.Formatter
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.shieldbrowser.app.R
import com.shieldbrowser.app.databinding.ItemListEntryBinding

fun Context.formatSize(bytes: Long): String = if (bytes < 0) "?" else Formatter.formatShortFileSize(this, bytes)

fun Context.formatWhen(t: Long): String =
    DateUtils.getRelativeTimeSpanString(t, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE).toString()

/** Opens a URL in the browser (single-task MainActivity picks it up in onNewIntent). */
fun Context.openInBrowser(url: String, newTab: Boolean = true) {
    // The "gecko" flavor opens links in its own browser screen (looked up by name: the classic flavor has no such class).
    val target: Class<*> = if (BuildConfig.FLAVOR == "gecko") {
        try { Class.forName("com.shieldbrowser.app.gecko.GeckoBrowserActivity") } catch (_: Exception) { MainActivity::class.java }
    } else MainActivity::class.java
    val i = Intent(this, target).apply {
        action = Intent.ACTION_VIEW
        data = android.net.Uri.parse(url)
        putExtra(MainActivity.EXTRA_INTERNAL, true)
        putExtra(MainActivity.EXTRA_NEW_TAB, newTab)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    }
    startActivity(i)
}

/**
 * Bottom sheets: fully expanded (on landscape phones the lower buttons would otherwise be cut off) and limited to
 * [maxWidthDp] — centred — on wide screens such as tablets. Call after setContentView() and before show().
 */
fun BottomSheetDialog.fitScreen(maxWidthDp: Int = 640) {
    behavior.state = BottomSheetBehavior.STATE_EXPANDED
    behavior.skipCollapsed = true
    behavior.maxWidth = (maxWidthDp * context.resources.displayMetrics.density).toInt()
}

/**
 * Tablets (smallest width >= 600dp): keeps list-like screens readable by centring [views] and limiting them to
 * [maxDp]. No-op on phones. Each view must be a direct child of a LinearLayout or FrameLayout.
 */
fun Activity.centerContent(vararg views: View?, maxDp: Int = 640) {
    if (resources.configuration.smallestScreenWidthDp < 600) return
    val maxPx = (maxDp * resources.displayMetrics.density).toInt()
    for (v in views) {
        if (v == null) continue
        val parent = v.parent as? View ?: continue
        parent.addOnLayoutChangeListener { _, left, _, right, _, _, _, _, _ ->
            val lp = v.layoutParams
            if (lp != null) {
                val target = if (right - left > maxPx) maxPx else ViewGroup.LayoutParams.MATCH_PARENT
                var changed = false
                if (lp.width != target) { lp.width = target; changed = true }
                if (lp is LinearLayout.LayoutParams && lp.gravity != Gravity.CENTER_HORIZONTAL) { lp.gravity = Gravity.CENTER_HORIZONTAL; changed = true }
                if (lp is FrameLayout.LayoutParams && lp.gravity != Gravity.CENTER_HORIZONTAL) { lp.gravity = Gravity.CENTER_HORIZONTAL; changed = true }
                if (changed) v.layoutParams = lp
            }
        }
    }
}

data class Entry(val id: Long, val title: String, val subtitle: String, val key: String)

/** Generic two-line list adapter used by History, Bookmarks, Site settings, Tab switcher. */
class EntryAdapter(
    private val onClick: (Entry) -> Unit,
    private val onMore: (Entry, View) -> Unit
) : RecyclerView.Adapter<EntryAdapter.VH>() {
    private var items: List<Entry> = emptyList()

    class VH(val b: ItemListEntryBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(list: List<Entry>) { items = list; notifyDataSetChanged() }
    override fun getItemCount() = items.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemListEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        h.b.title.text = e.title.ifBlank { e.subtitle }
        h.b.subtitle.text = e.subtitle
        h.b.letter.text = (e.title.ifBlank { e.subtitle }.removePrefix("www.").firstOrNull() ?: '•').uppercaseChar().toString()
        h.b.root.setOnClickListener { onClick(e) }
        h.b.more.setOnClickListener { onMore(e, it) }
    }
}

fun TextView.setStatusColor(ok: Boolean?) {
    val res = when (ok) { true -> R.color.status_ok; false -> R.color.status_bad; null -> R.color.status_off }
    setTextColor(context.getColor(res))
}
