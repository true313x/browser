package com.shieldbrowser.app.browser

import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * Real storage isolation using Chromium WebView multi-profile support (androidx.webkit Profile API).
 *  - Private tabs      → profile "private" (own cookies/storage/cache), deleted when the last private tab closes.
 *  - Strict isolation  → every normal tab gets an ephemeral profile "iso-<tabId>", deleted when the tab closes.
 * If the installed WebView does not support MULTI_PROFILE, [supported] is false and private tabs fall back to
 * "limited" mode (no history, no cache, no private downloads — but a SHARED cookie jar). The UI says so.
 */
class ProfileManager {
    companion object {
        const val PRIVATE_PROFILE = "private"
        const val ISOLATED_PREFIX = "iso-"
    }

    private val main = Handler(Looper.getMainLooper())

    val supported: Boolean
        get() = try { WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) } catch (_: Throwable) { false }

    fun profileNameFor(tab: BrowserTab, strictIsolation: Boolean): String? = when {
        !supported -> null
        tab.isPrivate -> PRIVATE_PROFILE
        strictIsolation -> ISOLATED_PREFIX + tab.id
        else -> null
    }

    /** Must be called right after constructing the WebView, before anything else touches it. */
    fun apply(webView: WebView, profileName: String?) {
        if (profileName == null || !supported) return
        try { WebViewCompat.setProfile(webView, profileName) } catch (_: Throwable) {}
    }

    fun cookieManagerFor(profileName: String?): CookieManager {
        if (profileName == null || !supported) return CookieManager.getInstance()
        return try { ProfileStore.getInstance().getOrCreateProfile(profileName).cookieManager }
        catch (_: Throwable) { CookieManager.getInstance() }
    }

    fun allCookieManagers(): List<CookieManager> {
        val out = ArrayList<CookieManager>()
        out.add(CookieManager.getInstance())
        if (supported) try {
            ProfileStore.getInstance().allProfileNames.forEach { n ->
                if (n != "Default") ProfileStore.getInstance().getProfile(n)?.let { out.add(it.cookieManager) }
            }
        } catch (_: Throwable) {}
        return out
    }

    /** Deletes a profile; WebViews are destroyed asynchronously so retry a few times. */
    fun deleteLater(name: String, canDelete: () -> Boolean = { true }, attempt: Int = 0) {
        if (!supported) return
        main.postDelayed({
            if (!canDelete()) return@postDelayed
            val ok = try { ProfileStore.getInstance().deleteProfile(name) } catch (_: Throwable) { false }
            if (!ok && attempt < 4) deleteLater(name, canDelete, attempt + 1)
        }, 1200L)
    }

    /** At process start no WebView exists, so every non-default profile is an orphan. */
    fun cleanupOrphans() {
        if (!supported) return
        try {
            val store = ProfileStore.getInstance()
            store.allProfileNames.filter { it != "Default" }.forEach { try { store.deleteProfile(it) } catch (_: Throwable) {} }
        } catch (_: Throwable) {}
    }
}
