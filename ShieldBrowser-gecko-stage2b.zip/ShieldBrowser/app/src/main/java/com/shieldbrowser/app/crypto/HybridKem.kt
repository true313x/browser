package com.shieldbrowser.app.crypto

import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.generators.MLKEMKeyPairGenerator
import org.bouncycastle.crypto.kems.MLKEMExtractor
import org.bouncycastle.crypto.kems.MLKEMGenerator
import org.bouncycastle.crypto.params.MLKEMKeyGenerationParameters
import org.bouncycastle.crypto.params.MLKEMParameters
import org.bouncycastle.crypto.params.MLKEMPrivateKeyParameters
import org.bouncycastle.crypto.params.MLKEMPublicKeyParameters
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import java.io.IOException
import java.security.GeneralSecurityException
import java.security.SecureRandom

private const val KEY_VERSION: Byte = 1

/** Public half of a hybrid X25519 + ML-KEM-768 (Kyber, FIPS 203) key. Safe to share. */
class HybridPublicKey(val x25519: ByteArray, val mlkem: ByteArray) {
    fun encode(): ByteArray = Wire.pack(byteArrayOf(KEY_VERSION), x25519, mlkem)

    /** 128-bit fingerprint for out-of-band comparison, e.g. "a1b2 c3d4 ...". */
    fun fingerprint(): String =
        Kdf.sha256(encode()).take(16).joinToString("") { "%02x".format(it) }.chunked(4).joinToString(" ")

    companion object {
        fun decode(b: ByteArray): HybridPublicKey {
            val f = try { Wire.unpack(b, 3) } catch (e: IOException) { throw GeneralSecurityException("malformed public key", e) }
            if (f[0].size != 1 || f[0][0] != KEY_VERSION) throw GeneralSecurityException("unsupported key version")
            if (f[1].size != 32) throw GeneralSecurityException("bad X25519 key")
            if (f[2].size != HybridKem.MLKEM768_PK) throw GeneralSecurityException("bad ML-KEM key")
            return HybridPublicKey(f[1], f[2])
        }
    }
}

/** Secret half. Keep it in memory only as long as needed and call [wipe]. */
class HybridPrivateKey(val x25519: ByteArray, val mlkem: ByteArray, val pub: HybridPublicKey) {
    fun encode(): ByteArray = Wire.pack(byteArrayOf(KEY_VERSION), x25519, mlkem, pub.encode())
    fun wipe() { x25519.fill(0); mlkem.fill(0) }

    companion object {
        fun decode(b: ByteArray): HybridPrivateKey {
            val f = try { Wire.unpack(b, 4) } catch (e: IOException) { throw GeneralSecurityException("malformed private key", e) }
            if (f[0].size != 1 || f[0][0] != KEY_VERSION) throw GeneralSecurityException("unsupported key version")
            if (f[1].size != 32) throw GeneralSecurityException("bad X25519 key")
            return HybridPrivateKey(f[1], f[2], HybridPublicKey.decode(f[3]))
        }
    }
}

class HybridKeyPair(val pub: HybridPublicKey, val priv: HybridPrivateKey)

/**
 * Hybrid KEM: the shared secret is secure if EITHER X25519 (classical) OR ML-KEM-768 (post-quantum) holds.
 * Secret = HKDF-SHA256(ikm = ssMLKEM || ssX25519, salt = label,
 *                      info = ephemeralX25519 || recipientX25519 || ctMLKEM || SHA256(recipientMLKEMpk)).
 * ML-KEM classes come from Bouncy Castle >= 1.84 (org.bouncycastle.crypto.{params,generators,kems}).
 */
object HybridKem {
    const val MLKEM768_PK = 1184
    const val MLKEM768_CT = 1088
    private val LABEL = "ShieldBrowser/HybridKEM/v1 X25519+ML-KEM-768".toByteArray(Charsets.US_ASCII)
    private val PARAMS: MLKEMParameters get() = MLKEMParameters.ml_kem_768

    class Encapsulation(val ephX25519: ByteArray, val mlkemCt: ByteArray)

    fun generate(random: SecureRandom = SecureRandom()): HybridKeyPair {
        val x = X25519PrivateKeyParameters(random)
        val xPub = x.generatePublicKey().encoded
        val gen = MLKEMKeyPairGenerator()
        gen.init(MLKEMKeyGenerationParameters(random, PARAMS))
        val kp = gen.generateKeyPair()
        val mPub = (kp.public as MLKEMPublicKeyParameters).encoded
        val mPriv = (kp.private as MLKEMPrivateKeyParameters).encoded
        val pub = HybridPublicKey(xPub, mPub)
        return HybridKeyPair(pub, HybridPrivateKey(x.encoded, mPriv, pub))
    }

    /** Returns the encapsulation to send plus the 32-byte shared secret (caller wipes it). */
    fun encapsulate(to: HybridPublicKey, random: SecureRandom = SecureRandom()): Pair<Encapsulation, ByteArray> {
        val eph = X25519PrivateKeyParameters(random)
        val ephPub = eph.generatePublicKey().encoded
        val agr = X25519Agreement()
        agr.init(eph)
        val ssX = ByteArray(agr.agreementSize)
        agr.calculateAgreement(X25519PublicKeyParameters(to.x25519, 0), ssX, 0)
        val swe = MLKEMGenerator(random).generateEncapsulated(MLKEMPublicKeyParameters(PARAMS, to.mlkem))
        val ssM = swe.secret
        val ctM = swe.encapsulation
        val key = combine(ssM, ssX, ctM, ephPub, to)
        Wire.wipe(ssX, ssM)
        return Pair(Encapsulation(ephPub, ctM), key)
    }

    fun decapsulate(priv: HybridPrivateKey, enc: Encapsulation): ByteArray {
        if (enc.ephX25519.size != 32 || enc.mlkemCt.size != MLKEM768_CT) throw GeneralSecurityException("bad encapsulation")
        val agr = X25519Agreement()
        agr.init(X25519PrivateKeyParameters(priv.x25519, 0))
        val ssX = ByteArray(agr.agreementSize)
        agr.calculateAgreement(X25519PublicKeyParameters(enc.ephX25519, 0), ssX, 0)
        val ssM = MLKEMExtractor(MLKEMPrivateKeyParameters(PARAMS, priv.mlkem)).extractSecret(enc.mlkemCt)
        val key = combine(ssM, ssX, enc.mlkemCt, enc.ephX25519, priv.pub)
        Wire.wipe(ssX, ssM)
        return key
    }

    private fun combine(ssM: ByteArray, ssX: ByteArray, ctM: ByteArray, ephX: ByteArray, recipient: HybridPublicKey): ByteArray {
        val ikm = ssM + ssX
        val info = LABEL + ephX + recipient.x25519 + ctM + Kdf.sha256(recipient.mlkem)
        val key = Kdf.hkdf(ikm, LABEL, info, 32)
        ikm.fill(0)
        return key
    }
}
