package com.shieldbrowser.app.browser

/** Turns what the user typed into a URL or a search. Pure Kotlin. */
object UrlInput {
    sealed class Resolved {
        data class Url(val url: String) : Resolved()
        data class Search(val query: String, val url: String) : Resolved()
    }

    private val schemeRegex = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:")
    private val hostRegex = Regex(
        "^(localhost|\\d{1,3}(\\.\\d{1,3}){3}|\\[[0-9a-fA-F:]+\\]|([\\p{L}\\p{N}-]+\\.)+[\\p{L}\\p{N}-]{2,})(:\\d{1,5})?([/?#].*)?$"
    )
    private val allowedSchemes = setOf("http", "https", "shield")

    fun resolve(raw: String, searchTemplate: String): Resolved {
        val t = raw.trim()
        fun search() = Resolved.Search(t, SearchEngines.searchUrl(searchTemplate, t))
        if (t.isEmpty() || t.any { it.isWhitespace() }) return search()
        val sm = schemeRegex.find(t)
        if (sm != null && t.startsWith(sm.value + "//")) {
            val scheme = sm.value.dropLast(1).lowercase()
            return if (scheme in allowedSchemes) Resolved.Url(t) else search()
        }
        if (t == "about:blank") return Resolved.Url(t)
        if (sm != null && !hostRegex.matches(t)) return search()   // javascript:, data:, mailto: typed by hand → search
        if (hostRegex.matches(t)) {
            val host = t.substringBefore('/').substringBefore('?').substringBefore('#').substringBefore(':')
            val plain = host == "localhost" || host.all { it.isDigit() || it == '.' }
            return Resolved.Url((if (plain) "http://" else "https://") + t)
        }
        return search()
    }

    fun displayUrl(url: String): String =
        url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')
}
