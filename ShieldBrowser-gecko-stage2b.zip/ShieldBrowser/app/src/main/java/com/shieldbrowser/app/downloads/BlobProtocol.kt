package com.shieldbrowser.app.downloads

import java.net.URLDecoder

/**
 * Wire format between assets/js/blob_fetch.js and [BlobDownloadManager]. Pure Kotlin (unit-tested on the JVM).
 *
 *   page → app   M|sid|size|type|name   metadata (type/name percent-encoded)
 *                C|sid|seq|base64       one chunk, in order
 *                D|sid                  finished
 *                E|sid|message          failed
 *   app → page   <sid>:go | <sid>:ack | <sid>:abort
 */
object BlobProtocol {
    const val CHUNK_BYTES = 192 * 1024
    /** A full chunk in base64 plus the "C|sid|seq|" header; anything longer is rejected before parsing. */
    const val MAX_MESSAGE_CHARS = 4 * ((CHUNK_BYTES + 2) / 3) + 128
    private const val MAX_NAME = 255
    private const val MAX_TYPE = 100

    sealed class Msg {
        abstract val sid: String
        data class Meta(override val sid: String, val size: Long, val type: String, val name: String) : Msg()
        class Chunk(override val sid: String, val seq: Int, val b64: String) : Msg()
        data class Done(override val sid: String) : Msg()
        data class Failed(override val sid: String, val reason: String) : Msg()
    }

    private val sidRegex = Regex("^[0-9a-f]{32}$")

    fun isValidSid(s: String): Boolean = sidRegex.matches(s)

    fun parse(raw: String?): Msg? {
        if (raw == null || raw.length < 4 || raw.length > MAX_MESSAGE_CHARS || raw[1] != '|') return null
        val rest = raw.substring(2)
        when (raw[0]) {
            'M' -> {
                val p = rest.split('|', limit = 4)
                if (p.size != 4 || !isValidSid(p[0])) return null
                val size = p[1].toLongOrNull() ?: return null
                if (size < 0) return null
                return Msg.Meta(p[0], size, decode(p[2], MAX_TYPE), decode(p[3], MAX_NAME))
            }
            'C' -> {
                val p = rest.split('|', limit = 3)
                if (p.size != 3 || !isValidSid(p[0])) return null
                val seq = p[1].toIntOrNull() ?: return null
                if (seq < 0 || p[2].isEmpty()) return null
                return Msg.Chunk(p[0], seq, p[2])
            }
            'D' -> return if (isValidSid(rest)) Msg.Done(rest) else null
            'E' -> {
                val p = rest.split('|', limit = 2)
                if (!isValidSid(p[0])) return null
                return Msg.Failed(p[0], decode(if (p.size > 1) p[1] else "", 120))
            }
            else -> return null
        }
    }

    private fun decode(s: String, max: Int): String {
        if (s.length > max * 12) return ""                  // longer than any legitimate percent-encoded value
        return try { URLDecoder.decode(s, "UTF-8").take(max) } catch (_: Exception) { "" }
    }

    /** "blob:https://host:port/uuid" → "https://host" (default ports removed). Opaque origins (blob:null/…) → null. */
    fun originOf(blobUrl: String): String? {
        if (!blobUrl.startsWith("blob:", ignoreCase = true)) return null
        val m = Regex("^(https?)://([^/?#]+)", RegexOption.IGNORE_CASE).find(blobUrl.substring(5)) ?: return null
        return normalizeOrigin(m.groupValues[1], m.groupValues[2])
    }

    fun normalizeOrigin(scheme: String, authority: String): String {
        val s = scheme.lowercase()
        var a = authority.lowercase()
        if ((s == "https" && a.endsWith(":443")) || (s == "http" && a.endsWith(":80"))) a = a.substringBeforeLast(':')
        return "$s://$a"
    }

    /** Compares the origin of a blob URL with the origin reported by WebMessageListener for the message sender. */
    fun sameOrigin(blobOrigin: String, senderOrigin: String): Boolean {
        val m = Regex("^(https?)://([^/?#]+)", RegexOption.IGNORE_CASE).find(senderOrigin.trim()) ?: return false
        return normalizeOrigin(m.groupValues[1], m.groupValues[2]) == blobOrigin
    }

    /**
     * Fills the JS template. The URL is substituted LAST so that text inside an attacker-chosen URL
     * (e.g. "%SID%") can never be re-interpreted as a placeholder.
     */
    fun fillTemplate(template: String, url: String, sid: String, quote: (String) -> String): String =
        template.replace("%SID%", quote(sid)).replace("%CHUNK%", CHUNK_BYTES.toString()).replace("%URL%", quote(url))

    fun chooseName(suggested: String, mime: String): String {
        if (suggested.isNotBlank()) return DownloadSafety.sanitizeFileName(suggested)
        return "download." + extensionFor(mime)
    }

    private val extensions = mapOf(
        "application/pdf" to "pdf", "text/plain" to "txt", "text/csv" to "csv", "text/html" to "html",
        "application/json" to "json", "image/png" to "png", "image/jpeg" to "jpg", "image/gif" to "gif",
        "image/webp" to "webp", "image/svg+xml" to "svg", "video/mp4" to "mp4", "video/webm" to "webm",
        "audio/mpeg" to "mp3", "application/zip" to "zip",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" to "xlsx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" to "docx"
    )

    fun extensionFor(mime: String): String = extensions[mime.substringBefore(';').trim().lowercase()] ?: "bin"
}
