package com.shieldbrowser.app.downloads

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R
import com.shieldbrowser.app.ui.centerContent
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.ActivityDownloadsBinding
import com.shieldbrowser.app.databinding.ItemDownloadBinding
import com.shieldbrowser.app.ui.formatSize
import com.shieldbrowser.app.ui.formatWhen
import kotlinx.coroutines.launch
import java.io.File

/** Downloads + File manager: categories, search, sort, pause/resume/cancel, open/share/rename/delete, APK install gate. */
class DownloadsActivity : AppCompatActivity() {
    private lateinit var b: ActivityDownloadsBinding
    private lateinit var adapter: Adapter
    private var category: FileCategory? = null
    private var sort = "date"
    private var latest: List<DownloadItem> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDownloadsBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.search, b.chips.parent as? View, b.recycler.parent as? View)
        b.toolbar.title = getString(R.string.downloads)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.inflateMenu(R.menu.menu_downloads)
        b.toolbar.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                R.id.d_sort_date -> sort = "date"
                R.id.d_sort_name -> sort = "name"
                R.id.d_sort_size -> sort = "size"
                R.id.d_clear -> container.downloads.clearFinished(deleteFiles = false)
            }
            render(); true
        }
        adapter = Adapter()
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.chips.setOnCheckedStateChangeListener { _, ids ->
            category = when (ids.firstOrNull()) {
                R.id.chipVideo -> FileCategory.VIDEO; R.id.chipImage -> FileCategory.IMAGE; R.id.chipDoc -> FileCategory.DOCUMENT
                R.id.chipApk -> FileCategory.APK; R.id.chipArchive -> FileCategory.ARCHIVE; R.id.chipOther -> FileCategory.OTHER
                else -> null
            }
            render()
        }
        b.search.addTextChangedListener { render() }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                container.downloads.items.collect { latest = it; render() }
            }
        }
    }

    private fun render() {
        val q = b.search.text.toString().trim().lowercase()
        var list = latest.filter { (category == null || it.category == category) && (q.isEmpty() || it.fileName.lowercase().contains(q)) }
        list = when (sort) {
            "name" -> list.sortedBy { it.fileName.lowercase() }
            "size" -> list.sortedByDescending { it.totalBytes }
            else -> list.sortedByDescending { it.createdAt }
        }
        adapter.submitList(list)
        b.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ actions
    private fun open(item: DownloadItem) {
        val f = File(item.filePath)
        if (!f.exists()) { Toast.makeText(this, R.string.file_missing, Toast.LENGTH_SHORT).show(); return }
        when {
            DownloadSafety.isApk(item.fileName, item.mime) -> confirmInstall(item, f)
            item.risk == RiskLevel.HIGH && container.settings.warnDangerous ->
                MaterialAlertDialogBuilder(this).setTitle(R.string.risky_file_title)
                    .setMessage(riskText(item)).setPositiveButton(R.string.open_anyway) { _, _ -> view(item, f) }
                    .setNegativeButton(android.R.string.cancel, null).show()
            else -> view(item, f)
        }
    }

    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun view(item: DownloadItem, f: File) {
        val mime = item.mime?.takeIf { it != "application/octet-stream" } ?: "*/*"
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(f), mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: ActivityNotFoundException) { Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show() }
    }

    /** APKs are NEVER installed automatically: show source/size/SHA-256/risk, then hand over to Android's installer. */
    private fun confirmInstall(item: DownloadItem, f: File) {
        val msg = buildString {
            appendLine(getString(R.string.download_file, item.fileName))
            appendLine(getString(R.string.download_source, item.sourceHost ?: "?"))
            appendLine(getString(R.string.download_size, formatSize(f.length())))
            appendLine("SHA-256:\n${item.sha256 ?: "?"}")
            appendLine()
            append("⚠ ").append(getString(R.string.apk_warning))
        }
        MaterialAlertDialogBuilder(this).setTitle(R.string.install_apk_title).setMessage(msg)
            .setPositiveButton(R.string.continue_to_installer) { _, _ ->
                if (!packageManager.canRequestPackageInstalls()) {
                    Toast.makeText(this, R.string.allow_unknown_sources, Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(f), "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    } catch (_: ActivityNotFoundException) {}
                }
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun share(item: DownloadItem) {
        val f = File(item.filePath)
        if (!f.exists()) return
        val i = Intent(Intent.ACTION_SEND).setType(item.mime ?: "*/*").putExtra(Intent.EXTRA_STREAM, uriFor(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, null))
    }

    private fun rename(item: DownloadItem) {
        val input = EditText(this).apply { setText(item.fileName); setSingleLine(); setSelection(0, item.fileName.substringBeforeLast('.').length) }
        MaterialAlertDialogBuilder(this).setTitle(R.string.rename).setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                if (!container.downloads.rename(item.id, input.text.toString())) Toast.makeText(this, R.string.rename_failed, Toast.LENGTH_SHORT).show()
            }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun details(item: DownloadItem) {
        val msg = buildString {
            appendLine(getString(R.string.download_file, item.fileName))
            appendLine(getString(R.string.download_source, item.sourceHost ?: "?"))
            appendLine(getString(R.string.download_size, formatSize(item.totalBytes)))
            appendLine(item.url)
            if (item.sha256 != null) appendLine("\nSHA-256:\n${item.sha256}")
            if (item.risk != RiskLevel.LOW) append("\n").append(riskText(item))
            if (item.error != null) append("\n").append(item.error)
        }
        MaterialAlertDialogBuilder(this).setTitle(R.string.details).setMessage(msg).setPositiveButton(android.R.string.ok, null).show()
    }

    private fun riskText(item: DownloadItem): String =
        getString(if (item.risk == RiskLevel.HIGH) R.string.risk_high else R.string.risk_medium) + "\n" +
            item.riskReasons.joinToString("\n") { "• " + reasonText(it) }

    private fun reasonText(key: String): String = getString(
        when (key) {
            "apk" -> R.string.risk_apk; "executable" -> R.string.risk_executable; "active_content" -> R.string.risk_active
            "double_extension" -> R.string.risk_double_ext; "mime_mismatch" -> R.string.risk_mime
            "unknown_type" -> R.string.risk_unknown; "insecure_source" -> R.string.risk_http; "rtl_override" -> R.string.risk_rtl
            else -> R.string.risk_unknown
        }
    )

    private fun more(item: DownloadItem, anchor: View) {
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        if (item.state == DownloadState.COMPLETED) {
            m.add(0, 1, 0, R.string.open); m.add(0, 2, 1, R.string.share); m.add(0, 3, 2, R.string.rename)
            if (item.isPrivate) m.add(0, 4, 3, R.string.keep_download)
        }
        if (item.isActive) m.add(0, 5, 0, R.string.cancel)
        m.add(0, 6, 5, R.string.details)
        m.add(0, 7, 6, R.string.delete_file)
        m.add(0, 8, 7, R.string.remove_from_list)
        pm.setOnMenuItemClickListener { mi ->
            val d = container.downloads
            when (mi.itemId) {
                1 -> open(item); 2 -> share(item); 3 -> rename(item)
                4 -> if (!d.keepPrivate(item.id)) Toast.makeText(this, R.string.rename_failed, Toast.LENGTH_SHORT).show()
                5 -> d.cancel(item.id); 6 -> details(item); 7 -> d.delete(item.id, true); 8 -> d.delete(item.id, false)
            }
            true
        }
        pm.show()
    }

    // ------------------------------------------------------------------ adapter
    private inner class Adapter : ListAdapter<DownloadItem, Adapter.VH>(object : DiffUtil.ItemCallback<DownloadItem>() {
        override fun areItemsTheSame(a: DownloadItem, b: DownloadItem) = a.id == b.id
        override fun areContentsTheSame(a: DownloadItem, b: DownloadItem) = a == b
    }) {
        inner class VH(val v: ItemDownloadBinding) : RecyclerView.ViewHolder(v.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemDownloadBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            val it = getItem(position)
            val v = h.v
            v.name.text = it.fileName
            v.letter.text = it.fileName.substringAfterLast('.', "?").take(4).uppercase()
            val risk = if (it.risk == RiskLevel.LOW) "" else "  ·  ⚠ " + getString(if (it.risk == RiskLevel.HIGH) R.string.risk_high_short else R.string.risk_medium_short)
            v.info.text = when (it.state) {
                DownloadState.RUNNING, DownloadState.QUEUED -> buildString {
                    append(formatSize(it.downloadedBytes)); if (it.totalBytes > 0) append(" / ").append(formatSize(it.totalBytes))
                    if (it.speedBps > 0) append("  ·  ").append(formatSize(it.speedBps)).append("/s")
                    if (it.etaSeconds >= 0) append("  ·  ").append(DateUtils.formatElapsedTime(it.etaSeconds))
                }
                DownloadState.PAUSED -> getString(R.string.paused) + "  ·  " + formatSize(it.downloadedBytes)
                DownloadState.COMPLETED -> formatSize(it.totalBytes) + "  ·  " + (it.sourceHost ?: "") + "  ·  " + formatWhen(it.createdAt) + (if (it.isPrivate) "  ·  🕶" else "") + risk
                DownloadState.FAILED -> getString(R.string.failed) + (it.error?.let { e -> ": $e" } ?: "")
                DownloadState.CANCELED -> getString(R.string.canceled)
            }
            val showBar = it.state == DownloadState.RUNNING || it.state == DownloadState.QUEUED || it.state == DownloadState.PAUSED
            v.bar.visibility = if (showBar) View.VISIBLE else View.GONE
            if (it.progress >= 0) { v.bar.isIndeterminate = false; v.bar.setProgressCompat(it.progress, false) } else v.bar.isIndeterminate = it.isActive
            when (it.state) {
                DownloadState.RUNNING, DownloadState.QUEUED -> {
                    v.btnAction.visibility = View.VISIBLE
                    if (it.isBlob) {         // blob: downloads stream from the page and cannot be paused: offer cancel instead
                        v.btnAction.setImageResource(R.drawable.ic_close)
                        v.btnAction.setOnClickListener { _ -> container.downloads.cancel(it.id) }
                    } else {
                        v.btnAction.setImageResource(R.drawable.ic_pause)
                        v.btnAction.setOnClickListener { _ -> container.downloads.pause(it.id) }
                    }
                }
                DownloadState.PAUSED, DownloadState.FAILED -> {
                    if (it.isBlob) v.btnAction.visibility = View.GONE          // cannot be resumed: the bytes lived in the page
                    else {
                        v.btnAction.visibility = View.VISIBLE
                        v.btnAction.setImageResource(R.drawable.ic_play)
                        v.btnAction.setOnClickListener { _ -> container.downloads.resume(it.id) }
                    }
                }
                else -> v.btnAction.visibility = View.GONE
            }
            v.root.setOnClickListener { _ -> if (it.state == DownloadState.COMPLETED) open(it) }
            v.btnMore.setOnClickListener { a -> more(it, a) }
        }
    }
}
