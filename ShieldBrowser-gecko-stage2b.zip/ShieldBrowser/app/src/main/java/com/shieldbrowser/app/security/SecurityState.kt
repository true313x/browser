package com.shieldbrowser.app.security

enum class SecurityState { NONE, INTERNAL, SECURE, INSECURE, WARNING }
