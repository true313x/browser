package com.shieldbrowser.app.blocking

/**
 * Parses blocklists into domain rules. Supported (domain-level only, by design):
 *  - hosts files:           `0.0.0.0 ads.example.com`
 *  - plain domain lists:    `ads.example.com`
 *  - ABP domain anchors:    `||ads.example.com^` (path/wildcard/option rules are skipped)
 *  - built-in format:       `ads.example.com advertising`
 * Cosmetic filters, regex rules and exceptions are NOT supported and are counted as skipped.
 */
object RuleListParser {
    data class Result(val domains: Map<String, BlockCategory>, val skipped: Int)

    private val domainRegex = Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")
    private val abpDomain = Regex("""^\|\|([a-z0-9.-]+)\^([$].*)?$""")
    private val ws = Regex("\\s+")

    fun parseDomains(text: String, defaultCategory: BlockCategory): Result {
        val out = HashMap<String, BlockCategory>()
        var skipped = 0
        for (raw in text.lineSequence()) {
            var line = raw.trim().lowercase()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("!") || line.startsWith("[")) continue
            val hash = line.indexOf(" #")
            if (hash > 0) line = line.substring(0, hash).trim()
            var domain: String? = null
            var cat = defaultCategory
            val parts = line.split(ws)
            when {
                line.startsWith("||") -> domain = abpDomain.find(line)?.groupValues?.get(1)
                parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> domain = parts[1]
                parts.size == 1 -> domain = parts[0]
                parts.size == 2 -> { domain = parts[0]; cat = BlockCategory.fromKey(parts[1]) }
            }
            if (domain != null && domainRegex.matches(domain) && !DomainUtils.isIpLiteral(domain)) {
                out[domain] = cat
            } else skipped++
        }
        return Result(out, skipped)
    }
}
