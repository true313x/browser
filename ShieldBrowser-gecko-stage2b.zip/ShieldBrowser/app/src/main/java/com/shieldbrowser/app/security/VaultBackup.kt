package com.shieldbrowser.app.security

import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.bookmarks.BookmarkKind
import com.shieldbrowser.app.crypto.HybridPrivateKey
import com.shieldbrowser.app.crypto.Kdf
import com.shieldbrowser.app.crypto.SealedBox
import org.json.JSONArray
import org.json.JSONObject
import java.security.GeneralSecurityException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Encrypted export/import of bookmarks + settings (".shieldvault").
 *  - Confidentiality: SealedBox to the device's hybrid public key (X25519 + ML-KEM-768).
 *  - Authenticity: the public key is public, so ANYONE could seal a file to it. Therefore the payload carries an
 *    HMAC-SHA256 whose key is derived from the PRIVATE key; a forged backup (e.g. phishing bookmarks, weakened
 *    settings) fails the check and is refused.
 * History, downloads and cookies are intentionally not exported.
 */
object VaultBackup {
    private val CONTEXT = "shieldbrowser.vault.v1".toByteArray()
    private val MAC_INFO = "vault-mac.v1".toByteArray()
    /** Open-tab URLs can carry tokens; they never go into a backup. */
    private val NEVER_EXPORT = setOf("gecko_session")

    class Result(val bookmarks: Int, val settings: Int)

    private fun macKey(priv: HybridPrivateKey): ByteArray = Kdf.hkdf(priv.encode(), "shield".toByteArray(), MAC_INFO, 32)

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray =
        Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(key, "HmacSHA256")) }.doFinal(data)

    /** Opens the sealed box and checks the authenticity tag; returns the JSON bytes. */
    private fun openAndVerify(priv: HybridPrivateKey, blob: ByteArray): ByteArray {
        val plain = SealedBox.open(priv, blob, CONTEXT)
        if (plain.size <= 32) throw GeneralSecurityException("empty backup")
        val tag = plain.copyOfRange(0, 32)
        val json = plain.copyOfRange(32, plain.size)
        if (!java.security.MessageDigest.isEqual(tag, hmac(macKey(priv), json))) throw GeneralSecurityException("backup is not authentic")
        return json
    }

    suspend fun export(c: AppContainer): ByteArray {
        val root = JSONObject().put("v", 1).put("created", System.currentTimeMillis())
        val bms = JSONArray()
        for (kind in intArrayOf(BookmarkKind.BOOKMARK, BookmarkKind.READING_LIST)) {
            for (b in c.bookmarks.list(kind)) {
                bms.put(JSONObject().put("u", b.url).put("t", b.title).put("k", b.kind).put("c", b.createdAt))
            }
        }
        root.put("bookmarks", bms)
        val prefs = JSONArray()
        for ((k, v) in c.settings.prefs.all) {
            if (k.startsWith("internal_") || k in NEVER_EXPORT) continue
            val e = JSONObject().put("k", k)
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> e.put("t", "S").put("v", JSONArray(v.filterIsInstance<String>()))
                else -> continue
            }
            prefs.put(e)
        }
        root.put("prefs", prefs)
        val json = root.toString().toByteArray(Charsets.UTF_8)
        val pub = c.keyVault.hybridPublicKey()
        val tag = c.keyVault.withPrivateKey { hmac(macKey(it), json) }
        return SealedBox.seal(pub, tag + json, CONTEXT)
    }

    /**
     * [priv] = a private key imported from a recovery file (restore on a NEW device); null = use this device's key.
     * @throws GeneralSecurityException for a wrong key, a damaged file or a forged backup.
     */
    suspend fun restore(c: AppContainer, blob: ByteArray, priv: HybridPrivateKey?): Result {
        val json: ByteArray =
            if (priv != null) openAndVerify(priv, blob)
            else c.keyVault.withPrivateKey { openAndVerify(it, blob) }
        val root = try { JSONObject(String(json, Charsets.UTF_8)) } catch (e: Exception) { throw GeneralSecurityException("damaged backup", e) }
        var nb = 0
        val bms = root.optJSONArray("bookmarks") ?: JSONArray()
        for (i in 0 until bms.length()) {
            val o = bms.optJSONObject(i) ?: continue
            val url = o.optString("u")
            if (!(url.startsWith("https://") || url.startsWith("http://"))) continue     // never import javascript:/file:/intent: ...
            val kind = if (o.optInt("k") == BookmarkKind.READING_LIST) BookmarkKind.READING_LIST else BookmarkKind.BOOKMARK
            c.bookmarks.add(url, o.optString("t"), kind); nb++
        }
        var ns = 0
        val ps = root.optJSONArray("prefs") ?: JSONArray()
        val ed = c.settings.prefs.edit()
        for (i in 0 until ps.length()) {
            val e = ps.optJSONObject(i) ?: continue
            val k = e.optString("k")
            if (k.isEmpty() || k.startsWith("internal_") || k in NEVER_EXPORT) continue
            when (e.optString("t")) {
                "b" -> ed.putBoolean(k, e.optBoolean("v"))
                "i" -> ed.putInt(k, e.optInt("v"))
                "l" -> ed.putLong(k, e.optLong("v"))
                "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                "s" -> ed.putString(k, e.optString("v"))
                "S" -> { val a = e.optJSONArray("v") ?: continue; ed.putStringSet(k, (0 until a.length()).map { a.optString(it) }.toSet()) }
                else -> continue
            }
            ns++
        }
        ed.apply()
        return Result(nb, ns)
    }
}
