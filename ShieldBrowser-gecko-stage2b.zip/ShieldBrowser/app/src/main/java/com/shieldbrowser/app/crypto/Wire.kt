package com.shieldbrowser.app.crypto

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException

/** Length-prefixed (u32, big-endian) byte fields. Pure JVM, no Android classes. */
internal object Wire {
    fun pack(vararg parts: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        val out = DataOutputStream(bos)
        for (p in parts) { out.writeInt(p.size); out.write(p) }
        out.flush()
        return bos.toByteArray()
    }

    /** Reads exactly [count] fields; rejects truncated input, absurd lengths and trailing bytes. */
    fun unpack(data: ByteArray, count: Int): List<ByteArray> {
        val inp = DataInputStream(ByteArrayInputStream(data))
        val res = ArrayList<ByteArray>(count)
        repeat(count) {
            if (inp.available() < 4) throw IOException("truncated")
            val n = inp.readInt()
            if (n < 0 || n > inp.available()) throw IOException("bad field length")
            val b = ByteArray(n)
            inp.readFully(b)
            res.add(b)
        }
        if (inp.available() != 0) throw IOException("trailing bytes")
        return res
    }

    fun wipe(vararg arrays: ByteArray?) { for (a in arrays) a?.fill(0) }
}
