package com.shieldbrowser.app.storage

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.util.Log
import net.zetetic.database.sqlcipher.SQLiteDatabase
import java.io.File

/**
 * Local store (history, bookmarks, per-site rules, downloads list), encrypted with SQLCipher (AES-256).
 * The key is a random 256-bit key derived from the Keystore-wrapped master key ([com.shieldbrowser.app.security.KeyVault]).
 * Nothing here ever leaves the device. `PRAGMA secure_delete` is on so deleted rows are overwritten.
 *
 *  - First start after the update: an existing plaintext shield.db is copied table by table into an encrypted file,
 *    verified (row counts), and only then replaced; the plaintext file is overwritten with random bytes. If anything
 *    fails the app keeps using the plaintext file (no data loss) and retries next start ([isEncrypted] tells which).
 *  - If the key is gone (Keystore reset/restore on a new phone) the unreadable file is replaced by an empty database
 *    instead of crashing at launch ([recoveredFromKeyLoss]).
 *  - [key] == null (tests, or a device whose Keystore is unusable) opens an unencrypted database.
 *  - name == null opens an in-memory database (instrumented tests).
 */
class AppDatabase(context: Context, private val name: String? = "shield.db", private val key: String? = null) {
    private val appContext = context.applicationContext
    @Volatile private var db: SQLiteDatabase? = null

    @Volatile private var encrypted = false
    @Volatile private var keyLost = false

    /** True when the file on disk is SQLCipher-encrypted. Opens the database first: the answer is only known after opening. */
    val isEncrypted: Boolean get() { database(); return encrypted }

    /** True when the key was gone and the unreadable database had to be replaced by an empty one. */
    val recoveredFromKeyLoss: Boolean get() { database(); return keyLost }

    val writableDatabase: SQLiteDatabase get() = database()
    val readableDatabase: SQLiteDatabase get() = database()

    fun close() { synchronized(this) { try { db?.close() } catch (_: Exception) { }; db = null } }

    private fun database(): SQLiteDatabase = db ?: synchronized(this) { db ?: open().also { db = it } }

    // ------------------------------------------------------------------------------------------ opening
    private fun open(): SQLiteDatabase {
        loadNative()
        if (name == null) return create(":memory:", key ?: "")
        val file = appContext.getDatabasePath(name).also { it.parentFile?.mkdirs() }
        val k = key
        if (k == null) return create(file.path, "").also { encrypted = false }

        if (file.exists() && isPlaintext(file)) {
            val migrated = try { migrate(file, k) } catch (e: Throwable) { Log.w(TAG, "encryption migration failed, staying on the plaintext file", e); false }
            if (!migrated) return create(file.path, "").also { encrypted = false }
        }
        return try {
            create(file.path, k).also { encrypted = true }
        } catch (e: Throwable) {
            Log.w(TAG, "cannot open the encrypted database (key lost?): starting empty", e)
            deleteWithSidecars(file)
            keyLost = true
            create(file.path, k).also { encrypted = true }
        }
    }

    private fun create(path: String, password: String): SQLiteDatabase {
        val d = SQLiteDatabase.openOrCreateDatabase(path, password, null, null, null)
        try {
            try { d.rawQuery("PRAGMA secure_delete = ON", null).use { it.moveToFirst() } } catch (_: Exception) { }
            val version = d.rawQuery("PRAGMA user_version", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }   // fails on a wrong key
            if (version == 0) {
                d.beginTransaction()
                try { createSchema(d); d.setTransactionSuccessful() } finally { d.endTransaction() }
                d.execSQL("PRAGMA user_version = $VERSION")
            }
            return d
        } catch (e: Throwable) {
            try { d.close() } catch (_: Exception) { }
            throw e
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, " +
                "title TEXT NOT NULL DEFAULT '', visited_at INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_history_time ON history(visited_at DESC)")
        db.execSQL("CREATE INDEX idx_history_url ON history(url)")
        db.execSQL(
            "CREATE TABLE bookmarks (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, " +
                "title TEXT NOT NULL DEFAULT '', kind INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, " +
                "is_read INTEGER NOT NULL DEFAULT 0, UNIQUE(url, kind))"
        )
        db.execSQL(
            "CREATE TABLE site_settings (host TEXT PRIMARY KEY, shield INTEGER NOT NULL DEFAULT 1, " +
                "js INTEGER NOT NULL DEFAULT -1, cookies INTEGER NOT NULL DEFAULT -1, popups INTEGER NOT NULL DEFAULT -1, " +
                "camera INTEGER NOT NULL DEFAULT -1, mic INTEGER NOT NULL DEFAULT -1, location INTEGER NOT NULL DEFAULT -1, " +
                "notifications INTEGER NOT NULL DEFAULT -1, clipboard INTEGER NOT NULL DEFAULT -1, " +
                "downloads INTEGER NOT NULL DEFAULT -1, autoplay INTEGER NOT NULL DEFAULT -1, fingerprint INTEGER NOT NULL DEFAULT -1)"
        )
        db.execSQL(
            "CREATE TABLE downloads (id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, file_name TEXT NOT NULL, " +
                "file_path TEXT NOT NULL, mime TEXT, total_bytes INTEGER NOT NULL DEFAULT -1, " +
                "downloaded_bytes INTEGER NOT NULL DEFAULT 0, state INTEGER NOT NULL, created_at INTEGER NOT NULL, " +
                "sha256 TEXT, source_host TEXT, risk TEXT, error TEXT)"
        )
    }

    // ------------------------------------------------------------------------------------------ plaintext -> encrypted
    private fun isPlaintext(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(16); it.read(b) == 16 && String(b, Charsets.ISO_8859_1).startsWith("SQLite format 3") }
    } catch (_: Exception) { false }

    private fun migrate(plain: File, k: String): Boolean {
        val tmp = File(plain.parentFile, plain.name + ".enc.tmp")
        val bak = File(plain.parentFile, plain.name + ".plain.bak")
        deleteWithSidecars(tmp); deleteWithSidecars(bak)
        val src = SQLiteDatabase.openOrCreateDatabase(plain.path, "", null, null, null)
        var ok = false
        try {
            val dst = try { create(tmp.path, k) } catch (e: Throwable) { throw e }
            try {
                dst.beginTransaction()
                try {
                    for (t in TABLES) copyTable(src, dst, t)
                    dst.setTransactionSuccessful()
                } finally { dst.endTransaction() }
                ok = TABLES.all { count(src, it) == count(dst, it) }
            } finally { dst.close() }
        } finally { src.close() }
        if (!ok) { deleteWithSidecars(tmp); return false }

        // swap files; at every step the data exists in at least one complete file
        sidecars(plain).forEach { shred(it) }
        if (!plain.renameTo(bak)) { deleteWithSidecars(tmp); return false }
        if (!tmp.renameTo(plain)) { bak.renameTo(plain); deleteWithSidecars(tmp); return false }
        shred(bak)
        return true
    }

    private fun copyTable(src: SQLiteDatabase, dst: SQLiteDatabase, table: String) {
        src.rawQuery("SELECT * FROM $table", null).use { c ->
            val cols = c.columnNames
            while (c.moveToNext()) {
                val cv = ContentValues()
                for (i in cols.indices) when (c.getType(i)) {
                    Cursor.FIELD_TYPE_NULL -> cv.putNull(cols[i])
                    Cursor.FIELD_TYPE_INTEGER -> cv.put(cols[i], c.getLong(i))
                    Cursor.FIELD_TYPE_FLOAT -> cv.put(cols[i], c.getDouble(i))
                    Cursor.FIELD_TYPE_BLOB -> cv.put(cols[i], c.getBlob(i))
                    else -> cv.put(cols[i], c.getString(i))
                }
                dst.insertWithOnConflict(table, null, cv, CONFLICT_REPLACE)
            }
        }
    }

    private fun count(d: SQLiteDatabase, table: String): Long =
        d.rawQuery("SELECT COUNT(*) FROM $table", null).use { if (it.moveToFirst()) it.getLong(0) else -1L }

    private fun sidecars(f: File) = listOf(File(f.path + "-wal"), File(f.path + "-shm"), File(f.path + "-journal")).filter { it.exists() }

    private fun deleteWithSidecars(f: File) { sidecars(f).forEach { it.delete() }; f.delete() }

    /** Overwrites with random bytes, then deletes (best effort; flash wear-levelling may keep old blocks). */
    private fun shred(f: File) {
        try {
            if (f.exists()) {
                val len = f.length(); val rnd = java.security.SecureRandom(); val buf = ByteArray(8192)
                f.outputStream().use { o -> var left = len; while (left > 0) { rnd.nextBytes(buf); val n = minOf(left, buf.size.toLong()).toInt(); o.write(buf, 0, n); left -= n } }
            }
        } catch (_: Exception) { }
        f.delete()
    }

    companion object {
        private const val TAG = "ShieldDb"
        private const val VERSION = 1
        /** android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE */
        private const val CONFLICT_REPLACE = 5
        private val TABLES = listOf("history", "bookmarks", "site_settings", "downloads")
        @Volatile private var nativeLoaded = false

        private fun loadNative() {
            if (nativeLoaded) return
            synchronized(AppDatabase::class.java) { if (!nativeLoaded) { System.loadLibrary("sqlcipher"); nativeLoaded = true } }
        }

        /** Escapes LIKE wildcards; use with `ESCAPE '\'`. */
        fun likeArg(q: String): String =
            "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    }
}
