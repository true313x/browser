package com.shieldbrowser.app.browser

import android.app.Activity
import android.content.Context
import android.content.MutableContextWrapper
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.security.Interstitials
import com.shieldbrowser.app.security.SecurityState
import com.shieldbrowser.app.tabs.TabList
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean

/**
 * App-scoped tab manager. It outlives the Activity (WebViews are created with a MutableContextWrapper whose base
 * context is swapped on attach/detach), so rotation / theme / language changes never lose tabs — including private ones.
 */
class TabManager(private val app: Context, private val c: AppContainer) {
    val list = TabList()
    private val runtime = LinkedHashMap<Long, BrowserTab>()
    private val main = Handler(Looper.getMainLooper())
    private val random = SecureRandom()
    private val statsPending = AtomicBoolean(false)
    @Volatile private var statsTab: BrowserTab? = null
    private val maxLiveWebViews = 5

    @Volatile var host: BrowserHost? = null
        private set
    @Volatile private var activity: Activity? = null

    val configurator = WebViewConfigurator(app, c, this)
    val bridge = ScriptBridge(this)

    // ------------------------------------------------------------------ attach / detach
    fun attach(h: BrowserHost, a: Activity) {
        host = h; activity = a
        runtime.values.forEach { it.ctxWrapper?.baseContext = a }
    }

    fun detach(h: BrowserHost) {
        if (host !== h) return
        host = null; activity = null
        runtime.values.forEach { t ->
            t.webView?.let { (it.parent as? ViewGroup)?.removeView(it) }
            t.ctxWrapper?.baseContext = app
        }
    }

    fun uiContext(): Context = activity ?: app

    // ------------------------------------------------------------------ lookup
    fun tab(id: Long): BrowserTab? = runtime[id]
    fun active(): BrowserTab? = list.active()?.let { runtime[it.id] }
    fun all(): List<BrowserTab> = list.tabs.mapNotNull { runtime[it.id] }
    fun findTab(wv: WebView): BrowserTab? = runtime.values.firstOrNull { it.webView === wv }
    val privateIsolated: Boolean get() = c.profiles.supported

    fun newNonce(tab: BrowserTab): String {
        val b = ByteArray(12); random.nextBytes(b)
        val n = b.joinToString("") { "%02x".format(it) }
        tab.nonce = n
        return n
    }

    // ------------------------------------------------------------------ tab lifecycle
    fun newTab(url: String? = null, isPrivate: Boolean = false, select: Boolean = true, openerId: Long? = null, blank: Boolean = false): BrowserTab {
        val data = list.open(url ?: "", isPrivate, afterId = openerId, select = select)
        val tab = BrowserTab(data)
        tab.openerId = openerId
        tab.needsLoad = !blank
        if (blank && openerId != null) {          // popups must share the opener's profile
            tab.profileName = runtime[openerId]?.profileName
            tab.profileLocked = true
        }
        runtime[data.id] = tab
        if (select) selectInternal(tab, null)
        host?.onTabsChanged()
        return tab
    }

    fun select(id: Long) {
        val prev = active()
        if (!list.select(id)) return
        val tab = runtime[id] ?: return
        selectInternal(tab, prev)
        host?.onTabsChanged()
    }

    private fun selectInternal(tab: BrowserTab, prev: BrowserTab?) {
        if (prev != null && prev !== tab) prev.webView?.onPause()
        ensureLoaded(tab)
        tab.webView?.onResume()
        tab.lastActiveAt = System.currentTimeMillis()
        trim()
        host?.onActiveTabChanged()
    }

    fun closeTab(id: Long) {
        val tab = runtime[id]
        val wasActive = list.activeId == id
        val data = list.close(id) ?: return
        runtime.remove(id)
        if (tab != null) {
            // Prefer returning to the tab that opened this popup.
            val opener = tab.openerId?.let { runtime[it] }
            if (wasActive && opener != null && list.get(opener.id) != null) list.select(opener.id)
            destroy(tab, deleteProfile = true)
        }
        if (list.tabs.isEmpty()) newTab(null, false)
        else if (wasActive) list.active()?.let { a -> runtime[a.id]?.let { selectInternal(it, null) } }
        if (data.isPrivate && list.count(true) == 0) endPrivateSession()
        host?.onTabsChanged()
    }

    fun closeAll(privateOnly: Boolean?) {
        val victims = list.tabs.filter { privateOnly == null || it.isPrivate == privateOnly }.map { it.id }
        victims.forEach { id ->
            runtime.remove(id)?.let { destroy(it, deleteProfile = true) }
            list.close(id)
        }
        if (list.tabs.isEmpty()) newTab(null, false)
        else if (list.active() == null) list.tabs.first().let { list.select(it.id) }
        list.active()?.let { a -> runtime[a.id]?.let { selectInternal(it, null) } }
        if (list.count(true) == 0) endPrivateSession()
        host?.onTabsChanged()
    }

    fun duplicate(id: Long) {
        val src = runtime[id] ?: return
        val data = list.duplicate(id) ?: return
        val tab = BrowserTab(data)
        runtime[data.id] = tab
        selectInternal(tab, src)
        host?.onTabsChanged()
    }

    fun restoreClosed(): BrowserTab? {
        val data = list.restoreClosed() ?: return null
        val tab = BrowserTab(data)
        runtime[data.id] = tab
        selectInternal(tab, null)
        host?.onTabsChanged()
        return tab
    }

    /** Wipes ALL private state: tabs, the private profile (cookies/storage/cache), private downloads. */
    fun endPrivateSession(createReplacement: Boolean = true) {
        val hadTabs = list.tabs.isNotEmpty()
        list.tabs.filter { it.isPrivate }.map { it.id }.forEach { id ->
            runtime.remove(id)?.let { destroy(it, deleteProfile = false) }
            list.close(id)
        }
        c.profiles.deleteLater(ProfileManager.PRIVATE_PROFILE, canDelete = { list.count(true) == 0 })
        c.downloads.clearPrivate()
        if (hadTabs && list.tabs.isEmpty() && createReplacement) newTab(null, false)
        else if (list.active() == null && list.tabs.isNotEmpty()) list.select(list.tabs.first().id)
        host?.onTabsChanged()
    }

    /** Real "exit": persists normal tabs, then frees every WebView and wipes strict-isolation profiles. */
    fun shutdown() {
        persistSession()
        runtime.values.toList().forEach { destroy(it, deleteProfile = true) }
        runtime.clear()
        list.closeAll(null)
    }

    // ------------------------------------------------------------------ WebView creation / disposal
    fun webViewFor(tab: BrowserTab): WebView = tab.webView ?: create(tab)

    private fun create(tab: BrowserTab): WebView {
        val w = MutableContextWrapper(activity ?: app)
        val wv = WebView(w)
        tab.ctxWrapper = w
        tab.webView = wv
        if (!tab.profileLocked) tab.profileName = c.profiles.profileNameFor(tab, c.settings.strictIsolation)
        c.profiles.apply(wv, tab.profileName)            // must precede any other WebView call
        configurator.configure(tab, wv)
        return wv
    }

    private fun ensureLoaded(tab: BrowserTab) {
        val wv = webViewFor(tab)
        if (!tab.needsLoad) return
        tab.needsLoad = false
        val saved = tab.savedState
        val url = tab.data.url
        when {
            saved != null -> { tab.savedState = null; wv.restoreState(saved) }
            url.isBlank() -> {
                val home = c.settings.homepage
                if (!tab.isPrivate && (home.startsWith("https://") || home.startsWith("http://"))) loadUrl(tab, home) else showStart(tab)
            }
            url.startsWith("shield://") -> showStart(tab)
            else -> loadUrl(tab, url)
        }
    }

    private fun destroy(tab: BrowserTab, deleteProfile: Boolean) {
        c.blobs.onTabGone(tab.id)
        try { tab.scriptHandler?.remove() } catch (_: Throwable) {}
        tab.scriptHandler = null
        try { tab.blobScriptHandler?.remove() } catch (_: Throwable) {}
        tab.blobScriptHandler = null
        val wv = tab.webView ?: return
        tab.webView = null
        try {
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.stopLoading()
            wv.webChromeClient = null
            wv.removeAllViews()
            wv.destroy()
        } catch (_: Throwable) {}
        val name = tab.profileName
        if (deleteProfile && name != null && name.startsWith(ProfileManager.ISOLATED_PREFIX) && !tab.profileLocked) {
            c.profiles.deleteLater(name)
        }
    }

    /** Keeps memory low: only the most recently used WebViews stay alive; the rest are frozen to a Bundle. */
    private fun trim() {
        val live = runtime.values.filter { it.webView != null && it.id != list.activeId }.sortedBy { it.lastActiveAt }
        val excess = live.size - (maxLiveWebViews - 1)
        if (excess <= 0) return
        live.take(excess).forEach { t ->
            val b = Bundle()
            t.webView?.saveState(b)
            t.savedState = b
            t.needsLoad = true
            destroy(t, deleteProfile = false)
        }
    }

    fun onRenderGone(tab: BrowserTab) {
        destroy(tab, deleteProfile = false)
        tab.needsLoad = true
        tab.savedState = null
        host?.toast(uiContext().getString(R.string.renderer_crashed))
        if (tab.id == list.activeId) selectInternal(tab, null)
    }

    // ------------------------------------------------------------------ navigation
    fun navigate(tab: BrowserTab, input: String) {
        val template = SearchEngines.template(c.settings.searchEngineId, c.settings.searchCustomUrl)
        when (val r = UrlInput.resolve(input, template)) {
            is UrlInput.Resolved.Url -> loadUrl(tab, r.url)
            is UrlInput.Resolved.Search -> loadUrl(tab, r.url)
        }
    }

    fun loadUrl(tab: BrowserTab, rawUrl: String) {
        if (rawUrl.startsWith("shield://") || rawUrl.isBlank()) { showStart(tab); return }
        val out = c.navPolicy.apply(tab, rawUrl)
        out.events.forEach { record(tab, it) }
        val h = DomainUtils.hostOf(out.url)
        val wv = webViewFor(tab)
        tab.needsLoad = false
        tab.lastTouchAt = System.currentTimeMillis()      // navigation started by the user counts as a gesture
        applySiteSettings(tab, h)
        tab.data.url = out.url
        tab.internalPage = false
        wv.loadUrl(out.url)
    }

    fun showStart(tab: BrowserTab) {
        val ctx = uiContext()
        val engine = SearchEngines.builtIns.firstOrNull { it.id == c.settings.searchEngineId }?.name ?: "Custom"
        val html = Interstitials.startPage(ctx, newNonce(tab), engine, tab.isPrivate)
        tab.pendingUrl = null
        loadInternal(tab, html, "shield://start", SecurityState.INTERNAL)
        tab.data.title = ""
    }

    fun loadInternal(tab: BrowserTab, html: String, displayUrl: String, security: SecurityState) {
        val wv = webViewFor(tab)
        tab.needsLoad = false
        tab.internalPage = true
        tab.forcedSecurity = security
        tab.security = security
        tab.data.url = displayUrl
        tab.pageHost = null
        // Internal pages run without JS (they need none).
        wv.settings.javaScriptEnabled = false
        wv.loadDataWithBaseURL(Interstitials.INTERNAL_BASE, html, "text/html", "utf-8", null)
    }

    fun applySiteSettings(tab: BrowserTab, host: String?) {
        tab.webView?.let { configurator.applySite(tab, it, host) }
    }

    // ------------------------------------------------------------------ stats
    fun record(tab: BrowserTab, e: BlockEvent, n: Int = 1) {
        tab.stats.record(e, n)
        c.sessionReport.record(e, n)
        notifyStats(tab)
    }

    fun notifyStats(tab: BrowserTab) {
        statsTab = tab                                   // always report the most recent tab, never a stale one
        if (statsPending.compareAndSet(false, true)) {
            main.postDelayed({ statsPending.set(false); statsTab?.let { host?.onStats(it) } }, 300)
        }
    }

    fun logRequest(tab: BrowserTab, r: WebResourceRequest) {
        tab.pushLog(tab.requestLog, "${r.method} ${r.url}${if (r.isForMainFrame) "  [main-frame]" else ""}")
    }

    // ------------------------------------------------------------------ bulk updates (settings changed)
    fun refreshScripts() {
        configurator.invalidateScript()
        runtime.values.forEach { t -> t.webView?.let { configurator.registerScripts(t, it) } }
    }

    fun applyPrefsAll() {
        runtime.values.forEach { t -> t.webView?.let { configurator.applyGlobal(t, it) } }
        refreshScripts()
    }

    fun reloadActive() { active()?.webView?.reload() }

    // ------------------------------------------------------------------ session persistence (normal tabs only)
    fun persistSession() {
        if (!c.settings.historyEnabled) { c.settings.sessionJson = ""; return }
        val normals = list.tabs.filter { !it.isPrivate && it.url.isNotBlank() }
        val arr = JSONArray()
        normals.forEach { arr.put(JSONObject().put("u", it.url).put("t", it.title)) }
        val idx = normals.indexOfFirst { it.id == list.activeId }.coerceAtLeast(0)
        c.settings.sessionJson = JSONObject().put("tabs", arr).put("active", idx).toString()
    }

    fun restoreSession(): Boolean {
        val json = c.settings.sessionJson
        if (json.isBlank() || list.tabs.isNotEmpty()) return false
        return try {
            val o = JSONObject(json)
            val arr = o.getJSONArray("tabs")
            val items = (0 until arr.length()).map { i ->
                val t = arr.getJSONObject(i)
                Triple(t.getString("u"), t.optString("t", ""), null as Long?)
            }.filter { it.first.startsWith("http://") || it.first.startsWith("https://") }
            if (items.isEmpty()) return false
            list.restore(items, o.optInt("active", 0))
            list.tabs.forEach { d -> if (runtime[d.id] == null) runtime[d.id] = BrowserTab(d) }
            true
        } catch (_: Exception) { false }
    }
}
