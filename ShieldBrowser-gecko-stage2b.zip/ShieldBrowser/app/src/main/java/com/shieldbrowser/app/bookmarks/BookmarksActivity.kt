package com.shieldbrowser.app.bookmarks

import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.shieldbrowser.app.R
import com.shieldbrowser.app.ui.centerContent
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.ActivityListBinding
import com.shieldbrowser.app.ui.Entry
import com.shieldbrowser.app.ui.EntryAdapter
import com.shieldbrowser.app.ui.openInBrowser
import kotlinx.coroutines.launch

/** Bookmarks + Reading list (two tabs). */
class BookmarksActivity : AppCompatActivity() {
    private lateinit var b: ActivityListBinding
    private lateinit var adapter: EntryAdapter
    private var kind = BookmarkKind.BOOKMARK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.tabs, b.search, b.recycler.parent as? View)
        b.toolbar.title = getString(R.string.bookmarks)
        b.toolbar.setNavigationOnClickListener { finish() }
        b.tabs.visibility = View.VISIBLE
        b.tabs.addTab(b.tabs.newTab().setText(R.string.bookmarks))
        b.tabs.addTab(b.tabs.newTab().setText(R.string.reading_list))
        b.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) { kind = tab.position; load() }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        adapter = EntryAdapter(
            onClick = { e ->
                if (kind == BookmarkKind.READING_LIST) lifecycleScope.launch { container.bookmarks.setRead(e.id, true) }
                openInBrowser(e.key)
            },
            onMore = { e, anchor ->
                PopupMenu(this, anchor).apply {
                    menu.add(0, 1, 0, R.string.delete)
                    if (kind == BookmarkKind.READING_LIST) menu.add(0, 2, 1, R.string.mark_read)
                    setOnMenuItemClickListener { m ->
                        lifecycleScope.launch {
                            if (m.itemId == 1) container.bookmarks.delete(e.id) else container.bookmarks.setRead(e.id, true)
                            load()
                        }
                        true
                    }
                }.show()
            }
        )
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.search.addTextChangedListener { load() }
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            val items = container.bookmarks.list(kind, b.search.text.toString())
            adapter.submit(items.map {
                Entry(it.id, (if (kind == BookmarkKind.READING_LIST && it.read) "✓ " else "") + it.title, it.url.removePrefix("https://"), it.url)
            })
            b.empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
