package com.shieldbrowser.app.security

import com.shieldbrowser.app.blocking.DomainUtils
import java.net.IDN

/**
 * Pure (JVM-testable) payment-page logic: is this a payment context, and does the address look like phishing?
 * It never sees page content, card numbers or form values.
 */
object PaymentGuard {
    enum class Issue {
        NOT_HTTPS, CREDENTIALS_IN_URL, IP_HOST, PUNYCODE, MIXED_SCRIPTS, NON_STANDARD_PORT, LOOKALIKE,
        CERT_EXCEPTION, CONNECTION_NOT_SECURE
    }

    /** Issues that make a Secure Payment tab refuse to continue; the others only warn. */
    val BLOCKING: Set<Issue> = setOf(Issue.NOT_HTTPS, Issue.CREDENTIALS_IN_URL, Issue.CERT_EXCEPTION, Issue.CONNECTION_NOT_SECURE)

    class Verdict(val isPaymentContext: Boolean, val issues: List<Issue>, val lookalikeOf: String?) {
        val blocked: Boolean get() = issues.any { it in BLOCKING }
        val clean: Boolean get() = issues.isEmpty()
    }

    private class Brand(val label: String, val domains: Set<String>, val anySuffix: Boolean = false)

    private val BRANDS = listOf(
        Brand("paypal", setOf("paypal.com", "paypal.me", "paypalobjects.com")),
        Brand("stripe", setOf("stripe.com", "stripe.network", "stripecdn.com")),
        Brand("adyen", setOf("adyen.com", "adyenpayments.com")),
        Brand("braintree", setOf("braintreegateway.com", "braintreepayments.com")),
        Brand("worldpay", setOf("worldpay.com")),
        Brand("klarna", setOf("klarna.com", "klarna.net")),
        Brand("razorpay", setOf("razorpay.com")),
        Brand("mastercard", setOf("mastercard.com")),
        Brand("moyasar", setOf("moyasar.com")),
        Brand("hyperpay", setOf("hyperpay.com")),
        Brand("paytabs", emptySet(), anySuffix = true),
        Brand("myfatoorah", emptySet(), anySuffix = true),
        Brand("fawry", emptySet(), anySuffix = true),
        Brand("paymob", emptySet(), anySuffix = true),
        Brand("payfort", emptySet(), anySuffix = true),
        Brand("tabby", setOf("tabby.ai", "tabby.sa")),
        Brand("tamara", setOf("tamara.co")),
        Brand("telr", setOf("telr.com"))
    )

    /** Registrable domains of payment providers / 3-D Secure vendors. A page of one of these is a payment context. */
    val PSP_DOMAINS: Set<String> = setOf(
        "stripe.com", "paypal.com", "adyen.com", "checkout.com", "braintreegateway.com", "worldpay.com", "klarna.com",
        "razorpay.com", "moyasar.com", "hyperpay.com", "paytabs.com", "tap.company", "myfatoorah.com", "telr.com",
        "fawry.com", "paymob.com", "tabby.ai", "tamara.co", "payfort.com", "2checkout.com", "squareup.com",
        "cardinalcommerce.com", "mastercard.com", "visa.com", "americanexpress.com", "pay.google.com"
    )

    private val PATH_WORDS = setOf(
        "checkout", "payment", "payments", "pay", "billing", "3ds", "3dsecure", "3d-secure", "secure-payment",
        "payment-method", "paymentmethod", "cashier"
    )
    private val LOOKALIKE_WORDS = setOf(
        "secure", "login", "signin", "verify", "verification", "account", "support", "wallet", "billing", "payment",
        "pay", "online", "service", "update", "security", "help", "refund"
    )

    fun looksLikePaymentUrl(url: String): Boolean {
        val host = DomainUtils.hostOf(url) ?: return false
        if (DomainUtils.registrableDomain(host) in PSP_DOMAINS) return true
        val path = url.substringAfter("://").substringAfter('/', "").substringBefore('?').substringBefore('#')
        return path.lowercase().split('/').any { it in PATH_WORDS }
    }

    /**
     * @param secure TLS state of the page; null = not reported yet (Gecko sends the location BEFORE the security info,
     *        so "unknown" must never be treated as "insecure").
     * @param fieldSignal true when the page itself exposed card fields (autocomplete=cc-number ...), reported by the
     *        built-in extension without any field content.
     */
    fun assess(url: String, secure: Boolean?, certException: Boolean, fieldSignal: Boolean): Verdict {
        val ctx = fieldSignal || looksLikePaymentUrl(url)
        val issues = ArrayList<Issue>()
        val scheme = DomainUtils.schemeOf(url)
        val authority = url.substringAfter("://", "").substringBefore('/').substringBefore('?').substringBefore('#')
        val host = DomainUtils.hostOf(url).orEmpty()

        if (scheme != "https") issues.add(Issue.NOT_HTTPS)
        else if (secure == false) issues.add(Issue.CONNECTION_NOT_SECURE)
        if (certException) issues.add(Issue.CERT_EXCEPTION)
        if ('@' in authority) issues.add(Issue.CREDENTIALS_IN_URL)
        if (host.isNotEmpty()) {
            if (DomainUtils.isIpLiteral(host)) issues.add(Issue.IP_HOST)
            if (host.split('.').any { it.startsWith("xn--") } || host.any { it.code > 127 }) issues.add(Issue.PUNYCODE)
            if (mixedScripts(host)) issues.add(Issue.MIXED_SCRIPTS)
            val port = authority.substringAfterLast('@').substringAfterLast(':', "")
            if (port.isNotEmpty() && !host.startsWith("[") && port != "443" && port.all { it.isDigit() }) issues.add(Issue.NON_STANDARD_PORT)
        }
        val look = if (host.isNotEmpty() && !DomainUtils.isIpLiteral(host)) lookalikeOf(host) else null
        if (look != null) issues.add(Issue.LOOKALIKE)
        return Verdict(ctx, issues, look)
    }

    /** True when one label mixes scripts (e.g. Latin + Cyrillic), the classic homograph trick. Pure single-script IDNs pass. */
    fun mixedScripts(host: String): Boolean {
        val unicode = try { IDN.toUnicode(host) } catch (_: Exception) { host }
        for (label in unicode.split('.')) {
            val scripts = HashSet<Character.UnicodeScript>()
            var i = 0
            while (i < label.length) {
                val cp = label.codePointAt(i)
                if (Character.isLetter(cp)) {
                    val sc = Character.UnicodeScript.of(cp)
                    if (sc != Character.UnicodeScript.COMMON && sc != Character.UnicodeScript.INHERITED) scripts.add(sc)
                }
                i += Character.charCount(cp)
            }
            if (scripts.size > 1) return true
        }
        return false
    }

    /** The brand this host imitates (paypal.com.evil.net, paypa1.com, secure-paypal.com ...), or null. */
    fun lookalikeOf(host: String): String? {
        val reg = DomainUtils.registrableDomain(host)
        val label = reg.substringBefore('.')
        for (b in BRANDS) if (reg in b.domains || (b.anySuffix && label == b.label)) return null     // it IS the brand
        val sub = host.removeSuffix(reg).trimEnd('.')
        val subTokens = sub.split('.', '-').filter { it.isNotEmpty() }
        val tokens = label.split('-').filter { it.isNotEmpty() }
        val norm = confusables(label)
        for (b in BRANDS) {
            val bl = b.label
            if (bl in subTokens) return bl                                                    // paypal.com.evil.net
            if (tokens.size > 1 && bl in tokens) return bl                                     // secure-paypal.com
            if (norm == bl) return bl                                                          // paypa1.com, paypaI.com
            if (label.length > bl.length && (label.startsWith(bl) || label.endsWith(bl))) {
                val rest = if (label.startsWith(bl)) label.removePrefix(bl) else label.removeSuffix(bl)
                if (rest in LOOKALIKE_WORDS) return bl                                         // paypalsecure.com
            }
            if (bl.length >= 6 && norm != bl && levenshtein(norm, bl) == 1) return bl          // paypall.com, stripee.com
        }
        return null
    }

    private fun confusables(s: String): String {
        var r = s.lowercase()
        r = r.replace("rn", "m").replace("vv", "w")
        return r.map {
            when (it) { '0' -> 'o'; '1' -> 'l'; '3' -> 'e'; '5' -> 's'; '4' -> 'a'; '7' -> 't'; else -> it }
        }.joinToString("")
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    /** Domain to show in large type on payment pages: the part users must check. */
    fun displayDomain(url: String): String = DomainUtils.hostOf(url)?.let { DomainUtils.registrableDomain(it) } ?: ""
}
