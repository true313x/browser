package com.shieldbrowser.app.security

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R

/**
 * The sealed environment. Declared with android:process=":sealed": a separate, secrets-free process that never
 * touches AppContainer, the database, the keys, GeckoView or the network. It only shows a lock screen and offers
 * (a) owner unlock through the system biometric/PIN prompt, (b) a full reset. It deliberately never shows why it
 * was triggered.
 */
class SealedActivity : AppCompatActivity() {
    private lateinit var unlockBtn: MaterialButton
    private lateinit var resetBtn: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        if (!SealedMode.isSealed(this)) { finishAndRemoveTask(); return }

        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(px(32), px(32), px(32), px(32))
            setBackgroundColor(Color.parseColor("#0B0F14"))
        }
        col.addView(TextView(this).apply { text = "\uD83D\uDD12"; textSize = 56f; gravity = Gravity.CENTER })
        col.addView(TextView(this).apply {
            text = getString(R.string.sealed_title); textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, px(16), 0, px(8))
        })
        col.addView(TextView(this).apply {
            text = getString(R.string.sealed_msg); textSize = 15f; setTextColor(Color.parseColor("#B8C2CC")); gravity = Gravity.CENTER
            setPadding(0, 0, 0, px(28))
        })
        unlockBtn = MaterialButton(this).apply {
            text = getString(R.string.sealed_unlock); isEnabled = false
            setOnClickListener { unlock() }
        }
        resetBtn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.sealed_reset); isEnabled = false
            setOnClickListener { confirmReset() }
        }
        col.addView(unlockBtn)
        col.addView(resetBtn)
        if (!AppLock.available(this)) {
            col.addView(TextView(this).apply {
                text = getString(R.string.sealed_no_lock); textSize = 13f; setTextColor(Color.parseColor("#E0A458")); gravity = Gravity.CENTER
                setPadding(0, px(16), 0, 0)
            })
        }
        setContentView(col)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })

        // The wipe must finish before the owner can go back, otherwise the engine would start into a half-deleted profile.
        Thread {
            SealedWiper.wipeIfPending(applicationContext)
            runOnUiThread { unlockBtn.isEnabled = AppLock.available(this); resetBtn.isEnabled = true }
        }.start()
    }

    private fun unlock() {
        AppLock.authenticate(this, getString(R.string.sealed_unlock_title)) { ok ->
            if (ok) returnToBrowser() else Toast.makeText(this, R.string.sealed_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmReset() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.sealed_reset_title).setMessage(R.string.sealed_reset_msg)
            .setPositiveButton(R.string.sealed_reset) { _, _ ->
                unlockBtn.isEnabled = false; resetBtn.isEnabled = false
                Thread { SealedWiper.wipeEverything(applicationContext); runOnUiThread { returnToBrowser() } }.start()
            }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun returnToBrowser() {
        val target = SealedMode.returnActivity(this)
        SealedMode.release(this)
        val launch = try {
            if (target != null) Intent().setClassName(packageName, target) else packageManager.getLaunchIntentForPackage(packageName)
        } catch (_: Exception) { packageManager.getLaunchIntentForPackage(packageName) }
        launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        try { if (launch != null) startActivity(launch) } catch (_: Exception) { }
        finishAndRemoveTask()
    }
}
