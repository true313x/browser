package com.shieldbrowser.app.downloads

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.os.SystemClock
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.network.DnsProvider
import com.shieldbrowser.app.privacy.SessionReport
import com.shieldbrowser.app.settings.BrowserSettings
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * In-app download manager (OkHttp, resumable via HTTP Range, SHA-256 on completion).
 *
 * - Normal downloads: app-specific external storage (no storage permission needed) + a row in SQLite.
 * - Private downloads: app cache dir, in-memory only, wiped when the private session ends unless "kept".
 * - Never installs anything. APKs are just files; installing goes through DownloadsActivity → system installer.
 * - `blob:` downloads: the page's JS streams the bytes to us in chunks (see BlobDownloadManager); they are written
 *   through [beginPush]/[push]/[finishPush]. They cannot be paused/resumed (the bytes live in the page).
 * - Progress notifications + a foreground service are driven by DownloadNotifier from [items].
 * LIMITATIONS: `data:` URLs are not supported; blob downloads need JavaScript and a same-origin main frame.
 */
class DownloadEngine(
    private val context: Context,
    private val db: AppDatabase,
    private val dns: DnsProvider,
    private val scope: CoroutineScope,
    private val settings: BrowserSettings,
    private val report: SessionReport
) {
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val jobs = ConcurrentHashMap<Long, Job>()
    private val calls = ConcurrentHashMap<Long, Call>()
    private val requests = ConcurrentHashMap<Long, DownloadRequest>()
    private val pushes = ConcurrentHashMap<Long, PushHandle>()
    private val privateIds = AtomicLong(-1)

    init { _items.value = loadRows() }

    // ------------------------------------------------------------------ public API
    fun dirFor(isPrivate: Boolean): File {
        val d = if (isPrivate) File(context.cacheDir, "private_downloads")
        else context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(context.filesDir, "downloads")
        d.mkdirs()
        return d
    }

    fun get(id: Long): DownloadItem? = _items.value.firstOrNull { it.id == id }
    fun fileOf(item: DownloadItem) = File(item.filePath)

    fun enqueue(req: DownloadRequest): Long {
        val dir = dirFor(req.isPrivate)
        val name = DownloadSafety.uniqueName(DownloadSafety.sanitizeFileName(req.fileName)) { n ->
            File(dir, n).exists() || File(dir, "$n.part").exists() || _items.value.any { it.filePath == File(dir, n).absolutePath }
        }
        val risk = DownloadSafety.assess(name, req.mime, req.url)
        var item = DownloadItem(
            id = 0, url = req.url, fileName = name, filePath = File(dir, name).absolutePath, mime = req.mime,
            totalBytes = if (req.contentLength > 0) req.contentLength else -1, downloadedBytes = 0,
            state = DownloadState.QUEUED, createdAt = System.currentTimeMillis(),
            sourceHost = DomainUtils.hostOf(req.url), risk = risk.level, riskReasons = risk.reasons, isPrivate = req.isPrivate
        )
        val id = if (req.isPrivate) privateIds.getAndDecrement() else insertRow(item)
        item = item.copy(id = id)
        requests[id] = req
        _items.update { listOf(item) + it }
        report.downloads.incrementAndGet()
        start(id)
        return id
    }

    fun pause(id: Long) {
        val item = get(id) ?: return
        if (item.isBlob || !item.isActive) return          // blob downloads cannot be paused
        update(id) { it.copy(state = DownloadState.PAUSED, speedBps = 0, etaSeconds = -1) }
        stopWork(id)
    }

    fun resume(id: Long) {
        val item = get(id) ?: return
        if (item.isBlob) return                               // the bytes live in the page; start a new download instead
        if (item.state == DownloadState.PAUSED || item.state == DownloadState.FAILED) start(id)
    }

    fun cancel(id: Long) {
        val item = get(id) ?: return
        // A stale "Cancel" button (notification) must not turn a finished download into a cancelled one.
        if (item.state == DownloadState.COMPLETED || item.state == DownloadState.CANCELED) return
        update(id) { it.copy(state = DownloadState.CANCELED, speedBps = 0, etaSeconds = -1) }
        stopWork(id)
        File(item.filePath + ".part").delete()
    }

    /** Cancels the running coroutine AND the blocking OkHttp call (a cancelled job alone would stay stuck in read()). */
    private fun stopWork(id: Long) {
        jobs.remove(id)?.cancel()
        calls.remove(id)?.cancel()
        pushes.remove(id)?.abort()
    }

    fun delete(id: Long, deleteFile: Boolean) {
        val item = get(id) ?: return
        stopWork(id)
        requests.remove(id)
        File(item.filePath + ".part").delete()
        if (deleteFile) File(item.filePath).delete()
        _items.update { l -> l.filter { it.id != id } }
        if (!item.isPrivate) db.writableDatabase.delete("downloads", "id = ?", arrayOf(id.toString()))
    }

    fun rename(id: Long, newName: String): Boolean {
        val item = get(id) ?: return false
        if (item.state != DownloadState.COMPLETED) return false
        val dir = File(item.filePath).parentFile ?: return false
        val clean = DownloadSafety.sanitizeFileName(newName)
        if (clean == item.fileName) return true
        val unique = DownloadSafety.uniqueName(clean) { File(dir, it).exists() }
        val target = File(dir, unique)
        if (!File(item.filePath).renameTo(target)) return false
        val risk = DownloadSafety.assess(unique, item.mime, item.url)
        update(id) { it.copy(fileName = unique, filePath = target.absolutePath, risk = risk.level, riskReasons = risk.reasons) }
        return true
    }

    /** Moves a private download into normal storage ("explicitly saved"). */
    fun keepPrivate(id: Long): Boolean {
        val item = get(id) ?: return false
        if (!item.isPrivate || item.state != DownloadState.COMPLETED) return false
        val dir = dirFor(false)
        val name = DownloadSafety.uniqueName(item.fileName) { File(dir, it).exists() }
        val target = File(dir, name)
        try { File(item.filePath).copyTo(target, overwrite = false); File(item.filePath).delete() } catch (_: Exception) { return false }
        _items.update { l -> l.filter { it.id != id } }
        val kept = item.copy(id = 0, fileName = name, filePath = target.absolutePath, isPrivate = false)
        val newId = insertRow(kept)
        _items.update { listOf(kept.copy(id = newId)) + it }
        return true
    }

    /** End of private session: stop, delete files, forget entries. */
    fun clearPrivate() {
        val priv = _items.value.filter { it.isPrivate }
        priv.forEach { stopWork(it.id); requests.remove(it.id); File(it.filePath).delete(); File(it.filePath + ".part").delete() }
        _items.update { l -> l.filter { !it.isPrivate } }
        try { File(context.cacheDir, "private_downloads").deleteRecursively() } catch (_: Exception) {}
    }

    fun clearFinished(deleteFiles: Boolean) {
        _items.value.filter { !it.isActive && it.state != DownloadState.PAUSED }.forEach { delete(it.id, deleteFiles) }
    }

    // ------------------------------------------------------------------ engine
    private fun start(id: Long) {
        val old = jobs[id]
        old?.cancel()
        calls.remove(id)?.cancel()
        // wait for the previous attempt to finish so two writers never touch the same .part file
        jobs[id] = scope.launch(Dispatchers.IO) { old?.join(); run(id) }
    }

    private suspend fun run(id: Long) {
        val item = get(id) ?: return
        if (item.isBlob) return
        val req = requests[id]
        val target = File(item.filePath)
        val part = File(item.filePath + ".part")
        update(id) { it.copy(state = DownloadState.RUNNING, error = null) }
        try {
            val resumeFrom = if (part.exists()) part.length() else 0L
            val rb = Request.Builder().url(item.url)
            req?.userAgent?.takeIf { it.isNotBlank() }?.let { rb.header("User-Agent", it) }
            req?.cookies?.takeIf { it.isNotBlank() }?.let { rb.header("Cookie", it) }
            req?.referrer?.takeIf { it.isNotBlank() }?.let { rb.header("Referer", it) }
            if (resumeFrom > 0) rb.header("Range", "bytes=$resumeFrom-")
            val newCall = dns.client().newCall(rb.build())
            calls[id] = newCall
            if (!currentCoroutineContext().isActive) newCall.cancel()
            newCall.execute().use { r ->
                if (r.code == 416 && resumeFrom > 0) { part.delete(); throw IOException("Range not satisfiable — press resume to restart") }
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("Empty response")
                val append = resumeFrom > 0 && r.code == 206
                val offset = if (append) resumeFrom else 0L
                val len = body.contentLength()
                val total = if (len >= 0) offset + len else -1L
                var downloaded = offset
                var lastTick = SystemClock.elapsedRealtime()
                var lastBytes = downloaded
                var lastPersist = lastTick
                var speed = 0.0
                FileOutputStream(part, append).use { out ->
                    body.byteStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            downloaded += n
                            val now = SystemClock.elapsedRealtime()
                            if (now - lastTick >= 500) {
                                val inst = (downloaded - lastBytes) * 1000.0 / (now - lastTick)
                                speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
                                val eta = if (total > 0 && speed > 1) ((total - downloaded) / speed).toLong() else -1L
                                val persist = now - lastPersist >= 3000
                                if (persist) lastPersist = now
                                val d = downloaded
                                update(id, persist) { it.copy(downloadedBytes = d, totalBytes = total, speedBps = speed.toLong(), etaSeconds = eta) }
                                lastTick = now; lastBytes = downloaded
                            }
                        }
                    }
                }
            }
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) { part.copyTo(target, overwrite = true); part.delete() }
            val hash = sha256(target)
            update(id) {
                it.copy(state = DownloadState.COMPLETED, downloadedBytes = target.length(), totalBytes = target.length(),
                    sha256 = hash, speedBps = 0, etaSeconds = -1)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (!currentCoroutineContext().isActive) return       // paused / canceled: state already set by caller
            update(id) { it.copy(state = DownloadState.FAILED, error = e.message?.take(160) ?: e.javaClass.simpleName, speedBps = 0, etaSeconds = -1) }
        } finally {
            calls.remove(id)
        }
    }

    // ------------------------------------------------------------------ blob: / pushed downloads
    /** Bytes are pushed by the caller (BlobDownloadManager); at most [MAX_PUSH_BYTES] per download. */
    class PushHandle internal constructor(
        val id: Long,
        internal val part: File,
        internal val target: File,
        internal val out: FileOutputStream,
        internal val expected: Long
    ) {
        @Volatile var cancelled = false
            private set
        @Volatile internal var closed = false
        internal var written = 0L
        internal var lastTick = SystemClock.elapsedRealtime()
        internal var lastBytes = 0L
        internal var speed = 0.0

        internal fun abort() {
            cancelled = true
            closeQuietly()
        }

        internal fun closeQuietly() {
            if (!closed) { closed = true; try { out.close() } catch (_: Exception) { } }
        }
    }

    data class PushRequest(
        val url: String,
        val fileName: String,
        val mime: String?,
        val totalBytes: Long,
        val isPrivate: Boolean
    )

    /** Registers a pushed download (state RUNNING). Returns null if the file cannot be created (e.g. disk full). */
    fun beginPush(req: PushRequest): PushHandle? {
        if (req.totalBytes > MAX_PUSH_BYTES) return null
        val dir = dirFor(req.isPrivate)
        if (req.totalBytes > 0 && dir.usableSpace < req.totalBytes + 32L * 1024 * 1024) return null
        val name = DownloadSafety.uniqueName(DownloadSafety.sanitizeFileName(req.fileName)) { n ->
            File(dir, n).exists() || File(dir, "$n.part").exists() || _items.value.any { it.filePath == File(dir, n).absolutePath }
        }
        val target = File(dir, name)
        val part = File(dir, "$name.part")
        val out = try { FileOutputStream(part, false) } catch (_: Exception) { return null }
        val risk = DownloadSafety.assess(name, req.mime, req.url)
        var item = DownloadItem(
            id = 0, url = req.url, fileName = name, filePath = target.absolutePath, mime = req.mime,
            totalBytes = if (req.totalBytes > 0) req.totalBytes else -1, downloadedBytes = 0,
            state = DownloadState.RUNNING, createdAt = System.currentTimeMillis(),
            sourceHost = DomainUtils.hostOf(req.url), risk = risk.level, riskReasons = risk.reasons, isPrivate = req.isPrivate
        )
        val id = if (req.isPrivate) privateIds.getAndDecrement() else insertRow(item)
        item = item.copy(id = id)
        _items.update { listOf(item) + it }
        report.downloads.incrementAndGet()
        val h = PushHandle(id, part, target, out, req.totalBytes)
        pushes[id] = h
        return h
    }

    /** Appends a chunk. Returns false when the download was cancelled/removed, is over its limit, or the write failed. */
    fun push(h: PushHandle, data: ByteArray): Boolean {
        if (h.cancelled || h.closed) return false
        if (h.written + data.size > MAX_PUSH_BYTES || (h.expected > 0 && h.written + data.size > h.expected)) {
            failPush(h, "Too much data")
            return false
        }
        try {
            h.out.write(data)
        } catch (e: IOException) {
            failPush(h, e.message ?: "Write failed")
            return false
        }
        h.written += data.size
        val now = SystemClock.elapsedRealtime()
        if (now - h.lastTick >= 500) {
            val inst = (h.written - h.lastBytes) * 1000.0 / (now - h.lastTick)
            h.speed = if (h.speed == 0.0) inst else h.speed * 0.7 + inst * 0.3
            val eta = if (h.expected > 0 && h.speed > 1) ((h.expected - h.written) / h.speed).toLong() else -1L
            val w = h.written
            val sp = h.speed.toLong()
            update(h.id, false) { it.copy(downloadedBytes = w, speedBps = sp, etaSeconds = eta) }
            h.lastTick = now; h.lastBytes = h.written
        }
        return true
    }

    fun finishPush(h: PushHandle) {
        pushes.remove(h.id)
        if (h.cancelled) { h.closeQuietly(); h.part.delete(); return }
        h.closeQuietly()
        try {
            if (h.target.exists()) h.target.delete()
            if (!h.part.renameTo(h.target)) { h.part.copyTo(h.target, overwrite = true); h.part.delete() }
            val hash = sha256(h.target)
            update(h.id) {
                it.copy(state = DownloadState.COMPLETED, downloadedBytes = h.target.length(), totalBytes = h.target.length(),
                    sha256 = hash, speedBps = 0, etaSeconds = -1)
            }
        } catch (e: Exception) {
            update(h.id) { it.copy(state = DownloadState.FAILED, error = e.message?.take(160) ?: "I/O error", speedBps = 0, etaSeconds = -1) }
        }
    }

    fun failPush(h: PushHandle, message: String) {
        pushes.remove(h.id)
        h.closeQuietly()
        h.part.delete()
        if (h.cancelled) return                                // user already cancelled: keep the CANCELED state
        update(h.id) { it.copy(state = DownloadState.FAILED, error = message.take(160), speedBps = 0, etaSeconds = -1) }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ------------------------------------------------------------------ state + persistence
    private fun update(id: Long, persist: Boolean = true, f: (DownloadItem) -> DownloadItem) {
        var updated: DownloadItem? = null
        _items.update { list -> list.map { if (it.id == id) f(it).also { u -> updated = u } else it } }
        val u = updated ?: return
        if (persist && !u.isPrivate) writeRow(u)
    }

    private fun values(i: DownloadItem) = ContentValues().apply {
        put("url", i.url); put("file_name", i.fileName); put("file_path", i.filePath); put("mime", i.mime)
        put("total_bytes", i.totalBytes); put("downloaded_bytes", i.downloadedBytes); put("state", i.state.code)
        put("created_at", i.createdAt); put("sha256", i.sha256); put("source_host", i.sourceHost)
        put("risk", i.risk.name + ":" + i.riskReasons.joinToString(",")); put("error", i.error)
    }

    private fun insertRow(i: DownloadItem): Long = db.writableDatabase.insert("downloads", null, values(i))
    private fun writeRow(i: DownloadItem) { db.writableDatabase.update("downloads", values(i), "id = ?", arrayOf(i.id.toString())) }

    private fun loadRows(): List<DownloadItem> {
        val out = ArrayList<DownloadItem>()
        db.readableDatabase.rawQuery(
            "SELECT id,url,file_name,file_path,mime,total_bytes,downloaded_bytes,state,created_at,sha256,source_host,risk,error " +
                "FROM downloads ORDER BY created_at DESC", null
        ).use { c ->
            while (c.moveToNext()) {
                var st = DownloadState.of(c.getInt(7))
                val rowUrl = c.getString(1) ?: ""
                var rowError: String? = c.getString(12)
                if (st == DownloadState.RUNNING || st == DownloadState.QUEUED) {
                    if (DownloadItem.isStreamUrl(rowUrl)) { st = DownloadState.FAILED; rowError = "Interrupted" }   // bytes lived in the page
                    else st = DownloadState.PAUSED
                }
                val riskRaw = c.getString(11) ?: "LOW:"
                val level = RiskLevel.values().firstOrNull { it.name == riskRaw.substringBefore(':') } ?: RiskLevel.LOW
                val reasons = riskRaw.substringAfter(':', "").split(',').filter { it.isNotEmpty() }
                out.add(
                    DownloadItem(
                        c.getLong(0), rowUrl, c.getString(2), c.getString(3), c.getString(4), c.getLong(5), c.getLong(6),
                        st, c.getLong(8), c.getString(9), c.getString(10), level, reasons, rowError
                    )
                )
            }
        }
        return out
    }

    companion object {
        const val MAX_PUSH_BYTES = 2L * 1024 * 1024 * 1024
    }
}
