package com.shieldbrowser.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.ActivityReportBinding
import com.shieldbrowser.app.databinding.ItemStatRowBinding

/** Per-session report. Held in memory only: never written to disk, never sent anywhere. */
class PrivacyReportActivity : AppCompatActivity() {
    private lateinit var b: ActivityReportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityReportBinding.inflate(layoutInflater)
        setContentView(b.root)
        centerContent(b.root.getChildAt(1))
        b.toolbar.setNavigationOnClickListener { finish() }
        b.btnClearReport.setOnClickListener { container.sessionReport.clear(); render() }
        render()
    }

    private fun render() {
        val r = container.sessionReport
        val k = r.counters
        val sites = r.sitesVisited()
        b.reportRows.removeAllViews()
        listOf(
            R.string.rep_sites to sites.size, R.string.stat_trackers to k.trackers.get(), R.string.stat_ads to k.ads.get(),
            R.string.stat_cookies to k.cookies.get(), R.string.rep_dangerous to k.dangerous.get(),
            R.string.stat_fingerprint to k.fingerprint.get(), R.string.stat_mining to k.mining.get(),
            R.string.stat_popups to k.popups.get(), R.string.stat_params to k.params.get(), R.string.rep_downloads to r.downloads.get()
        ).forEach { (label, n) ->
            val rb = ItemStatRowBinding.inflate(LayoutInflater.from(this), b.reportRows, false)
            rb.rowIcon.visibility = android.view.View.GONE
            rb.rowLabel.text = getString(label)
            rb.rowValue.text = n.toString()
            b.reportRows.addView(rb.root)
        }
        b.sitesText.text = if (sites.isEmpty()) getString(R.string.nothing_here) else sites.joinToString("\n")
    }
}
