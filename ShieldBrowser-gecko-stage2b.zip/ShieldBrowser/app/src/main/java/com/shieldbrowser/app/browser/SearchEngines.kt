package com.shieldbrowser.app.browser

import java.net.URLEncoder

data class SearchEngine(val id: String, val name: String, val template: String)

/** Search engines are plain data; switching never requires an app update. Typing is NEVER sent to the engine until you submit. */
object SearchEngines {
    val builtIns = listOf(
        SearchEngine("google", "Google", "https://www.google.com/search?q=%s"),
        SearchEngine("bing", "Bing", "https://www.bing.com/search?q=%s"),
        SearchEngine("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q=%s"),
        SearchEngine("brave", "Brave Search", "https://search.brave.com/search?q=%s"),
        SearchEngine("startpage", "Startpage", "https://www.startpage.com/do/search?q=%s"),
        SearchEngine("ecosia", "Ecosia", "https://www.ecosia.org/search?q=%s")
    )

    fun isValidTemplate(t: String) = t.startsWith("https://") && t.contains("%s") && t.length < 512

    fun template(id: String, customUrl: String): String =
        if (id == "custom" && isValidTemplate(customUrl)) customUrl
        else (builtIns.firstOrNull { it.id == id } ?: builtIns[2]).template

    fun searchUrl(template: String, query: String): String =
        template.replace("%s", URLEncoder.encode(query, "UTF-8"))
}
