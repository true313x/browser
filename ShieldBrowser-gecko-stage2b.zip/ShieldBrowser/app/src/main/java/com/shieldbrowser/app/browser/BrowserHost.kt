package com.shieldbrowser.app.browser

import android.net.Uri
import android.view.View
import android.webkit.HttpAuthHandler
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient

enum class SitePerm { CAMERA, MICROPHONE, LOCATION }
enum class JsDialogKind { ALERT, CONFIRM, PROMPT }

/** UI callbacks implemented by MainActivity. TabManager outlives the activity; `host` is null while detached. */
interface BrowserHost {
    fun onTabsChanged()
    fun onActiveTabChanged()
    fun onTabChanged(tab: BrowserTab)
    fun onProgress(tab: BrowserTab, progress: Int)
    fun onStats(tab: BrowserTab)
    fun toast(message: String, actionLabel: String? = null, action: (() -> Unit)? = null)
    fun requestSitePermissions(tab: BrowserTab, siteHost: String, needs: List<SitePerm>, onResult: (Boolean) -> Unit)
    fun confirmExternal(tab: BrowserTab, label: String, onAllow: () -> Unit)
    fun showJsDialog(tab: BrowserTab, kind: JsDialogKind, host: String, message: String, default: String?, result: JsResult)
    fun launchFileChooser(callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean
    fun showCustomView(view: View, callback: WebChromeClient.CustomViewCallback)
    fun hideCustomView()
    fun onDownloadRequested(tab: BrowserTab, url: String, userAgent: String?, contentDisposition: String?, mime: String?, length: Long)
    fun showLinkMenu(tab: BrowserTab, linkUrl: String?, imageUrl: String?)
    fun promptHttpAuth(tab: BrowserTab, host: String, realm: String, handler: HttpAuthHandler)
    fun promptEnableJs(tab: BrowserTab, host: String)
    /** A blob: download's metadata arrived: apply the normal download policy/dialog, then report accept/reject. */
    fun confirmBlobDownload(tab: BrowserTab, name: String, mime: String?, size: Long, blobUrl: String, onResult: (Boolean) -> Unit)
    /** Result of an in-page search (activeMatchOrdinal is 0-based). */
    fun onFindResult(tab: BrowserTab, activeMatchOrdinal: Int, numberOfMatches: Int, isDoneCounting: Boolean)
}
