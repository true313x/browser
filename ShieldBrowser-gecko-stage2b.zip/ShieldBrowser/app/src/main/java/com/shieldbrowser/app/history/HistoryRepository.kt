package com.shieldbrowser.app.history

import android.content.ContentValues
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

data class HistoryEntry(val id: Long, val url: String, val title: String, val visitedAt: Long)

class HistoryRepository(private val db: AppDatabase) {

    suspend fun add(url: String, title: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val w = db.writableDatabase
        val last = w.rawQuery(
            "SELECT id, visited_at FROM history WHERE url = ? ORDER BY visited_at DESC LIMIT 1", arrayOf(url)
        ).use { if (it.moveToFirst()) it.getLong(0) to it.getLong(1) else null }
        if (last != null && now - last.second < 10 * 60 * 1000L) {
            val cv = ContentValues().apply { put("visited_at", now); if (title.isNotBlank()) put("title", title) }
            w.update("history", cv, "id = ?", arrayOf(last.first.toString()))
        } else {
            val cv = ContentValues().apply { put("url", url); put("title", title); put("visited_at", now) }
            w.insert("history", null, cv)
        }
    }

    suspend fun list(query: String? = null, limit: Int = 300): List<HistoryEntry> = withContext(Dispatchers.IO) {
        val r = db.readableDatabase
        val c = if (query.isNullOrBlank()) {
            r.rawQuery("SELECT id,url,title,visited_at FROM history ORDER BY visited_at DESC LIMIT ?", arrayOf(limit.toString()))
        } else {
            val a = AppDatabase.likeArg(query.trim())
            r.rawQuery(
                "SELECT id,url,title,visited_at FROM history WHERE url LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\' " +
                    "ORDER BY visited_at DESC LIMIT ?", arrayOf(a, a, limit.toString())
            )
        }
        c.use { cur ->
            val out = ArrayList<HistoryEntry>()
            while (cur.moveToNext()) out.add(HistoryEntry(cur.getLong(0), cur.getString(1), cur.getString(2) ?: "", cur.getLong(3)))
            out
        }
    }

    /** Distinct-URL suggestions for the address bar (local only). */
    suspend fun suggest(query: String, limit: Int = 5): List<HistoryEntry> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val a = AppDatabase.likeArg(query.trim())
        db.readableDatabase.rawQuery(
            "SELECT MAX(id),url,title,MAX(visited_at) FROM history WHERE url LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\' " +
                "GROUP BY url ORDER BY MAX(visited_at) DESC LIMIT ?", arrayOf(a, a, limit.toString())
        ).use { cur ->
            val out = ArrayList<HistoryEntry>()
            while (cur.moveToNext()) out.add(HistoryEntry(cur.getLong(0), cur.getString(1), cur.getString(2) ?: "", cur.getLong(3)))
            out
        }
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) { db.writableDatabase.delete("history", "id = ?", arrayOf(id.toString())); Unit }

    suspend fun deleteToday() = withContext(Dispatchers.IO) {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        db.writableDatabase.delete("history", "visited_at >= ?", arrayOf(c.timeInMillis.toString())); Unit
    }

    suspend fun deleteAll() = withContext(Dispatchers.IO) { db.writableDatabase.delete("history", null, null); Unit }

    suspend fun deleteOlderThan(days: Int) = withContext(Dispatchers.IO) {
        if (days <= 0) return@withContext
        val cutoff = System.currentTimeMillis() - days * 86_400_000L
        db.writableDatabase.delete("history", "visited_at < ?", arrayOf(cutoff.toString())); Unit
    }
}
