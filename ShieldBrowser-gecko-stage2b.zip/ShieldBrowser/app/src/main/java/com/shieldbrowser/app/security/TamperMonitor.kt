package com.shieldbrowser.app.security

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.view.inputmethod.InputMethodManager
import com.shieldbrowser.app.BuildConfig
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Local tamper / hostile-environment detection. HONEST LIMIT: every check runs inside a process that an attacker with
 * root or a hooking framework may already control, so this is deterrence and damage limiting, not a guarantee.
 * Its job is to notice the common cases (debugger, Frida/Xposed, repackaged APK, rooted/emulated device) and react
 * before secrets are used, via [SealedMode].
 */
object TamperMonitor {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "tamper-scan").also { it.isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    /** Scans off the main thread and calls [onResult] on the main thread. [forPayment] adds screen/keyboard checks. */
    fun scanAsync(context: Context, forPayment: Boolean, onResult: (Set<TamperSignal>) -> Unit) {
        val app = context.applicationContext
        executor.execute {
            val found = try { scan(app, forPayment) } catch (_: Throwable) { emptySet() }
            main.post { onResult(found) }
        }
    }

    fun scan(context: Context, forPayment: Boolean): Set<TamperSignal> {
        val s = LinkedHashSet<TamperSignal>()
        val release = !BuildConfig.DEBUG

        if (release && (Debug.isDebuggerConnected() || Debug.waitingForDebugger())) s.add(TamperSignal.DEBUGGER)
        if (release && tracerAttached()) s.add(TamperSignal.TRACER)
        if (release && (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) s.add(TamperSignal.DEBUGGABLE_BUILD)
        if (release && signatureMismatch(context)) s.add(TamperSignal.SIGNATURE_MISMATCH)
        if (release && (hookInMaps() || hookThread() || hookFrameInStack())) s.add(TamperSignal.HOOK_FRAMEWORK)
        if (release && fridaPortOpen()) s.add(TamperSignal.INSTRUMENTATION_SERVER)
        if (rootIndicators()) s.add(TamperSignal.ROOT)
        if (IntegrityChecks.looksLikeEmulator(Build.FINGERPRINT, Build.HARDWARE, Build.PRODUCT, Build.MODEL, Build.MANUFACTURER) && release) {
            s.add(TamperSignal.EMULATOR)
        }
        if (forPayment) {
            if (screenReaderAppActive(context)) s.add(TamperSignal.SCREEN_READER_APP)
            if (thirdPartyKeyboard(context)) s.add(TamperSignal.THIRD_PARTY_KEYBOARD)
        }
        return s
    }

    fun critical(signals: Set<TamperSignal>): Set<TamperSignal> = signals.filter { it.severity == Severity.CRITICAL }.toSet()

    // ------------------------------------------------------------------------------------------ individual checks
    private fun readOrEmpty(path: String): String = try { File(path).readText() } catch (_: Exception) { "" }

    private fun tracerAttached(): Boolean = IntegrityChecks.tracerPid(readOrEmpty("/proc/self/status")) > 0

    private fun hookInMaps(): Boolean = IntegrityChecks.hookMarkers(readOrEmpty("/proc/self/maps")).isNotEmpty()

    private fun hookThread(): Boolean {
        val names = try {
            File("/proc/self/task").listFiles()?.map { readOrEmpty("${it.path}/comm") } ?: emptyList()
        } catch (_: Exception) { emptyList() }
        return IntegrityChecks.hookThreads(names).isNotEmpty()
    }

    private fun hookFrameInStack(): Boolean =
        IntegrityChecks.hookFrames(Throwable().stackTrace.map { it.className })

    /** A listening frida-server on this device (default port 27042) means the device is prepared for instrumentation. */
    private fun fridaPortOpen(): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", 27042), 150); true }
    } catch (_: Exception) { false }

    private val SU_PATHS = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/sbin/su", "/vendor/bin/su", "/su/bin/su",
        "/system/app/Superuser.apk", "/data/adb/magisk", "/sbin/.magisk", "/data/adb/ksu", "/data/adb/ap"
    )

    private fun rootIndicators(): Boolean =
        Build.TAGS?.contains("test-keys") == true || SU_PATHS.any { try { File(it).exists() } catch (_: Exception) { false } }

    @Suppress("DEPRECATION")
    private fun signatureMismatch(context: Context): Boolean {
        val expected = BuildConfig.EXPECTED_CERT_SHA256.split(',').map { it.trim().replace(":", "") }.filter { it.isNotEmpty() }
        if (expected.isEmpty()) return false                     // not configured -> no verdict
        return try {
            val pm = context.packageManager
            val digests: List<String> = if (Build.VERSION.SDK_INT >= 28) {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                (info.signingInfo?.apkContentsSigners ?: emptyArray()).map { sha256Hex(it.toByteArray()) }
            } else {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
                (info.signatures ?: emptyArray()).map { sha256Hex(it.toByteArray()) }
            }
            digests.isEmpty() || digests.any { d -> expected.none { IntegrityChecks.sameDigest(d, it) } }
        } catch (_: Exception) { true }
    }

    private fun sha256Hex(b: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private fun screenReaderAppActive(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        return try {
            am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { svc ->
                val reads = (svc.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT) != 0
                val system = (svc.resolveInfo.serviceInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                reads && !system
            }
        } catch (_: Exception) { false }
    }

    private fun thirdPartyKeyboard(context: Context): Boolean {
        return try {
            val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val ime = imm.enabledInputMethodList.firstOrNull { it.id == id } ?: return false
            (ime.serviceInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
        } catch (_: Exception) { false }
    }
}
