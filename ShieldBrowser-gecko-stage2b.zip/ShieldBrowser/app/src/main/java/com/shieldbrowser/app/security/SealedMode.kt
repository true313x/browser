package com.shieldbrowser.app.security

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.Process

/**
 * Sealed Mode = the reaction to a CRITICAL tamper signal.
 *
 *  1. A flag is written synchronously (plain, deliberately unencrypted: it must be readable before anything unlocks).
 *  2. [SealedActivity] is started in its own process (":sealed") that never loads the container, the database, the
 *     keys or GeckoView: there is nothing in it to steal and no network code path.
 *  3. Every other process of the app (main + all Gecko child processes) is killed, so whatever an attacker had
 *     attached to (debugger, Frida, memory dump) loses its target.
 *  4. [SealedWiper] deletes the web sessions (Gecko profile, WebView data, caches, clipboard) once those processes are
 *     gone; with [TamperPolicy.SEAL_WIPE] it also destroys the database, settings and keys.
 *  5. Normal start-up is blocked (ShieldApp skips the container; the browser activities redirect here) until the owner
 *     passes the device biometric/PIN prompt in [SealedActivity].
 *
 * Limits (also in SECURITY.md): an attacker who already has root can modify this app or read other process memory
 * before the signal fires, and can clear the flag; deleting the sessions/keys is what makes that worthless.
 */
object SealedMode {
    private const val FILE = "shield_sealed"
    private const val K_SEALED = "sealed"
    private const val K_AT = "at"
    private const val K_REASON = "reason"
    private const val K_WIPE_ALL = "wipe_all"
    private const val K_WIPED = "wiped"
    private const val K_RETURN = "return"

    internal fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isSealed(context: Context): Boolean = prefs(context).getBoolean(K_SEALED, false)

    internal fun wipeAllRequested(context: Context) = prefs(context).getBoolean(K_WIPE_ALL, false)
    internal fun wiped(context: Context) = prefs(context).getBoolean(K_WIPED, false)
    internal fun markWiped(context: Context) { prefs(context).edit().putBoolean(K_WIPED, true).commit() }
    internal fun returnActivity(context: Context): String? = prefs(context).getString(K_RETURN, null)

    /** Reason codes are kept for the owner's log only; they are never shown on the sealed screen. */
    fun lastReason(context: Context): String? = prefs(context).getString(K_REASON, null)

    /** [returnActivity]: fully-qualified class name to open after a successful unlock. */
    fun trigger(context: Context, signals: Set<TamperSignal>, policy: TamperPolicy, returnActivity: String?) {
        val app = context.applicationContext
        val reason = signals.joinToString(",") { it.name }
        prefs(app).edit().clear()
            .putBoolean(K_SEALED, true).putLong(K_AT, System.currentTimeMillis()).putString(K_REASON, reason)
            .putBoolean(K_WIPE_ALL, policy == TamperPolicy.SEAL_WIPE).putString(K_RETURN, returnActivity)
            .commit()
        try {
            app.startActivity(
                Intent(app, SealedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        } catch (_: Exception) { /* even if this fails, the flag blocks the next start */ }
        Handler(Looper.getMainLooper()).postDelayed({
            SealedWiper.killOtherProcesses(app)
            Process.killProcess(Process.myPid())
        }, 500)
    }

    /** Called after the owner authenticated. */
    fun release(context: Context) { prefs(context).edit().clear().commit() }
}
