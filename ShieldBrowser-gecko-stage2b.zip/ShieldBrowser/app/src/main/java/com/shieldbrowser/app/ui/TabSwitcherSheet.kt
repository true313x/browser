package com.shieldbrowser.app.ui

import android.view.LayoutInflater
import android.widget.EditText
import android.widget.PopupMenu
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.container
import com.shieldbrowser.app.databinding.SheetTabsBinding

/** Tab switcher: search, normal + private tabs, tab groups, duplicate, close, restore closed, close all. */
class TabSwitcherSheet(private val activity: MainActivity) {
    private val c = activity.container
    private val tabs get() = c.tabs

    fun show() {
        val dlg = BottomSheetDialog(activity)
        val v = SheetTabsBinding.inflate(LayoutInflater.from(activity))
        dlg.setContentView(v.root)
        dlg.fitScreen()

        lateinit var adapter: EntryAdapter
        fun refresh() {
            val q = v.tabSearch.text.toString()
            val groups = tabs.list.groups.associateBy { it.id }
            val list = tabs.list.search(q).sortedWith(compareBy({ it.groupId ?: Long.MAX_VALUE }, { it.createdAt })).map { t ->
                val g = t.groupId?.let { groups[it]?.name }
                val title = t.title.ifBlank { t.url.removePrefix("https://").removePrefix("http://").ifBlank { activity.getString(R.string.new_tab) } }
                val sub = (if (t.isPrivate) "🕶 " else "") + (if (g != null) "[$g] " else "") + t.url.removePrefix("https://").removePrefix("http://").ifBlank { activity.getString(R.string.start_page) }
                Entry(t.id, title, sub, t.id.toString())
            }
            adapter.submit(list)
        }
        adapter = EntryAdapter(
            onClick = { e -> tabs.select(e.id); dlg.dismiss() },
            onMore = { e, anchor ->
                val pm = PopupMenu(activity, anchor)
                pm.menu.add(0, 1, 0, R.string.close_tab)
                pm.menu.add(0, 2, 1, R.string.duplicate_tab)
                pm.menu.add(0, 3, 2, R.string.add_to_group)
                if (tabs.list.get(e.id)?.groupId != null) pm.menu.add(0, 4, 3, R.string.remove_from_group)
                pm.setOnMenuItemClickListener { m ->
                    when (m.itemId) {
                        1 -> { tabs.closeTab(e.id); refresh() }
                        2 -> { tabs.duplicate(e.id); dlg.dismiss() }
                        3 -> chooseGroup(e.id) { refresh() }
                        4 -> { tabs.list.assign(e.id, null); refresh() }
                    }
                    true
                }
                pm.show()
            }
        )
        // tablets: two columns (layout-sw600dp/integers.xml)
        val columns = activity.resources.getInteger(R.integer.tab_columns)
        v.tabRecycler.layoutManager = if (columns > 1) GridLayoutManager(activity, columns) else LinearLayoutManager(activity)
        v.tabRecycler.adapter = adapter
        v.tabSearch.addTextChangedListener { refresh() }
        v.btnNewTab.setOnClickListener { tabs.newTab(null, false); dlg.dismiss() }
        v.btnNewPrivate.setOnClickListener { tabs.newTab(null, true); dlg.dismiss() }
        v.btnRestore.setOnClickListener { if (tabs.restoreClosed() != null) dlg.dismiss() else v.btnRestore.isEnabled = false }
        v.btnRestore.isEnabled = tabs.list.recentlyClosed().isNotEmpty()
        v.btnCloseAll.setOnClickListener {
            MaterialAlertDialogBuilder(activity).setMessage(R.string.close_all_confirm)
                .setPositiveButton(R.string.close_all) { _, _ -> tabs.closeAll(null); dlg.dismiss() }
                .setNegativeButton(android.R.string.cancel, null).show()
        }
        refresh()
        dlg.show()
    }

    private fun chooseGroup(tabId: Long, done: () -> Unit) {
        val groups = tabs.list.groups.toList()
        val names = (groups.map { it.name } + activity.getString(R.string.new_group)).toTypedArray()
        MaterialAlertDialogBuilder(activity).setTitle(R.string.add_to_group)
            .setItems(names) { _, which ->
                if (which < groups.size) { tabs.list.assign(tabId, groups[which].id); done() }
                else {
                    val input = EditText(activity).apply { setSingleLine(); hint = activity.getString(R.string.group_name) }
                    MaterialAlertDialogBuilder(activity).setTitle(R.string.new_group).setView(input)
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            val g = tabs.list.createGroup(input.text.toString())
                            tabs.list.assign(tabId, g.id); done()
                        }.setNegativeButton(android.R.string.cancel, null).show()
                }
            }.show()
    }
}
