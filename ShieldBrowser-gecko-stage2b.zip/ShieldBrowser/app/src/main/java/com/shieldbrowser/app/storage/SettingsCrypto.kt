package com.shieldbrowser.app.storage

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Byte-level authenticated cipher used for the settings file (pure JVM interface → unit-testable). */
interface SettingsCipher {
    fun encrypt(plain: ByteArray, aad: ByteArray): ByteArray

    /** Throws when the blob is corrupt, was tampered with, or the key no longer exists. */
    fun decrypt(blob: ByteArray, aad: ByteArray): ByteArray
}

/**
 * AES-256-GCM. Blob layout: [ivLength:1][iv][ciphertext+tag].
 * Works with Android Keystore keys (the Keystore generates the IV) and with plain JCA keys (unit tests).
 */
class AesGcmCipher(private val keyProvider: () -> SecretKey) : SettingsCipher {
    override fun encrypt(plain: ByteArray, aad: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, keyProvider())
        c.updateAAD(aad)
        val iv = c.iv
        val ct = c.doFinal(plain)
        val out = ByteArray(1 + iv.size + ct.size)
        out[0] = iv.size.toByte()
        System.arraycopy(iv, 0, out, 1, iv.size)
        System.arraycopy(ct, 0, out, 1 + iv.size, ct.size)
        return out
    }

    override fun decrypt(blob: ByteArray, aad: ByteArray): ByteArray {
        require(blob.size > 1) { "blob too short" }
        val ivLen = blob[0].toInt() and 0xff
        require(ivLen in 12..16 && blob.size > 1 + ivLen) { "bad iv" }
        val iv = blob.copyOfRange(1, 1 + ivLen)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, keyProvider(), GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return c.doFinal(blob, 1 + ivLen, blob.size - 1 - ivLen)
    }

    /** Round-trips a few bytes; throws if the key store is unusable on this device. */
    fun selfTest() {
        val probe = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val aad = byteArrayOf(9)
        check(decrypt(encrypt(probe, aad), aad).contentEquals(probe)) { "self-test failed" }
    }
}

/** Non-exportable AES key held by the Android Keystore (TEE-backed where the device has one). */
object KeystoreKey {
    private const val PROVIDER = "AndroidKeyStore"

    fun getOrCreate(alias: String): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER)
        ks.load(null)
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun delete(alias: String) {
        try {
            val ks = KeyStore.getInstance(PROVIDER)
            ks.load(null)
            ks.deleteEntry(alias)
        } catch (_: Exception) { }
    }
}

/**
 * Serialises a settings map to bytes. Supported value types: Boolean, Int, Long, Float, String, Set<String>.
 * Hand-rolled binary format (no org.json) so it runs in plain JVM unit tests and has no 64 KB string limit.
 */
object SettingsCodec {
    private const val VERSION = 1
    private const val T_BOOL = 0
    private const val T_INT = 1
    private const val T_LONG = 2
    private const val T_FLOAT = 3
    private const val T_STRING = 4
    private const val T_SET = 5
    private const val MAX_ENTRIES = 100_000
    private const val MAX_STRING_BYTES = 16 * 1024 * 1024

    fun encode(map: Map<String, Any>): ByteArray {
        val bos = ByteArrayOutputStream()
        val out = DataOutputStream(bos)
        out.writeInt(VERSION)
        out.writeInt(map.size)
        for ((k, v) in map) {
            writeString(out, k)
            when (v) {
                is Boolean -> { out.writeByte(T_BOOL); out.writeBoolean(v) }
                is Int -> { out.writeByte(T_INT); out.writeInt(v) }
                is Long -> { out.writeByte(T_LONG); out.writeLong(v) }
                is Float -> { out.writeByte(T_FLOAT); out.writeFloat(v) }
                is String -> { out.writeByte(T_STRING); writeString(out, v) }
                is Set<*> -> {
                    out.writeByte(T_SET)
                    val items = v.filterIsInstance<String>()
                    out.writeInt(items.size)
                    for (s in items) writeString(out, s)
                }
                else -> throw IllegalArgumentException("unsupported type for key $k")
            }
        }
        out.flush()
        return bos.toByteArray()
    }

    fun decode(bytes: ByteArray): MutableMap<String, Any> {
        val inp = DataInputStream(ByteArrayInputStream(bytes))
        val version = inp.readInt()
        if (version != VERSION) throw IOException("unsupported settings version $version")
        val n = inp.readInt()
        if (n < 0 || n > MAX_ENTRIES) throw IOException("bad entry count")
        val map = HashMap<String, Any>()
        repeat(n) {
            val key = readString(inp)
            val value: Any = when (inp.readUnsignedByte()) {
                T_BOOL -> inp.readBoolean()
                T_INT -> inp.readInt()
                T_LONG -> inp.readLong()
                T_FLOAT -> inp.readFloat()
                T_STRING -> readString(inp)
                T_SET -> {
                    val count = inp.readInt()
                    if (count < 0 || count > MAX_ENTRIES) throw IOException("bad set size")
                    val set = HashSet<String>()
                    repeat(count) { set.add(readString(inp)) }
                    set
                }
                else -> throw IOException("unknown value type")
            }
            map[key] = value
        }
        return map
    }

    private fun writeString(out: DataOutputStream, s: String) {
        val b = s.toByteArray(Charsets.UTF_8)
        out.writeInt(b.size)
        out.write(b)
    }

    private fun readString(inp: DataInputStream): String {
        val len = inp.readInt()
        if (len < 0 || len > MAX_STRING_BYTES) throw IOException("bad string length")
        val b = ByteArray(len)
        inp.readFully(b)
        return String(b, Charsets.UTF_8)
    }
}

/**
 * Atomic file store for the settings map.
 *  - cipher != null: file = "SHE1" + AES-GCM blob (header is bound as AAD → swapping/stripping it fails authentication).
 *  - cipher == null: file = "SHP1" + plain bytes. Only used when the device Keystore is unusable; the UI says so.
 */
class EncryptedSettingsStore(private val file: File, private val cipher: SettingsCipher?) {
    data class Loaded(
        val values: MutableMap<String, Any>,
        /** True if a file existed but could not be decrypted/parsed (settings fall back to defaults). */
        val corrupted: Boolean,
        /** True if the file was in the plain format although a cipher is available (caller should re-save). */
        val needsUpgrade: Boolean
    )

    val encrypted: Boolean get() = cipher != null

    fun load(): Loaded {
        if (!file.exists()) return Loaded(HashMap(), corrupted = false, needsUpgrade = false)
        return try {
            val raw = file.readBytes()
            if (raw.size < 5) throw IOException("too short")
            val magic = raw.copyOfRange(0, 4)
            val body = raw.copyOfRange(4, raw.size)
            when {
                magic.contentEquals(MAGIC_ENC) -> {
                    val c = cipher ?: throw IOException("encrypted file but no key available")
                    Loaded(SettingsCodec.decode(c.decrypt(body, MAGIC_ENC)), corrupted = false, needsUpgrade = false)
                }
                magic.contentEquals(MAGIC_PLAIN) -> Loaded(SettingsCodec.decode(body), corrupted = false, needsUpgrade = cipher != null)
                else -> throw IOException("unknown file header")
            }
        } catch (_: Exception) {
            Loaded(HashMap(), corrupted = true, needsUpgrade = false)
        }
    }

    @Throws(IOException::class)
    fun save(map: Map<String, Any>) {
        val plain = SettingsCodec.encode(map)
        val c = cipher
        val payload = if (c != null) MAGIC_ENC + c.encrypt(plain, MAGIC_ENC) else MAGIC_PLAIN + plain
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        FileOutputStream(tmp).use { fos ->
            fos.write(payload)
            fos.flush()
            try { fos.fd.sync() } catch (_: Exception) { }
        }
        if (!tmp.renameTo(file)) {
            file.delete()
            if (!tmp.renameTo(file)) throw IOException("could not replace settings file")
        }
    }

    companion object {
        val MAGIC_ENC = byteArrayOf('S'.code.toByte(), 'H'.code.toByte(), 'E'.code.toByte(), '1'.code.toByte())
        val MAGIC_PLAIN = byteArrayOf('S'.code.toByte(), 'H'.code.toByte(), 'P'.code.toByte(), '1'.code.toByte())
    }
}
