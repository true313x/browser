package com.shieldbrowser.app.bookmarks

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.shieldbrowser.app.storage.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object BookmarkKind {
    const val BOOKMARK = 0
    const val READING_LIST = 1
}

data class Bookmark(val id: Long, val url: String, val title: String, val kind: Int, val createdAt: Long, val read: Boolean)

class BookmarkRepository(private val db: AppDatabase) {

    suspend fun add(url: String, title: String, kind: Int = BookmarkKind.BOOKMARK) = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            put("url", url); put("title", title); put("kind", kind)
            put("created_at", System.currentTimeMillis()); put("is_read", 0)
        }
        db.writableDatabase.insertWithOnConflict("bookmarks", null, cv, SQLiteDatabase.CONFLICT_REPLACE); Unit
    }

    suspend fun remove(url: String, kind: Int) = withContext(Dispatchers.IO) {
        db.writableDatabase.delete("bookmarks", "url = ? AND kind = ?", arrayOf(url, kind.toString())); Unit
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        db.writableDatabase.delete("bookmarks", "id = ?", arrayOf(id.toString())); Unit
    }

    suspend fun contains(url: String, kind: Int = BookmarkKind.BOOKMARK): Boolean = withContext(Dispatchers.IO) {
        db.readableDatabase.rawQuery("SELECT 1 FROM bookmarks WHERE url = ? AND kind = ? LIMIT 1", arrayOf(url, kind.toString()))
            .use { it.moveToFirst() }
    }

    suspend fun setRead(id: Long, read: Boolean) = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply { put("is_read", if (read) 1 else 0) }
        db.writableDatabase.update("bookmarks", cv, "id = ?", arrayOf(id.toString())); Unit
    }

    suspend fun list(kind: Int, query: String? = null): List<Bookmark> = withContext(Dispatchers.IO) {
        val r = db.readableDatabase
        val c = if (query.isNullOrBlank()) {
            r.rawQuery("SELECT id,url,title,kind,created_at,is_read FROM bookmarks WHERE kind = ? ORDER BY created_at DESC", arrayOf(kind.toString()))
        } else {
            val a = AppDatabase.likeArg(query.trim())
            r.rawQuery(
                "SELECT id,url,title,kind,created_at,is_read FROM bookmarks WHERE kind = ? AND (url LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\') " +
                    "ORDER BY created_at DESC", arrayOf(kind.toString(), a, a)
            )
        }
        c.use { cur ->
            val out = ArrayList<Bookmark>()
            while (cur.moveToNext()) out.add(Bookmark(cur.getLong(0), cur.getString(1), cur.getString(2) ?: "", cur.getInt(3), cur.getLong(4), cur.getInt(5) == 1))
            out
        }
    }

    suspend fun suggest(query: String, limit: Int = 3): List<Bookmark> = list(BookmarkKind.BOOKMARK, query).take(limit)
}
