package com.shieldbrowser.app.security

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.shieldbrowser.app.R

/**
 * Turns an untrusted URL (tel:, mailto:, intent://, market://, app deep links …) into a *sanitised* Intent.
 * Sanitising: explicit component/selector removed, URI-permission grant flags removed, BROWSABLE category required,
 * file:/content: data rejected. The user is asked for confirmation before launch (default setting).
 */
object ExternalIntentGuard {
    /** Actions a web page may request through an intent: URI. Everything else (CALL, DELETE, settings…) is refused. */
    private val SAFE_INTENT_ACTIONS = setOf(Intent.ACTION_VIEW, Intent.ACTION_SENDTO, Intent.ACTION_SEND, Intent.ACTION_DIAL)

    private const val DANGEROUS_FLAGS =
        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION

    fun toSafeIntent(url: String): Intent? {
        val scheme = url.substringBefore(':').lowercase()
        val intent: Intent = try {
            when (scheme) {
                "intent" -> Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                "tel" -> Intent(Intent.ACTION_DIAL, Uri.parse(url))
                "sms", "smsto", "mms", "mmsto", "mailto" -> Intent(Intent.ACTION_SENDTO, Uri.parse(url))
                else -> Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
        } catch (_: Exception) { return null }
        intent.component = null
        intent.selector = null
        intent.flags = intent.flags and DANGEROUS_FLAGS.inv()
        intent.addCategory(Intent.CATEGORY_BROWSABLE)
        val dataScheme = intent.data?.scheme?.lowercase()
        if (dataScheme == "file" || dataScheme == "content" || dataScheme == "javascript") return null
        if (intent.action == Intent.ACTION_MAIN) return null
        if (scheme == "intent") {
            val action = intent.action
            if (action != null && action !in SAFE_INTENT_ACTIONS) return null
        }
        return intent
    }

    fun describe(ctx: Context, intent: Intent, url: String): String {
        val scheme = (intent.data?.scheme ?: url.substringBefore(':')).lowercase()
        val kind = when (scheme) {
            "tel" -> ctx.getString(R.string.ext_phone)
            "sms", "smsto", "mms", "mmsto" -> ctx.getString(R.string.ext_sms)
            "mailto" -> ctx.getString(R.string.ext_email)
            "geo" -> ctx.getString(R.string.ext_maps)
            "market" -> ctx.getString(R.string.ext_store)
            else -> ctx.getString(R.string.ext_app, scheme)
        }
        return kind + "\n" + url.take(120)
    }

    fun launch(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: ActivityNotFoundException) { false } catch (_: SecurityException) { false }
}
