package com.shieldbrowser.app.settings

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.preference.PreferenceDataStore
import com.shieldbrowser.app.storage.AesGcmCipher
import com.shieldbrowser.app.storage.EncryptedSettingsStore
import com.shieldbrowser.app.storage.KeystoreKey
import com.shieldbrowser.app.storage.SettingsCipher
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * Drop-in [SharedPreferences] whose whole content lives in ONE AES-256-GCM encrypted file
 * (filesDir/settings.enc). Keys AND values are encrypted; the AES key is non-exportable (Android Keystore).
 *
 * It encrypts everything stored through [BrowserSettings]: switches, search engine, DNS provider, user allow/block
 * lists, custom User-Agent, and the saved tab session (URLs of open tabs).
 * It does NOT cover the SQLite database (history, bookmarks, per-site rules, downloads list) or downloaded files.
 *
 * Writes are atomic (temp file + rename). If the file cannot be decrypted (key lost, file damaged) the settings
 * reset to defaults instead of crashing; [recoveredFromCorruption] tells the UI.
 */
class SecurePrefs(
    private val store: EncryptedSettingsStore,
    private val post: (Runnable) -> Unit
) : SharedPreferences {

    private val lock = Any()
    private val map = HashMap<String, Any>()
    private val listeners = CopyOnWriteArrayList<SharedPreferences.OnSharedPreferenceChangeListener>()
    private val writer = Executors.newSingleThreadExecutor { r -> Thread(r, "secure-prefs").also { it.isDaemon = true } }

    /** True when values are really encrypted (false only if this device's Keystore is unusable). */
    val isEncrypted: Boolean get() = store.encrypted
    @Volatile var recoveredFromCorruption: Boolean = false
        private set

    init {
        val loaded = store.load()
        map.putAll(loaded.values)
        recoveredFromCorruption = loaded.corrupted
        if (loaded.needsUpgrade || loaded.corrupted) {
            try { store.save(HashMap(map)) } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------------ reads
    override fun getAll(): MutableMap<String, *> = synchronized(lock) {
        val copy = HashMap<String, Any?>()
        for ((k, v) in map) copy[k] = if (v is Set<*>) HashSet(v) else v
        copy
    }

    override fun getString(key: String?, defValue: String?): String? =
        synchronized(lock) { (map[key] as? String) ?: defValue }

    override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? =
        synchronized(lock) {
            val v = map[key]
            if (v is Set<*>) v.filterIsInstance<String>().toMutableSet() else defValues
        }

    override fun getInt(key: String?, defValue: Int): Int = synchronized(lock) { (map[key] as? Int) ?: defValue }
    override fun getLong(key: String?, defValue: Long): Long = synchronized(lock) { (map[key] as? Long) ?: defValue }
    override fun getFloat(key: String?, defValue: Float): Float = synchronized(lock) { (map[key] as? Float) ?: defValue }
    override fun getBoolean(key: String?, defValue: Boolean): Boolean = synchronized(lock) { (map[key] as? Boolean) ?: defValue }
    override fun contains(key: String?): Boolean = synchronized(lock) { map.containsKey(key) }

    override fun edit(): SharedPreferences.Editor = EditorImpl()

    override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null && !listeners.contains(listener)) listeners.add(listener)
    }

    override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) listeners.remove(listener)
    }

    // ------------------------------------------------------------------ writes
    private fun persistNow(): Boolean {
        val snapshot = synchronized(lock) { HashMap(map) }
        return try { store.save(snapshot); true } catch (_: Exception) { false }
    }

    private fun persistLater() {
        try { writer.execute { persistNow() } } catch (_: Exception) { persistNow() }
    }

    private fun fire(keys: List<String>) {
        if (keys.isEmpty() || listeners.isEmpty()) return
        post(Runnable { for (k in keys) for (l in listeners) l.onSharedPreferenceChanged(this, k) })
    }

    private object Removed

    private inner class EditorImpl : SharedPreferences.Editor {
        private val pending = HashMap<String, Any>()
        private var clearAll = false

        private fun put(key: String?, value: Any?): SharedPreferences.Editor {
            if (key != null) pending[key] = value ?: Removed
            return this
        }

        override fun putString(key: String?, value: String?): SharedPreferences.Editor = put(key, value)
        override fun putStringSet(key: String?, values: MutableSet<String>?): SharedPreferences.Editor =
            put(key, values?.let { HashSet(it) })
        override fun putInt(key: String?, value: Int): SharedPreferences.Editor = put(key, value)
        override fun putLong(key: String?, value: Long): SharedPreferences.Editor = put(key, value)
        override fun putFloat(key: String?, value: Float): SharedPreferences.Editor = put(key, value)
        override fun putBoolean(key: String?, value: Boolean): SharedPreferences.Editor = put(key, value)
        override fun remove(key: String?): SharedPreferences.Editor = put(key, null)
        override fun clear(): SharedPreferences.Editor { clearAll = true; return this }

        /** Applies the edit to memory; returns the keys whose value really changed. */
        private fun applyToMemory(): List<String> {
            val changed = ArrayList<String>()
            synchronized(lock) {
                if (clearAll) {
                    changed.addAll(map.keys)
                    map.clear()
                }
                for ((k, v) in pending) {
                    if (v === Removed) {
                        if (map.remove(k) != null && !changed.contains(k)) changed.add(k)
                    } else {
                        val old = map[k]
                        if (old == null || old != v) { map[k] = v; if (!changed.contains(k)) changed.add(k) }
                    }
                }
            }
            return changed
        }

        override fun commit(): Boolean {
            val changed = applyToMemory()
            val ok = persistNow()
            fire(changed)
            return ok
        }

        override fun apply() {
            val changed = applyToMemory()
            persistLater()
            fire(changed)
        }
    }

    // ------------------------------------------------------------------ singleton + legacy migration
    companion object {
        private const val FILE_NAME = "settings.enc"
        private const val KEY_ALIAS = "shield_settings_key_v1"
        @Volatile private var instance: SecurePrefs? = null

        fun get(context: Context): SecurePrefs {
            val existing = instance
            if (existing != null) return existing
            return synchronized(this) { instance ?: create(context.applicationContext).also { instance = it } }
        }

        private fun create(app: Context): SecurePrefs {
            val cipher: SettingsCipher? = try {
                AesGcmCipher { KeystoreKey.getOrCreate(KEY_ALIAS) }.also { it.selfTest() }
            } catch (_: Throwable) { null }
            val main = Handler(Looper.getMainLooper())
            val prefs = SecurePrefs(EncryptedSettingsStore(File(app.filesDir, FILE_NAME), cipher)) { r -> main.post(r) }
            prefs.migrateLegacy(app)
            return prefs
        }

        /** Overwrites a file with zeros before deleting it (best effort: flash wear-levelling may keep old blocks). */
        private fun shred(f: File) {
            try {
                if (f.exists()) {
                    RandomAccessFile(f, "rw").use { raf ->
                        val zeros = ByteArray(4096)
                        var left = raf.length()
                        while (left > 0) {
                            val n = minOf(left, zeros.size.toLong()).toInt()
                            raf.write(zeros, 0, n)
                            left -= n
                        }
                        raf.fd.sync()
                    }
                }
            } catch (_: Exception) { }
            f.delete()
        }
    }

    /** One-time import of the pre-encryption plain SharedPreferences file, then secure removal of it. */
    private fun migrateLegacy(app: Context) {
        val name = app.packageName + "_preferences"
        val dir = File(app.applicationInfo.dataDir, "shared_prefs")
        val xml = File(dir, "$name.xml")
        if (!xml.exists()) return
        try {
            val legacy = app.getSharedPreferences(name, Context.MODE_PRIVATE)
            val edit = edit()
            for ((k, v) in legacy.all) {
                if (contains(k)) continue
                when (v) {
                    is Boolean -> edit.putBoolean(k, v)
                    is Int -> edit.putInt(k, v)
                    is Long -> edit.putLong(k, v)
                    is Float -> edit.putFloat(k, v)
                    is String -> edit.putString(k, v)
                    is Set<*> -> edit.putStringSet(k, v.filterIsInstance<String>().toMutableSet())
                }
            }
            if (!edit.commit()) return           // keep the old file if the encrypted copy could not be written
            legacy.edit().clear().commit()
        } catch (_: Exception) {
            return
        }
        shred(xml)
        shred(File(dir, "$name.xml.bak"))
        try { app.deleteSharedPreferences(name) } catch (_: Exception) { }
    }
}

/** Routes the Settings screen (androidx.preference) through [SecurePrefs] instead of a plain XML file. */
class SecureSettingsDataStore(private val prefs: SharedPreferences) : PreferenceDataStore() {
    override fun putString(key: String, value: String?) { prefs.edit().putString(key, value).apply() }
    override fun getString(key: String, defValue: String?): String? = prefs.getString(key, defValue)
    override fun putStringSet(key: String, values: MutableSet<String>?) { prefs.edit().putStringSet(key, values).apply() }
    override fun getStringSet(key: String, defValues: MutableSet<String>?): MutableSet<String>? = prefs.getStringSet(key, defValues)
    override fun putInt(key: String, value: Int) { prefs.edit().putInt(key, value).apply() }
    override fun getInt(key: String, defValue: Int): Int = prefs.getInt(key, defValue)
    override fun putLong(key: String, value: Long) { prefs.edit().putLong(key, value).apply() }
    override fun getLong(key: String, defValue: Long): Long = prefs.getLong(key, defValue)
    override fun putFloat(key: String, value: Float) { prefs.edit().putFloat(key, value).apply() }
    override fun getFloat(key: String, defValue: Float): Float = prefs.getFloat(key, defValue)
    override fun putBoolean(key: String, value: Boolean) { prefs.edit().putBoolean(key, value).apply() }
    override fun getBoolean(key: String, defValue: Boolean): Boolean = prefs.getBoolean(key, defValue)
}
