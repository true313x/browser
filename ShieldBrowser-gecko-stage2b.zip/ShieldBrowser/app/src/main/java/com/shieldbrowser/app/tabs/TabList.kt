package com.shieldbrowser.app.tabs

/** Pure data model for tabs (no Android dependencies → fully unit-testable). */
class TabData(
    val id: Long,
    var url: String,
    var title: String,
    val isPrivate: Boolean,
    var groupId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

class TabGroup(val id: Long, var name: String, var colorIndex: Int)

class TabList {
    private val _tabs = mutableListOf<TabData>()
    val tabs: List<TabData> get() = _tabs
    val groups = mutableListOf<TabGroup>()
    var activeId: Long = -1L
        private set
    private var nextId = 1L
    private var nextGroupId = 1L
    private val closed = ArrayDeque<TabData>()
    private val maxClosed = 20

    fun get(id: Long): TabData? = _tabs.firstOrNull { it.id == id }
    fun active(): TabData? = get(activeId)

    fun open(url: String, isPrivate: Boolean, afterId: Long? = null, select: Boolean = true): TabData {
        val t = TabData(nextId++, url, "", isPrivate)
        val idx = afterId?.let { a -> _tabs.indexOfFirst { it.id == a } }?.takeIf { it >= 0 }
        if (idx != null) {
            _tabs.add(idx + 1, t)
            _tabs.firstOrNull { it.id == afterId }?.let { t.groupId = it.groupId }
        } else _tabs.add(t)
        if (select) activeId = t.id
        return t
    }

    /** Closes a tab; if it was active, selects a neighbour (preferring the same privacy type). */
    fun close(id: Long): TabData? {
        val idx = _tabs.indexOfFirst { it.id == id }
        if (idx < 0) return null
        val t = _tabs.removeAt(idx)
        if (!t.isPrivate && t.url.isNotBlank()) {
            closed.addLast(TabData(0, t.url, t.title, false, t.groupId))
            while (closed.size > maxClosed) closed.removeFirst()
        }
        if (activeId == id) {
            // nearest tab of the same privacy type (next first, then previous); otherwise any neighbour
            val pool = _tabs.withIndex().filter { it.value.isPrivate == t.isPrivate }
            val pick = pool.firstOrNull { it.index >= idx }?.value ?: pool.lastOrNull()?.value
            activeId = (pick ?: _tabs.getOrNull(idx) ?: _tabs.getOrNull(idx - 1))?.id ?: -1L
        }
        return t
    }

    fun select(id: Long): Boolean {
        if (get(id) == null) return false
        activeId = id
        return true
    }

    fun duplicate(id: Long): TabData? {
        val src = get(id) ?: return null
        val t = open(src.url, src.isPrivate, afterId = id, select = true)
        t.title = src.title
        return t
    }

    /** privateOnly: null = all tabs, true = only private tabs, false = only normal tabs. */
    fun closeAll(privateOnly: Boolean? = null) {
        val victims = _tabs.filter { privateOnly == null || it.isPrivate == privateOnly }.map { it.id }
        victims.forEach { close(it) }
    }

    fun restoreClosed(): TabData? {
        val c = closed.removeLastOrNull() ?: return null
        val t = open(c.url, false)
        t.title = c.title
        return t
    }

    fun recentlyClosed(): List<TabData> = closed.toList().asReversed()

    fun search(query: String): List<TabData> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return _tabs.toList()
        return _tabs.filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
    }

    fun count(isPrivate: Boolean) = _tabs.count { it.isPrivate == isPrivate }

    fun createGroup(name: String): TabGroup {
        val g = TabGroup(nextGroupId++, name.trim().ifEmpty { "Group" }, groups.size % 6)
        groups.add(g)
        return g
    }

    fun assign(tabId: Long, groupId: Long?) {
        get(tabId)?.groupId = groupId?.takeIf { gid -> groups.any { it.id == gid } }
    }

    fun deleteGroup(groupId: Long) {
        groups.removeAll { it.id == groupId }
        _tabs.filter { it.groupId == groupId }.forEach { it.groupId = null }
    }

    /** Re-creates tabs from persisted data (normal tabs only). */
    fun restore(items: List<Triple<String, String, Long?>>, activeIndex: Int) {
        items.forEach { (u, title, g) -> open(u, false, select = false).also { it.title = title; it.groupId = g } }
        if (_tabs.isNotEmpty()) activeId = _tabs[activeIndex.coerceIn(0, _tabs.size - 1)].id
    }
}
