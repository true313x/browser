package com.shieldbrowser.app.browser

import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.GeolocationPermissions
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import com.shieldbrowser.app.R
import com.shieldbrowser.app.app.AppContainer
import com.shieldbrowser.app.blocking.DomainUtils
import com.shieldbrowser.app.privacy.BlockEvent
import com.shieldbrowser.app.privacy.EventType
import com.shieldbrowser.app.settings.Perm

class TabWebChromeClient(
    private val tab: BrowserTab,
    private val tabs: TabManager,
    private val c: AppContainer
) : WebChromeClient() {

    override fun onProgressChanged(view: WebView, newProgress: Int) {
        tab.progress = newProgress
        tabs.host?.onProgress(tab, newProgress)
    }

    override fun onReceivedTitle(view: WebView, title: String?) {
        if (!tab.internalPage && !title.isNullOrBlank()) tab.data.title = title
        tabs.host?.onTabChanged(tab)
    }

    override fun onReceivedIcon(view: WebView, icon: Bitmap?) { tab.favicon = icon }

    // ------------------------------------------------------------------ windows / popups
    override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
        val pageHost = tab.pageHost
        val site = c.siteSettings.get(pageHost)
        val now = System.currentTimeMillis()
        while (tab.windowTimes.isNotEmpty() && now - tab.windowTimes.first() > 4000) tab.windowTimes.removeFirst()
        val blocked = when {
            site.popups == Perm.BLOCK -> true
            site.popups == Perm.ALLOW -> false
            !c.settings.blockPopups -> false
            else -> !isUserGesture || tab.windowTimes.size >= 2        // no gesture, or "new-window abuse"
        }
        if (blocked) {
            tabs.record(tab, BlockEvent(EventType.POPUP, pageHost.orEmpty(), view.url.orEmpty(), detail = if (isUserGesture) "window flood" else "no user gesture"))
            val ctx = tabs.uiContext()
            tabs.host?.toast(ctx.getString(R.string.popup_blocked), ctx.getString(R.string.allow_site)) {
                pageHost?.let { h -> c.siteSettings.update(h) { it.copy(popups = Perm.ALLOW) } }
            }
            return false
        }
        val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
        tab.windowTimes.addLast(now)
        val newTab = tabs.newTab(null, tab.isPrivate, select = true, openerId = tab.id, blank = true)
        transport.webView = tabs.webViewFor(newTab)
        resultMsg.sendToTarget()
        return true
    }

    override fun onCloseWindow(window: WebView) {
        tabs.findTab(window)?.let { tabs.closeTab(it.id) }
    }

    // ------------------------------------------------------------------ permissions
    override fun onPermissionRequest(request: PermissionRequest) {
        val host = request.origin?.host.orEmpty()
        val needs = ArrayList<SitePerm>()
        val grant = ArrayList<String>()
        for (r in request.resources) when (r) {
            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> { needs.add(SitePerm.CAMERA); grant.add(r) }
            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> { needs.add(SitePerm.MICROPHONE); grant.add(r) }
            else -> {}   // MIDI / protected-media-id (DRM identifiers) are always denied (privacy)
        }
        val h = tabs.host
        if (needs.isEmpty() || h == null) { request.deny(); return }
        h.requestSitePermissions(tab, host, needs) { ok ->
            if (ok) request.grant(grant.toTypedArray()) else request.deny()
        }
    }

    override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
        val host = DomainUtils.hostOf(origin).orEmpty()
        val h = tabs.host
        if (h == null) { callback.invoke(origin, false, false); return }
        h.requestSitePermissions(tab, host, listOf(SitePerm.LOCATION)) { ok -> callback.invoke(origin, ok, false) }
    }

    // ------------------------------------------------------------------ file chooser / fullscreen video
    override fun onShowFileChooser(
        webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, fileChooserParams: FileChooserParams
    ): Boolean {
        val ok = tabs.host?.launchFileChooser(filePathCallback, fileChooserParams) ?: false
        if (!ok) filePathCallback.onReceiveValue(null)
        return ok
    }

    override fun onShowCustomView(view: View, callback: CustomViewCallback) {
        val h = tabs.host
        if (h == null) callback.onCustomViewHidden() else h.showCustomView(view, callback)
    }

    override fun onHideCustomView() { tabs.host?.hideCustomView() }

    // ------------------------------------------------------------------ JS dialogs (rate-limited)
    private fun dialog(kind: JsDialogKind, url: String, message: String, default: String?, result: JsResult): Boolean {
        val now = System.currentTimeMillis()
        while (tab.dialogTimes.isNotEmpty() && now - tab.dialogTimes.first() > 10_000) tab.dialogTimes.removeFirst()
        tab.dialogTimes.addLast(now)
        val h = tabs.host
        if (h == null || tab.dialogTimes.size > 3) {
            tabs.record(tab, BlockEvent(EventType.DIALOG, DomainUtils.hostOf(url).orEmpty(), url, detail = "dialog flood"))
            result.cancel()
            return true
        }
        h.showJsDialog(tab, kind, DomainUtils.hostOf(url).orEmpty(), message, default, result)
        return true
    }

    override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean =
        dialog(JsDialogKind.ALERT, url, message, null, result)

    override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean =
        dialog(JsDialogKind.CONFIRM, url, message, null, result)

    override fun onJsPrompt(view: WebView, url: String, message: String, defaultValue: String?, result: JsPromptResult): Boolean =
        dialog(JsDialogKind.PROMPT, url, message, defaultValue, result)

    override fun onJsBeforeUnload(view: WebView, url: String, message: String, result: JsResult): Boolean {
        result.confirm()    // never trap the user on a page
        return true
    }

    override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
        if (c.settings.developerMode) {
            tab.pushLog(tab.console, "[${consoleMessage.messageLevel()}] ${consoleMessage.message()} (${consoleMessage.sourceId()}:${consoleMessage.lineNumber()})")
        }
        return true
    }
}
