package com.shieldbrowser.app.security

import android.content.Context
import android.view.View
import com.shieldbrowser.app.R

enum class InterstitialKind { SSL, MALWARE, MINER, HTTPS_FALLBACK, LOAD_ERROR }

/**
 * Local HTML for warning / error / start pages. These pages contain NO JavaScript and a strict CSP.
 * Their action links use the internal `shield://` scheme and carry a per-page random nonce that TabWebViewClient
 * verifies, so a malicious website cannot forge "Continue anyway" links.
 */
object Interstitials {
    const val INTERNAL_BASE = "https://shield.invalid/"

    private const val CSP = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; form-action shield:; base-uri 'none'"

    private fun esc(s: String): String = buildString {
        for (c in s) when (c) {
            '&' -> append("&amp;"); '<' -> append("&lt;"); '>' -> append("&gt;")
            '"' -> append("&quot;"); '\'' -> append("&#39;"); else -> append(c)
        }
    }

    private fun css(): String = """
        :root{color-scheme:light dark;--bg:#fafdfb;--fg:#191c1b;--card:#e9f0ee;--pri:#00796b;--bad:#ba1a1a;--mut:#3f4947}
        @media (prefers-color-scheme:dark){:root{--bg:#101413;--fg:#e0e3e1;--card:#222927;--pri:#4db6ac;--bad:#ffb4ab;--mut:#bec9c6}}
        *{box-sizing:border-box}
        body{margin:0;padding:24px 20px;background:var(--bg);color:var(--fg);font-family:system-ui,-apple-system,Roboto,sans-serif;line-height:1.5}
        .wrap{max-width:560px;margin:8vh auto 0}
        h1{font-size:22px;margin:12px 0}
        .icon{font-size:44px}
        .bad h1,.bad .icon{color:var(--bad)}
        p{color:var(--mut)}
        .url{background:var(--card);padding:10px 12px;border-radius:10px;word-break:break-all;font-family:monospace;font-size:13px;color:var(--fg)}
        .btns{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}
        a.btn{display:inline-block;padding:12px 20px;border-radius:24px;text-decoration:none;font-weight:600;font-size:15px}
        a.primary{background:var(--pri);color:var(--bg)}
        a.ghost{border:1.5px solid var(--mut);color:var(--fg)}
        details{margin-top:18px;color:var(--mut);font-size:13px}
        form{display:flex;gap:8px;margin-top:20px}
        input[type=text]{flex:1;padding:14px 18px;border-radius:26px;border:1.5px solid var(--mut);background:var(--card);color:var(--fg);font-size:16px;min-width:0}
        button{padding:0 20px;border:0;border-radius:26px;background:var(--pri);color:var(--bg);font-weight:600;font-size:15px}
        """.trimIndent()

    private fun head(ctx: Context, title: String): String {
        val rtl = ctx.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        return "<!doctype html><html dir=\"${if (rtl) "rtl" else "ltr"}\"><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<meta http-equiv=\"Content-Security-Policy\" content=\"$CSP\">" +
            "<title>${esc(title)}</title><style>${css()}</style></head><body>"
    }

    fun page(ctx: Context, kind: InterstitialKind, url: String, details: String, nonce: String): String {
        val (title, msg, secLabel, secAction) = when (kind) {
            InterstitialKind.SSL -> Quad(R.string.ssl_title, R.string.ssl_msg, R.string.int_continue, "ssl_continue")
            InterstitialKind.MALWARE -> Quad(R.string.malware_title, R.string.malware_msg, R.string.int_continue, "block_continue")
            InterstitialKind.MINER -> Quad(R.string.miner_title, R.string.miner_msg, R.string.int_continue, "block_continue")
            InterstitialKind.HTTPS_FALLBACK -> Quad(R.string.https_fb_title, R.string.https_fb_msg, R.string.int_continue_http, "http_continue")
            InterstitialKind.LOAD_ERROR -> Quad(R.string.err_title, R.string.err_msg, R.string.int_retry, "retry")
        }
        val bad = kind != InterstitialKind.LOAD_ERROR
        val t = ctx.getString(title)
        return head(ctx, t) +
            "<div class=\"wrap ${if (bad) "bad" else ""}\"><div class=\"icon\">${if (bad) "&#9888;" else "&#128268;"}</div>" +
            "<h1>${esc(t)}</h1><p>${esc(ctx.getString(msg))}</p><div class=\"url\">${esc(url)}</div>" +
            "<div class=\"btns\"><a class=\"btn primary\" href=\"shield://action?do=back&amp;nonce=$nonce\">${esc(ctx.getString(R.string.int_back))}</a>" +
            "<a class=\"btn ghost\" href=\"shield://action?do=$secAction&amp;nonce=$nonce\">${esc(ctx.getString(secLabel))}</a></div>" +
            (if (details.isNotBlank()) "<details><summary>${esc(ctx.getString(R.string.int_details))}</summary><p>${esc(details)}</p></details>" else "") +
            "</div></body></html>"
    }

    fun startPage(ctx: Context, nonce: String, engineName: String, isPrivate: Boolean): String {
        val title = ctx.getString(R.string.app_name)
        return head(ctx, title) +
            "<div class=\"wrap\"><div class=\"icon\" style=\"color:var(--pri)\">&#128737;</div><h1>${esc(title)}</h1>" +
            "<p>${esc(ctx.getString(if (isPrivate) R.string.start_private_note else R.string.start_note))}</p>" +
            "<form action=\"shield://search\" method=\"get\"><input type=\"hidden\" name=\"nonce\" value=\"$nonce\">" +
            "<input type=\"text\" name=\"q\" placeholder=\"${esc(ctx.getString(R.string.start_search_hint, engineName))}\" autocomplete=\"off\" autocapitalize=\"off\">" +
            "<button type=\"submit\">&#10140;</button></form></div></body></html>"
    }

    private data class Quad(val a: Int, val b: Int, val c: Int, val d: String)
}
