package com.shieldbrowser.app.security

enum class Severity { INFO, WARN, CRITICAL }

/** Signals the tamper monitor can raise. CRITICAL ones may trigger Sealed Mode, WARN ones only gate payments. */
enum class TamperSignal(val severity: Severity) {
    DEBUGGER(Severity.CRITICAL),
    TRACER(Severity.CRITICAL),
    DEBUGGABLE_BUILD(Severity.CRITICAL),
    SIGNATURE_MISMATCH(Severity.CRITICAL),
    HOOK_FRAMEWORK(Severity.CRITICAL),
    INSTRUMENTATION_SERVER(Severity.WARN),
    ROOT(Severity.WARN),
    EMULATOR(Severity.WARN),
    /** Payment context only: non-system accessibility service that can read the screen. */
    SCREEN_READER_APP(Severity.WARN),
    /** Payment context only: non-system keyboard (could log card numbers). */
    THIRD_PARTY_KEYBOARD(Severity.WARN)
}

/** Pure parsing helpers (no Android classes) so they can be unit-tested on the JVM. */
object IntegrityChecks {
    /** "TracerPid:\t0" -> 0. Anything > 0 means a debugger/tracer (ptrace) is attached. -1 when absent. */
    fun tracerPid(procStatus: String): Int {
        val line = procStatus.lineSequence().firstOrNull { it.startsWith("TracerPid:") } ?: return -1
        return line.substringAfter(':').trim().toIntOrNull() ?: -1
    }

    private val HOOK_MARKERS = listOf(
        "frida-agent", "frida-gadget", "libfrida", "re.frida", "linjector", "frida_agent",
        "xposedbridge", "lsposed", "edxposed", "libsandhook", "libwhale", "libsubstrate", "com.saurik.substrate"
    )

    /** Which hooking/instrumentation frameworks are mapped into this process (lines of /proc/self/maps). */
    fun hookMarkers(maps: String): Set<String> {
        val found = LinkedHashSet<String>()
        for (line in maps.lineSequence()) {
            val l = line.lowercase()
            for (m in HOOK_MARKERS) if (l.contains(m)) found.add(m)
        }
        return found
    }

    private val HOOK_THREADS = setOf("gum-js-loop", "gdbus", "gmain", "pool-frida", "frida-server")

    /** Thread names (/proc/self/task/<tid>/comm). gum-js-loop / pool-frida are Frida's JS and agent threads. */
    fun hookThreads(threadNames: Collection<String>): Set<String> =
        threadNames.map { it.trim().lowercase() }.filter { it in HOOK_THREADS && it != "gmain" && it != "gdbus" }.toSet()
            .ifEmpty {
                // gmain+gdbus together (GLib main loop + D-Bus) is typical for the Frida agent but each alone is common.
                val n = threadNames.map { it.trim().lowercase() }
                if ("gmain" in n && "gdbus" in n && "gum-js-loop" in n) setOf("gum-js-loop") else emptySet()
            }

    /** Class names found in a stack trace that belong to hooking frameworks. */
    fun hookFrames(classNames: Collection<String>): Boolean =
        classNames.any { c ->
            c.startsWith("de.robv.android.xposed") || c.startsWith("org.lsposed") || c.startsWith("com.saurik.substrate") ||
                c.startsWith("io.github.lsposed") || c.startsWith("re.frida") || c.contains(".frida.")
        }

    fun looksLikeEmulator(fingerprint: String, hardware: String, product: String, model: String, manufacturer: String): Boolean {
        val f = fingerprint.lowercase(); val h = hardware.lowercase(); val p = product.lowercase()
        return f.startsWith("generic") || f.contains("emulator") || f.contains("vbox") ||
            h == "goldfish" || h == "ranchu" || h.contains("vbox") ||
            p.startsWith("sdk_gphone") || p.contains("emulator") || p == "google_sdk" ||
            model.contains("Emulator", ignoreCase = true) || model.contains("Android SDK built for", ignoreCase = true) ||
            manufacturer.equals("Genymotion", ignoreCase = true)
    }

    /** Constant-time comparison of two hex digests (case-insensitive). */
    fun sameDigest(a: String, b: String): Boolean {
        val x = a.lowercase(); val y = b.lowercase()
        if (x.length != y.length) return false
        var r = 0
        for (i in x.indices) r = r or (x[i].code xor y[i].code)
        return r == 0
    }
}
