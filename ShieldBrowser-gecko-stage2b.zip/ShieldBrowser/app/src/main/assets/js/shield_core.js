/* Shield Browser — document-start script (all frames). Config is provided as __SHIELD_CFG.
 * Everything here REDUCES tracking/fingerprinting surface; none of it is a guarantee.
 * Messages to the app go through window.ShieldBridge (WebMessageListener), batched and de-duplicated. */
(function () {
  'use strict';
  var CFG = (typeof __SHIELD_CFG !== 'undefined') ? __SHIELD_CFG : null;
  if (!CFG || window.__shieldInit) { return; }
  try { Object.defineProperty(window, '__shieldInit', { value: true }); } catch (e) { return; }

  var host = '';
  try { host = String(location.hostname || '').toLowerCase(); } catch (e) {}
  var O = null;
  (function () {
    var p = host;
    for (;;) {
      if (Object.prototype.hasOwnProperty.call(CFG.ovr, p)) { O = CFG.ovr[p]; return; }
      var i = p.indexOf('.');
      if (i < 0) return;
      p = p.substring(i + 1);
    }
  })();
  O = O || {};
  if (O.off) { return; }

  var MODE = (O.fp !== undefined && O.fp >= 0) ? O.fp : CFG.fp;
  var st = window.setTimeout.bind(window);
  var queue = {}, timer = 0, seen = {};

  function flush() {
    timer = 0;
    var q = queue; queue = {};
    try { if (window.ShieldBridge) { window.ShieldBridge.postMessage(JSON.stringify(q)); } } catch (e) {}
  }
  /* once=true → counted at most once per frame (e.g. "canvas read-back"); otherwise counted every time. */
  function rep(type, kind, once) {
    var key = type + ':' + kind;
    if (once) { if (seen[key]) return; seen[key] = 1; }
    queue[key] = (queue[key] || 0) + 1;
    if (!timer) { timer = st(flush, 700); }
  }

  /* --- make wrappers look native ---------------------------------------------------------- */
  var nativeToString = Function.prototype.toString;
  var fakes = new WeakMap();
  try {
    var ts = function toString() { var f = fakes.get(this); return f !== undefined ? f : nativeToString.call(this); };
    fakes.set(ts, 'function toString() { [native code] }');
    Function.prototype.toString = ts;
  } catch (e) {}
  function mask(fn, name) { try { fakes.set(fn, 'function ' + name + '() { [native code] }'); } catch (e) {} return fn; }
  function patchMethod(proto, name, make) {
    try {
      if (!proto) return;
      var orig = proto[name];
      if (typeof orig !== 'function') return;
      var w = make(orig);
      mask(w, name);
      proto[name] = w;
    } catch (e) {}
  }
  function patchGetter(obj, name, val) {
    try {
      if (!obj) return;
      var d = Object.getOwnPropertyDescriptor(obj, name);
      var g = function () { return (typeof val === 'function') ? val.call(this) : val; };
      mask(g, 'get ' + name);
      Object.defineProperty(obj, name, { get: g, configurable: true, enumerable: d ? d.enumerable : true });
    } catch (e) {}
  }
  function wrapNumGetter(proto, name, fn) {
    try {
      var d = Object.getOwnPropertyDescriptor(proto, name);
      if (!d || !d.get) return;
      var og = d.get;
      var g = function () { return fn(og.call(this)); };
      mask(g, 'get ' + name);
      Object.defineProperty(proto, name, { get: g, configurable: true, enumerable: d.enumerable });
    } catch (e) {}
  }

  /* --- deterministic per-site noise -------------------------------------------------------- */
  function h32(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h = Math.imul(h ^ s.charCodeAt(i), 16777619); } return h >>> 0; }
  var S = (CFG.seed ^ h32(host)) >>> 0;
  function perturb(d) {
    var s = S, n = d.length;
    for (var i = 0; i < n; i += 44) {
      s = (Math.imul(s ^ (i >>> 2), 2654435761) >>> 0);
      var c = i + (s % 3);
      if (c < n) { d[c] = d[c] ^ 1; }
    }
  }

  var NP = window.Navigator && Navigator.prototype;

  /* --- fingerprint mitigation ------------------------------------------------------------- */
  if (MODE >= 1) {
    var ctxType = new WeakMap();
    var HC = window.HTMLCanvasElement && HTMLCanvasElement.prototype;
    var C2D = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
    var origGID = C2D && C2D.getImageData;
    if (HC) {
      patchMethod(HC, 'getContext', function (o) { return function (type) { try { ctxType.set(this, String(type)); } catch (e) {} return o.apply(this, arguments); }; });
      var farbled = function (canvas) {
        var t = ctxType.get(canvas);
        if (t !== '2d' && t !== undefined) return null;               // WebGL canvases handled via readPixels
        if (canvas.width * canvas.height < 256 || !origGID) return null;
        var c = document.createElement('canvas'); c.width = canvas.width; c.height = canvas.height;
        var x = c.getContext('2d'); x.drawImage(canvas, 0, 0);
        var id = origGID.call(x, 0, 0, c.width, c.height);
        perturb(id.data); x.putImageData(id, 0, 0);
        return c;
      };
      patchMethod(HC, 'toDataURL', function (o) { return function () { try { var c = farbled(this); if (c) { rep('fp', 'canvas', true); return o.apply(c, arguments); } } catch (e) {} return o.apply(this, arguments); }; });
      patchMethod(HC, 'toBlob', function (o) { return function () { try { var c = farbled(this); if (c) { rep('fp', 'canvas', true); return o.apply(c, arguments); } } catch (e) {} return o.apply(this, arguments); }; });
    }
    if (C2D) {
      patchMethod(C2D, 'getImageData', function (o) { return function () { var d = o.apply(this, arguments); try { if (d && d.data && d.data.length >= 1024) { perturb(d.data); rep('fp', 'canvas', true); } } catch (e) {} return d; }; });
    }
    if (window.AudioBuffer) {
      patchMethod(AudioBuffer.prototype, 'getChannelData', function (o) {
        var done = new WeakSet();
        return function () {
          var d = o.apply(this, arguments);
          try { if (!done.has(d)) { done.add(d); var s = S; for (var i = 0; i < d.length; i += 100) { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; d[i] += (s / 4294967296 - 0.5) * 1e-7; } rep('fp', 'audio', true); } } catch (e) {}
          return d;
        };
      });
    }
    if (window.AnalyserNode) {
      patchMethod(AnalyserNode.prototype, 'getFloatFrequencyData', function (o) { return function (a) { var r = o.apply(this, arguments); try { for (var i = 0; i < a.length; i += 7) { a[i] += 0.0001 * ((S >>> (i % 16)) & 3); } rep('fp', 'audio', true); } catch (e) {} return r; }; });
    }
    var patchGL = function (P) {
      if (!P) return;
      patchMethod(P, 'getParameter', function (o) { return function (p) {
        try { if (p === 37445) { rep('fp', 'webgl', true); return 'Google Inc.'; } if (p === 37446) { rep('fp', 'webgl', true); return 'ANGLE (Generic GPU)'; } } catch (e) {}
        return o.apply(this, arguments);
      }; });
      if (MODE >= 2) patchMethod(P, 'readPixels', function (o) { return function () { var r = o.apply(this, arguments); try { var b = arguments[6]; if (b && b.length >= 64) { perturb(b); rep('fp', 'webgl', true); } } catch (e) {} return r; }; });
      if (MODE >= 3) patchMethod(P, 'getSupportedExtensions', function (o) { return function () { var r = o.apply(this, arguments); try { if (r && r.filter) { return r.filter(function (x) { return x.indexOf('debug') < 0; }); } } catch (e) {} return r; }; });
    };
    patchGL(window.WebGLRenderingContext && WebGLRenderingContext.prototype);
    patchGL(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype);

    if (NP) {
      patchGetter(NP, 'hardwareConcurrency', 4);
      patchGetter(NP, 'deviceMemory', 4);
      try { if (NP.getBattery) { Object.defineProperty(NP, 'getBattery', { value: undefined, configurable: true, writable: true }); rep('fp', 'battery', true); } } catch (e) {}
    }
  }
  if (MODE >= 2 && NP) {
    var LANGS = Object.freeze(['en-US', 'en']);
    patchGetter(NP, 'languages', function () { return LANGS; });
    patchGetter(NP, 'language', 'en-US');
    patchGetter(NP, 'connection', undefined);
    if (window.Screen) {
      var r100 = function (v) { return Math.round(v / 100) * 100; };
      ['width', 'height', 'availWidth', 'availHeight'].forEach(function (n) { wrapNumGetter(Screen.prototype, n, r100); });
      patchGetter(Screen.prototype, 'colorDepth', 24);
      patchGetter(Screen.prototype, 'pixelDepth', 24);
    }
    try {
      Object.defineProperty(window, 'outerWidth', { get: function () { return window.innerWidth; }, configurable: true });
      Object.defineProperty(window, 'outerHeight', { get: function () { return window.innerHeight; }, configurable: true });
    } catch (e) {}
    if (window.Performance) patchMethod(Performance.prototype, 'now', function (o) { return function () { return Math.round(o.call(this) * 10) / 10; }; });
  }
  if (MODE >= 3) {
    patchMethod(Date.prototype, 'getTimezoneOffset', function () { return function () { return 0; }; });
    if (window.Intl && Intl.DateTimeFormat) patchMethod(Intl.DateTimeFormat.prototype, 'resolvedOptions', function (o) { return function () { var r = o.apply(this, arguments); try { r.timeZone = 'UTC'; } catch (e) {} return r; }; });
    if (window.FontFaceSet) patchMethod(FontFaceSet.prototype, 'check', function (o) { return function (f) { rep('fp', 'fonts', true); return false; }; });
    if (window.speechSynthesis) patchMethod(window.speechSynthesis.constructor.prototype, 'getVoices', function () { return function () { rep('fp', 'voices', true); return []; }; });
  }

  /* --- identity consistency with the selected User-Agent profile --------------------------- */
  if (CFG.id && NP) {
    patchGetter(NP, 'platform', CFG.id.platform);
    patchGetter(NP, 'vendor', CFG.id.vendor);
    patchGetter(NP, 'maxTouchPoints', CFG.id.touch);
    patchGetter(NP, 'appVersion', CFG.id.appVersion);
    if (!CFG.id.uad) patchGetter(NP, 'userAgentData', undefined);
  }

  /* --- WebRTC IP-leak reduction ----------------------------------------------------------- */
  if (CFG.webrtc === 'block') {
    ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel'].forEach(function (n) {
      try { Object.defineProperty(window, n, { value: undefined, configurable: true, writable: true }); } catch (e) {}
    });
    rep('webrtc', 'block', true);
  } else if (CFG.webrtc === 'relay' && window.RTCPeerConnection) {
    try {
      var OrigPC = window.RTCPeerConnection;
      var PC = function RTCPeerConnection(cfg, c) {
        var conf = {}; try { if (cfg) { for (var k in cfg) { conf[k] = cfg[k]; } } } catch (e) {}
        conf.iceTransportPolicy = 'relay'; rep('webrtc', 'relay', true);
        return new OrigPC(conf, c);
      };
      PC.prototype = OrigPC.prototype; PC.generateCertificate = OrigPC.generateCertificate;
      mask(PC, 'RTCPeerConnection');
      window.RTCPeerConnection = PC;
      if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = PC;
    } catch (e) {}
  }

  /* --- clipboard ------------------------------------------------------------------------- */
  var activeGesture = function () { try { return !!(navigator.userActivation && navigator.userActivation.isActive); } catch (e) { return true; } };
  if (CFG.clip && !O.clip) {
    var CB = window.Clipboard && Clipboard.prototype;
    ['readText', 'read'].forEach(function (n) {
      patchMethod(CB, n, function () { return function () { rep('clip', 'read', false); return Promise.reject(new DOMException('Read permission denied.', 'NotAllowedError')); }; });
    });
  }
  if (CFG.clip && window.Document) {
    patchMethod(Document.prototype, 'execCommand', function (o) { return function (c) {
      var cl = String(c).toLowerCase();
      if (cl === 'paste' && !O.clip) { rep('clip', 'read', false); return false; }
      if ((cl === 'copy' || cl === 'cut') && !activeGesture()) { rep('clip', 'write', false); return false; }
      return o.apply(this, arguments);
    }; });
    var CB2 = window.Clipboard && Clipboard.prototype;
    patchMethod(CB2, 'writeText', function (o) { return function () { if (!activeGesture()) { rep('clip', 'write', false); return Promise.reject(new DOMException('Write blocked (no user gesture).', 'NotAllowedError')); } return o.apply(this, arguments); }; });
  }

  /* --- per-site "block cookies": make document.cookie inert -------------------------------- */
  if (O.nocookie && window.Document) {
    try {
      Object.defineProperty(Document.prototype, 'cookie', {
        get: function () { return ''; },
        set: function (v) { rep('cookie', 'blocked', false); },
        configurable: true
      });
    } catch (e) {}
  }

  /* --- cryptomining heuristics (best effort) --------------------------------------------- */
  if (CFG.mining) {
    var workers = [], wasm = 0, t0 = Date.now(), stopped = false, blobWorkers = 0;
    var stop = function (why) {
      if (stopped) return; stopped = true;
      for (var i = 0; i < workers.length; i++) { try { workers[i].terminate(); } catch (e) {} }
      rep('miner', why, true);
    };
    var check = function () {
      if (stopped) return;
      var cores = Math.max(4, navigator.hardwareConcurrency || 4);
      if (workers.length >= cores + 2 && (wasm > 0 || blobWorkers >= cores) && Date.now() - t0 < 20000) stop('heuristic');
    };
    if (window.Worker) {
      var OW = window.Worker;
      var W = function Worker(u, o) {
        if (stopped) { throw new DOMException('Blocked by Shield (suspected cryptominer)', 'SecurityError'); }
        var w = new OW(u, o);
        workers.push(w);
        try { var s = String(u); if (s.indexOf('blob:') === 0 || s.indexOf('data:') === 0) blobWorkers++; } catch (e) {}
        check();
        return w;
      };
      W.prototype = OW.prototype; mask(W, 'Worker'); window.Worker = W;
    }
    if (window.WebAssembly) {
      ['instantiate', 'compile', 'instantiateStreaming', 'compileStreaming'].forEach(function (n) {
        patchMethod(WebAssembly, n, function (o) { return function () { wasm++; check(); return o.apply(this, arguments); }; });
      });
    }
    var globalsScan = function () {
      var names = ['CoinHive', 'CryptoLoot', 'CoinImp', 'deepMiner', 'WMP', 'MinerUI'];
      for (var i = 0; i < names.length; i++) {
        var g = window[names[i]];
        if (g && (typeof g === 'object' || typeof g === 'function')) { stop('global:' + names[i]); try { if (g.Anonymous) { g.Anonymous = function () { return { start: function () {}, stop: function () {}, on: function () {} }; }; } } catch (e) {} }
      }
    };
    st(globalsScan, 2500); st(globalsScan, 8000);
  }

  /* --- link / click tracking, referrer, cosmetic filters ----------------------------------- */
  function onClick(e) {
    try {
      var a = e.target && e.target.closest ? e.target.closest('a') : null;
      if (!a) return;
      if (a.hasAttribute('ping')) { a.removeAttribute('ping'); rep('track', 'ping', false); }
      if (CFG.referrer && a.origin && a.origin !== location.origin && a.relList) { a.relList.add('noreferrer'); }
    } catch (x) {}
  }
  document.addEventListener('click', onClick, true);
  document.addEventListener('auxclick', onClick, true);

  function addToHead(node) {
    var h = document.head || document.documentElement;
    if (h) { h.appendChild(node); return true; }
    return false;
  }
  function inject(make) {
    var n = make();
    if (addToHead(n)) return;
    try {
      var mo = new MutationObserver(function () { if (addToHead(make())) { mo.disconnect(); } });
      mo.observe(document, { childList: true, subtree: true });
    } catch (e) {}
  }
  if (CFG.referrer) {
    var addMeta = function () { var m = document.createElement('meta'); m.name = 'referrer'; m.content = CFG.referrer; return m; };
    inject(addMeta);
    document.addEventListener('DOMContentLoaded', function () { try { addToHead(addMeta()); } catch (e) {} });
  }
  if (CFG.cosmetic) {
    inject(function () {
      var s = document.createElement('style');
      s.textContent = 'ins.adsbygoogle,.adsbygoogle,[id^="google_ads_iframe"],[id^="div-gpt-ad"],iframe[src*="doubleclick.net"],iframe[src*="googlesyndication.com"],' +
        '.ad-banner,.ad-container,.ad-slot,.advert,.advertisement,[class*="sponsored-ad"],[id^="taboola-"],[class^="OUTBRAIN"],.outbrain-widget,' +
        '[data-ad-slot],[data-google-query-id]{display:none !important;}';
      return s;
    });
  }
})();
