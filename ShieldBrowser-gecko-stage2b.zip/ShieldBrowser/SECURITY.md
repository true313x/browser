# Security Policy

## Reporting a vulnerability
Please use **GitHub → Security → “Report a vulnerability”** (private advisory) on this repository.
Do not open public issues for security problems. Include version, device/WebView version, steps and impact.
We aim to acknowledge within 7 days. There is no bug-bounty program.

## Security model

**Trust boundaries**
* Web content is untrusted. It runs in the system WebView (Chromium) sandbox; Shield Browser adds policy around it.
* The app’s own UI/pages (`shield://`) are local HTML without JavaScript, with a CSP, and actions require a per-page random nonce.
* Files, intents and URLs coming from web content or from other apps are untrusted and validated.

**Hardening implemented**
* WebView: `allowFileAccess`, `allowContentAccess`, `allowFileAccessFromFileURLs`, `allowUniversalAccessFromFileURLs` = false; mixed content never allowed; no `@JavascriptInterface`
  objects (a `WebMessageListener` is used, which can only *count* events); JS popups/dialog floods rate-limited; `onJsBeforeUnload` never traps the user.
* Navigation: HTTPS-only upgrade with warning fallback; TLS errors never auto-proceed (per-tab, per-host explicit exception only); `data:`, `file:`, `content:`, `javascript:` top-level navigations blocked; automatic cross-site redirects gated.
* External apps: `intent:`/`tel:`/`mailto:`/app links are parsed into sanitised intents (component, selector and URI-grant flags removed; BROWSABLE required; file/content data rejected) and confirmed by the user by default.
* Incoming intents: only `http`/`https` VIEW URLs are accepted.
* Downloads: file names sanitised (no traversal, no bidi/zero-width characters), unique names, resumable; HTTPS→HTTP downgrades are blocked **before** the plaintext request is sent (network interceptor) and the `Cookie` header is dropped when a redirect leaves the original host; SHA-256, risk heuristics; APKs are never installed automatically; FileProvider with narrow paths; `exported=false` for all components except the launcher activity.
* `blob:` downloads: the page streams the bytes through a `WebMessageListener` only for sessions the app started (128-bit random id, bound to one tab); messages must come from the **main frame** and the origin that owns the blob URL; the normal download policy/dialog runs before any byte is accepted; chunks are acknowledged one at a time (back-pressure), size is capped (2 GB) and stalled sessions time out. A malicious page can only feed bytes into a download you just approved for that same page.
* Download notifications: **private** downloads never get a per-file notification (generic "Private download in progress" only); every notification has a generic public version for the lock screen; tapping only opens the Downloads screen. The foreground service (`dataSync`) and receiver are `exported=false`.
* Encrypted local settings: see below.
* Storage: `allowBackup=false`, empty backup/transfer rules, SQLite `secure_delete`, private downloads in cache and wiped; per-tab/private WebView profiles.
* Network security config: system trust anchors only.
* Permissions: INTERNET, ACCESS_NETWORK_STATE, REQUEST_INSTALL_PACKAGES (APK hand-off), POST_NOTIFICATIONS (asked once, at your first download), FOREGROUND_SERVICE + FOREGROUND_SERVICE_DATA_SYNC (downloads in the background), MODIFY_AUDIO_SETTINGS (WebRTC audio), and CAMERA/RECORD_AUDIO/LOCATION that are requested at runtime **only after** you allow a site. No contacts/SMS/phone/call-log.

**Known limitations / non-goals**
* We cannot prevent zero-click exploits in Android, Chromium or the GPU/media stack; keep *Android System WebView* and Android updated.
* Fingerprint and UA changes are mitigations, not anonymity. A site (and your network) can still see your IP address and network-level fingerprints.
* **Encrypted local settings** (`SecurePrefs`): one file `filesDir/settings.enc`, AES-256-GCM, random IV per write, header bound as AAD, atomic replace; the key is a non-exportable Android Keystore key (hardware-backed where the device has a TEE). Both keys and values are encrypted. It protects against reading the app's files from a backup, a copied data directory or a rooted/forensic file dump **without** the device's Keystore; it does **not** protect against malware running as this app, or against someone who can unlock your device. The old plain `shared_prefs` XML is imported once, overwritten with zeros and deleted (flash wear-levelling can still leave remnants). If the Keystore is unusable the app falls back to an unencrypted file and Settings says so; if the file cannot be decrypted (e.g. after a Keystore reset) settings reset to defaults. **Gecko build:** the SQLite database is encrypted with SQLCipher (AES-256, raw key derived from a Keystore-wrapped master key). **Not encrypted:** downloaded files (and, in the classic build, the SQLite database if the Keystore is unusable).
* The blob helper (`assets/js/blob_tracker.js`) wraps `URL.createObjectURL/revokeObjectURL` and `<a>.click/href/download` and, unlike the privacy shield script, is **not** disguised as native code: a page that inspects those functions can tell this browser apart. It sends nothing anywhere by itself and keeps at most 12 blobs for at most 3 minutes.
* A `blob:` download needs JavaScript on the site and the blob must belong to the page's main frame origin (blobs created inside cross-origin iframes cannot be read). Pages whose CSP forbids `fetch(blob:)` still work when the blob was created through `URL.createObjectURL` after the tracker script ran.
* No SafetyNet-style or cloud reputation checks (by design); malware-host protection is a local list you can extend.
* Not independently audited.

## Gecko build: tamper response, payment protection, post-quantum backups (see GECKO.md, Stage 2)
* **Sealed Mode** reacts to debugger / hooking / repackaging signals by killing all processes, deleting web sessions and restarting in
  an empty secrets-free process (`:sealed`) until the owner authenticates. Detection is local and therefore bypassable by an attacker who
  already controls the device or the process; it limits damage, it is not a guarantee.
* Set `shield.certSha256` in `gradle.properties` (SHA-256 of your release signing certificate: `apksigner verify --print-certs app-release.apk`)
  to make a repackaged APK a critical signal.
* **Secure Payment tab** and payment-page hardening (FLAG_SECURE, overlay/tap-jacking, autofill/accessibility, phishing guard, paranoid checkout).
  Card numbers are never read, stored or logged by the app; the extension reports only that a card form exists.
* **Backups** are sealed with X25519 + ML-KEM-768 (Bouncy Castle) and authenticated with an HMAC from the private key; the recovery key is
  Argon2id-protected. Website TLS post-quantum hybrid comes from the Gecko engine.
* **App lock** is a UI gate (BiometricPrompt, no crypto binding): it does not protect against code running inside the app process.
