# Review of Stage 2 (second pass) — findings, fixes, open items

Method: line-by-line desk review of every new/changed file, cross-checked against Mozilla / Bouncy Castle / SQLCipher docs,
unit-test expectations traced by hand, extension logic run in Node. **Nothing has been compiled** (no Kotlin/Gradle available
to the author). Severity = impact if it shipped.

## Found and fixed in this pass
| # | Sev | Problem | Fix |
|---|-----|---------|-----|
| 1 | Critical | Secure Payment tab could blank itself: Gecko reports the location **before** the security info, so the first verdict saw `secure=false` → "connection not secure" (a *blocking* issue) → forced `about:blank` on every first navigation. | `PaymentGuard.assess(secure: Boolean?)`; unknown is never "insecure". `GeckoTab.securityKnown` resets per origin. Test added. |
| 2 | High | Popup tabs: the UI could call `setSession(session, runtime)` on a session GeckoView itself is about to open → `IllegalStateException`. | `GeckoTab.isPopup`; `showTab` waits (max 1 s) instead of opening it. |
| 3 | High | Security Center could show "database NOT encrypted" simply because the lazy DB was not opened yet. | `isEncrypted` / `recoveredFromKeyLoss` open the DB first; key-loss notice added (EN/AR/FA). |
| 4 | Medium | Settings switches used `isPressed` → keyboard / TalkBack toggles changed the switch but not the setting. | Click listener. |
| 5 | Medium | While the lock cover was showing, Back and Ctrl-shortcuts still acted on the hidden browser. | Guarded. |
| 6 | Medium | `FLAG_SECURE` was not refreshed after toggling App lock. | Re-applied on sheet close and `onStart`. |
| 7 | Medium | Encrypted backup contained `gecko_session` (open-tab URLs, may carry tokens). | Excluded from export and import. |
| 8 | Medium | A hostile/damaged sealed box could surface BC's unchecked exceptions (e.g. all-zero X25519 result). | `SealedBox.open` wraps them in `GeneralSecurityException`. |
| 9 | Medium | Hook check matched any class name containing "frida" ("Friday…") → possible false Sealed Mode. | Only `re.frida` / `.frida.` packages; test added. |
| 10 | Medium | A mistyped `shield.certSha256`, or Play App Signing (Google re-signs), would seal **every** launch. | Build fails on a malformed digest; docs say use the Play *app signing* key digest. |
| 11 | Medium | Card-field signal was lost when the per-tab receiver attached after the page loaded. | Content script retries 6× with back-off (URL heuristics still cover the common case). |
| 12 | Low | Android 15 cuts `dataSync` foreground services after their budget; no `onTimeout` → crash. | `DownloadService.onTimeout` stops the service. |
| 13 | Low | Sealed Mode could not be tested on debug builds (real checks are release-only). | Debug-only "Simulate tamper" button. |
| 14 | Low | CI ignored Gecko unit tests, the Node test and the pinned GeckoView version. | Workflow extended. |

## Verified since the first pass
`SecurityInformation.isException` / `isSecure` exist; `GeckoSessionSettings.Builder.contextId` + `usePrivateMode` have no stated
conflict (storage of a context is deleted with `clearDataForSessionContext`); all other signatures used are listed in GECKO.md.

## Open (deliberately not "fixed" — design limits or needs a device)
| # | Sev | Item | Why open / next step |
|---|-----|------|----------------------|
| O1 | High | **Compile and runtime status unknown.** Most likely first errors: `net.zetetic…SQLiteDatabase.openOrCreateDatabase` overload, BC 1.84 / sqlcipher 4.19.0 / sqlite 2.7.0 coordinates, `ShieldApp` early-return side effects. | Run `gradle testClassicDebugUnitTest`, then `assembleGeckoDebug`; paste the log. |
| O2 | High | Local tamper detection can be bypassed by an attacker who controls the process/device. | Inherent. Mitigation is damage limiting (Phase 1: auth-bound keys, native checks). |
| O3 | Medium | App lock is a UI gate, not key-bound. DB key is not auth-bound, so "Seal" (not "Seal + wipe") leaves the DB readable to an in-process attacker. | Phase 1: Keystore key with `setUserAuthenticationRequired`, re-wrap on seal. |
| O4 | Medium | Picked upload files are copied to cache without a size cap; deleted only at the next start after 6 h. | Phase 1: cap + delete on tab close. |
| O5 | Medium | Payment Request API / Google Pay / passkeys-WebAuthn are not wired in the Gecko screen. | Phase 2 (verify GeckoView support first). |
| O6 | Medium | Paranoid checkout has no per-site allow list; it can break a checkout. | Phase 2: "allow this once" in the unsafe-page dialog. |
| O7 | Low | `REQUEST_INSTALL_PACKAGES` and cleartext (classic flavour) remain. | Phase 1: remove from Gecko flavour if APK hand-off is not needed. |
| O8 | Low | Clipboard is cleared when a Secure Payment tab closes (also clears an unrelated clip). | Intentional; make it a setting in Phase 2. |
| O9 | Low | Idle timeout of a secure tab is enforced only while the screen is in front and at the next `onStart`. | Add an alarm-based expiry (Phase 2). |
| O10 | Low | Pinned GeckoView build string not checked against the repository; stable is 157.x, nightly is 160. | CI step added (non-blocking); pick the newest 157/158 build. |
| O11 | Info | Stage-1 gaps (per-site settings, date pickers, add-ons, pause/resume of Gecko downloads, tablet layout). | Phase 3. |

## Device test checklist (needs a phone; ~30 min)
1. Fresh install → browse → Security Center shows "database encrypted"; key fingerprint present.
2. Update over an old build with history → history/bookmarks still there, status "encrypted".
3. Debug build: Security Center → Simulate tamper → sealed screen, browser logged out, unlock works, "Reset" works.
4. Menu → Secure Payment tab → https site loads; banner shows; screenshot is blocked; leave idle 5 min → closed; no history entry.
5. Open a test checkout (any site with a card form) in a normal tab → banner "Payment page", snackbar offers the secure tab.
6. Visit `http://neverssl.com/checkout`-style URL in a secure tab → blocked; lookalike test host → warning.
7. Export backup → restore on the same device; export recovery key → restore on a second device with passphrase.
8. Private tab: the blocker counter increases (extension now active there).
9. Turn on Paranoid checkout, load a normal shop checkout, note what breaks.
