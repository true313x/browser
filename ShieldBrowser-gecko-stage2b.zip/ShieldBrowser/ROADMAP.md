# ShieldBrowser (Gecko) — development plan

Principle: each phase ends with something a user can feel and a test that proves it. Security claims are written only after the
test exists. Order = risk reduction per hour of work.

## Phase 0 — Make it real (days 1–3)
* Build both flavours; fix compile errors; run unit tests + `js-test`; confirm pinned GeckoView exists (CI step).
* Device checklist in REVIEW.md. Gate: **green CI for classic + gecko, checklist 1–8 pass.**
* Record real numbers: cold-start time (Keystore + SQLCipher migration), tamper-loop battery cost, APK size.

## Phase 1 — Close the known security gaps (weeks 1–3)
1. **Auth-bound keys:** Keystore AES key with `setUserAuthenticationRequired(true)` (+ `setInvalidatedByBiometricEnrollment`) wrapping the
   hybrid private key; on Seal re-wrap the DB master key under it so a sealed phone cannot open the DB without the owner.
2. **Real sealed sandbox:** optional decoy (empty private Gecko session, own profile dir via runtime `arguments("-profile", dir)`, all
   capabilities denied, no network permission use) in `:sealed`; log attempts sealed to the owner's Kyber key for later review.
3. **Detection depth:** small native (JNI) checks — inline-hook prologue check on a few libc/Gecko entry points, `/proc/self/maps` diff
   against load-time snapshot, direct-syscall `ptrace` self-check; time-jitter scheduling so the scan interval is not predictable.
   Keep every signal graded (CRITICAL/WARN) and add a **seal-loop breaker** (3 seals in 10 min → ask before sealing again).
4. **Signing:** release signing config, App-Signing digest pinning, optional Play Integrity as an *opt-in* second signal (network, Google).
5. Housekeeping: upload copy cap + delete-on-close, drop `REQUEST_INSTALL_PACKAGES`/cleartext where unused, StrongBox when available.
Gate: pen-test script (Frida attach, repackage, debuggable flip, root) → each ends sealed or warned as designed.

## Phase 2 — Payments, deeper (weeks 3–6)
1. Verify and wire **Payment Request / Google Pay**, **WebAuthn/passkeys + NFC security keys** (GeckoView support first).
2. **3-D Secure / OTP flows:** keep the secure tab alive across app switches safely (alarm-based expiry), optional SMS-OTP assist without
   reading unrelated SMS.
3. **Provider & bank list for the target market** (mada, KNET, Fawry, Paymob, STC Pay, regional banks) shipped as a signed, versioned list;
   update path without telemetry.
4. **Phishing:** offline lookalike model for banks/PSPs of the region, certificate-subject vs. host comparison (`SecurityInformation.host`),
   punycode display in the address bar, warning page instead of dialog.
5. Paranoid checkout: "allow once" per script host, learning mode that reports what it blocked; per-site memory.
6. Settings: clipboard policy, idle timeout, require-auth defaults; in-app explanation screens (AR/EN/FA).
Gate: 20 real checkouts across 10 PSPs: ≥ 90 % complete in a Secure Payment tab, 0 card data in logs/history/backups.

## Phase 3 — Product parity & polish (weeks 6–10)
Per-site settings in Gecko, date/time/colour pickers, tab strip + tablet layout, reader mode, pause/resume for Gecko downloads, add-on
install (uBlock Origin), better start page, accessibility pass (TalkBack on every new screen), RTL audit, translations review.
Gate: Stage-1 gap list empty; accessibility scanner clean.

## Phase 4 — Quality, release, upkeep (continuous)
* CI: unit + instrumented (emulator) + Node + lint + dependency/CVE check + SBOM; reproducible builds; signed releases.
* GeckoView update cadence: track the 4-week Firefox release train; security releases within 48 h; CI job that opens a PR with the new pin.
* Crash/diagnostics **without telemetry**: local, exportable, encrypted log with explicit user share.
* External security audit of `crypto/`, `security/`, SealedMode; public threat model; disclosure policy (SECURITY.md) and bounty if funded.
* Store readiness: Play policy review (FGS types, permissions), F-Droid metadata, privacy policy ("no data leaves the device").

## Risks to watch
| Risk | Mitigation |
|------|-----------|
| False positives seal real users | graded signals, seal-loop breaker, build-time pin validation, field test before default-on |
| Checkouts break under Paranoid mode | opt-in, allow-once, telemetry-free self-report |
| GeckoView API drift (4-week cadence) | pin + CI canary build against newest beta |
| Over-claiming security | every claim in docs tied to a test or labelled as a limit |
| Solo maintenance load | keep Phase order; drop Phase 3 items before Phase 1/2 |
